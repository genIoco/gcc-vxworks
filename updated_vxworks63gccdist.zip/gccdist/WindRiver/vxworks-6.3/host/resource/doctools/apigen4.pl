# apigen4.pl - produce internal XML from distilled refgen markup
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01v,30jun05,khs  Add tcl specific bolding for SEE ALSO section
# 01u,16jun05,khs  Add \COMMAND directives
# 01t,26apr05,lll  Force BSP primary output filename to be "target" when 
#                  processing target.{nr|ref} to facilitate automated creation
#                  of Eclipse online help TOC for BSPs
# 01s,06oct04,wsl  revise handling of item lists
# 01r,06oct04,wsl  Add variant format for list markup, SPR 102301
# 01q,05oct04,wsl  fix format of error messages
# 01p,01oct04,wsl  add line numbers to error messages, SPR 93816
# 01o,30sep04,wsl  SPR 102166, hangs on blank line after \is
# 01n,24sep04,wsl  fix bug in libraryName
# 01m,24sep04,wsl  SPR 98236, tools should not document like libraries
# 01l,22sep04,wsl  SPR 94608, suppress error messages for undocumented
#                  routines
# 01k,22sep04,wsl  SPR 101642, banner-like comments need better error msg
# 01j,21sep04,wsl  add <file> tag in support of CSS, SPR 101587
# 01i,17sep04,wsl  add IFSET directives, SPR 101589
# 01h,16sep04,wsl  implement -sort option, SPR 97290
# 01g,16sep04,wsl  fix SPR 97007, incorrect tagging of routines
# 01f,15sep04,wsl  SPR 96061, make LAST MODIFIED section -internal
# 01e,15sep04,wsl  replace some regexps that were very slow for some reason
# 01d,30jun04,tpw  Handle multiword title names.
# 01c,25may04,tpw  Add -missingok, suppress missing section warnings.
# 01b,21mar03,wsl  allow NOMANUAL in library section
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This group of subroutines takes the complete text with pure refgen markup
# and converts it into an internal XML markup.  The tags are defined in the
# file apigen.dtd, which also describes some non-XML restrictions used in the
# internal format.
#
# NOROUTINES
#

# set the name space

package format;


###############################################################################
#
# apiParse - convert text to internal XML
#
# This routine is the master routine for putting the text into the internal
# format, which is a form of XML.
#



sub apiParse
    {
    $v = $::v;

    if ( $::optionDebug )
        {
        print STDERR "Starting Stage 4 -- formatting\n";
        }

    return () if not @_;

    my @routineList = @_;
    my $libraryText = shift @routineList;
    @routineDescs = ();  # list of routine short descriptions
    $loopCount = 0;   # variable to detect infinite loops
    $loopMax   = 100; # maximum loop count

    # variables global to the parsing stage

    $allMarks    = "bs|be|cs|ce|h|is|i|ie|ms|ml|m|me|sh|ss|se|ts|te|IMAGE";
    $sectionEnds = "h\\s|INTERNAL|NOROUTINES|NOMANUAL|TITLE|COMMAND";

    # find the library name for future reference

    if ( $libraryText =~ /^(.*)$v\s*(\w+[^-]*?)\s*-/ )
        {
        $libraryName = $2;

        # Beginning with VxWorks 6.1, force BSP primary output filename to 
        # always be "target" when processing target.{nr|ref} to facilitate 
        # automated creation of Eclipse online help TOC for BSPs.

        if ( $::inFile =~ /^target\.(nr|ref)/i )
            {
            $libraryName = "target";
            }
        }
    else
        {
        print STDERR "$1: INTERNAL ERROR: library name not first in text\n";
        $libraryName = "unknown";
        }

    # the library title may change based on the \TITLE directive and category

    $::libraryTitle = $libraryName;

    # process each library/routine section separately

    if ( $::optionSort )
        {
        # swap line number info with text for sort

        foreach $routineText (@routineList)
            {
            $routineText =~ s/^([^$v\n]*)$v([^\n$v]*)\n/\2$v\1\n/o;
            }
        @routineList = sort @routineList;

        foreach $routineText (@routineList)
            {
            $routineText =~ s/^([^$v\n]*)$v([^\n$v]*)\n/\2$v\1\n/o;
            }
        }

    foreach $routineText (@routineList)
        {
        $routineText = apiRtnParse($routineText);
        }

    # library must be processed last to pick up list of routine names

    $libraryText = apiLibParse($libraryText);

    if ( $isNoroutines )
        {
        grep s/<$::tagRoutinedoc>/<$::tagRoutinedoc scope="internal">/,
          @routineList;
        }

    if ( $::optionDebug )
        {
        my $debugFile = $::outFileBase . ".4";
        my $debugText = (join "\n", $libraryText, @routineList) . "\n";
        $debugText =~ s/$v/:/go;

        open DEBUG, ">$debugFile";
        print DEBUG $debugText;
        close DEBUG;

        print STDERR "  Finished Stage 4\n";
        }

    return ($libraryText, @routineList);
    }


###############################################################################
#
# apiParsePrep - do format conversion that does not depend on parsing 
#
# This routine converts the problematic special characters <, >, and & to
# the standard entity references &lt;, &gt;, and &amp;.  It then inserts
# bold and italic markers for sections marked with single quotes and angle
# brackets, and removes the escapes on quote marks and backslashes.  Since
# the conversion of < and > depends on context, this must all be done line
# by line.
#

sub apiParsePrep
    {

    return () if not @_;

    my @textLines = split /\n/, shift;

    my $marker = chr 129;

    my $inCode  = 0;

    # remove comments

    my @tempLines = grep !/$v\\\"/, @textLines;
    @textLines = @tempLines;
    @tempLines = ();

    # pre-process text line by line

    foreach ( @textLines )
        {
        my @original = $_;

        # code displays are exempt from all reformatting

        if ( /$v(\\cs|\\bs)/ )
            {
            $inCode = 1;
            next;
            }
        elsif ( /$v(\\ce|\\be)/ )
            {
            $inCode = 0;
            next;
            }

        s/&/&amp;/g;  # must come first -- applies even to code

        if ( $inCode )
            {
            s/</&lt;/g;
            s/>/&gt;/g;
            }
        else
            {
            # not in code display

            s/\\\\|\\\//&bslash;/g;  # escaped backslash -- must come first
            s/\\&amp;/&amp;/g; # legacy -- ampersand need not be escaped
            s/\\</&lt;/g;
            s/\\>/&gt;/g;
            s/\\\`/&btick;/g;
            s/\\\|/&vbar;/g;

            # italicize words in angle brackets

            s/<(\S[^>]*)>/$marker$::tagItalic>\1$marker\/$::tagItalic>/g;

            # all angle brackets should now be honest

#            s/<($|\s)/&lt;\1/g;
            s/</&lt;/g;

            # complete marking of italics

            s/$marker/</g;

            # make marked titles bold

            s/$v\\tb\s+(.*)$/$v<$::tagItalic>\1<\/$::tagItalic>/;
            s/(,|\.)\s*(<\/$::tagItalic>)/\2\1/;

            # embolden things in single quotes

            s/($v|[^\w\\])(\`|\')([^\']*[^\\\'])\'($|\W)/\1<$::tagBold>\3<\/$::tagBold>\4/g;
            s/\\\'/\'/g;

            # flag library names -- twice because of overlap
            # careful not to misinterpret file name, but allow period

            s/($v|[^>\w])(\w+(Lib|Show|Drv|Sio))(\.?($|[^.\(\/:\w]+))/\1<$::tagLibrary>\2<\/$::tagLibrary>\4/go;
            s/($v|[^>\w])(\w+(Lib|Show|Drv|Sio))(\.?($|[^.\(\/:\w]+))/\1<$::tagLibrary>\2<\/$::tagLibrary>\4/go;
            s/($v|[^>\w])(if_\w+)(\.?($|[^.\(\/:\w]+))/\1<$::tagLibrary>\2<\/$::tagLibrary>\3/go;
            s/($v|[^>\w])(if_\w+)(\.?($|[^.\(\/:\w]+))/\1<$::tagLibrary>\2<\/$::tagLibrary>\3/go;
            s/\\lib\s+(\S*\w)/<$::tagLibrary>\1<\/$::tagLibrary>/go;

            # find file names -- twice because of overlap
            # must be careful not to pick up line number info

            s/($v|[^:_\\\.\/\w>])([_\\\.\/\w]+\.([aocCsShH]|tcl|cc|html|gif|hpp|txt|java))(\.?($|[^.\(\/\w]+))/\1<$::tagFile>\2<\/$::tagFile>\4/go;
            s/($v|[^:_\\\.\/\w>])([_\\\.\/\w]+\.([aocCsShH]|tcl|cc|html|gif|hpp|txt|java))($|\.?([^.\(\/\w]+))/\1<$::tagFile>\2<\/$::tagFile>\4/go;
            s/\\file\s+(\S*\w)/<$::tagFile>\1<\/$::tagFile>/go;

            # flag routines

            s/((operator )?)([\w\~:\.;]+)\(\)/<$::tagRoutine>\1\3(\&nbsp;)<\/$::tagRoutine>/g;
            s/\\rtn\s+(\S*\w)/<$::tagRoutine>\1<\/$::tagRoutine>/go;

            # mark symbolic constants -- twice because of overlap

            s/($v|[^\.\w>\\])([A-Z]+_[_A-Z0-9]+)(\.?$|\.?([^\.\w]))/\1<$::tagConstant>\2<\/$::tagConstant>\3/g;
            s/($v|[^\.\w>\\])([A-Z]+_[_A-Z0-9]+)(\.?$|\.?([^\.\w]))/\1<$::tagConstant>\2<\/$::tagConstant>\3/g;

            # mark URLs

            s/(http:\/\/\S*?)((\.|,)?($|\s))/<$::tagUrl>\1<\/$::tagUrl>\2/g;

            # mark email addresses

            s/(mailto:\/\/\S*?)((\.|,)?($|\s))/<$::tagEmail>\1<\/$::tagEmail>\2/g;

            # mark Wind River errno codes -- twice because of overlap

            s/($v|[^\.\w>])(S_\w+_[_A-Z0-9]+)(\.?$|\.?([^\.\w]))/\1<$::tagConstant>\2<\/$::tagConstant>\3/g;
            s/($v|[^\.\w>])(S_\w+_[_A-Z0-9]+)(\.?$|\.?([^\.\w]))/\1<$::tagConstant>\2<\/$::tagConstant>\3/g;
            
            # mark standard errno codes

            my $mark = chr 129;
            while ( s/($v|[^\.\w>])(E[A-Z]+)(\.?$|\.?([^\.\w]))/\1$mark\3/ )
                {
                my $maybeErrno = $2;
                if ( grep /^$maybeErrno$/, @::stdErrnoList )
                    {
                    s/$mark/<$::tagConstant>$maybeErrno<\/$::tagConstant>/;
                    }
                else
                    {
                    s/$mark/<>$maybeErrno<>/;
                    }
                }
            s/<>//g;

            # mark some special words -- twice because of overlap

            s/($v|[^\.\w>])(OK|ERROR|NULL|TRUE|FALSE|EOF)(\.?$|\.?([^\.\w]))/\1<$::tagConstant>\2<\/$::tagConstant>\3/g;
            s/($v|[^\.\w>])(OK|ERROR|NULL|TRUE|FALSE|EOF)(\.?$|\.?([^\.\w]))/\1<$::tagConstant>\2<\/$::tagConstant>\3/g;
	    s/($v|\s)(tty|fd)($|\s|,|\.\s|;)/\1<$::tagItalic>\2<\/$::tagItalic>\3/g;
	    s/($v|\s)(tty|fd)($|\s|,|\.\s|;)/\1<$::tagItalic>\2<\/$::tagItalic>\3/g;

            # fix up special cases

            s/(\$\{)(<$::tagConstant>)([^<]*)(<\/$::tagConstant>)(\})/\2\1\3\5\4/;
            }

        # change /@ @/ to /* */ -- applies to all text

        s:/@:/*:g;
        s:([^\\])@/:\1*/:g;
        s:\\@:@:g;
        }

    return @textLines
    }


###############################################################################
#
# apiLibParse - convert library text to internal XML
#
# This routine does some library-specific pre- and post-processing for
# the master routine, apiEntryParse(), for putting text into the internal
# format, which is a form of XML.
#

sub apiLibParse
    {

    my @textLines = apiParsePrep(@_);

    # global variables

    $entryIsRoutine = 0; # shameless hack to signal apiEntryParse
    $isNoroutines = 0; # state variable indicating that all routines are private

    # The routine apiParseEntry will fill out the following special lists.
    # An empty list is a signal that the special list should not be used
    # -- the section is not to be re-ordered.

    $textLines[0] =~ /^(.*)$v/;
    my $firstLoc = $1;

    @headerLines   = ("$firstLoc$v<$::tagLibrarydoc>");
    @includesLines = ();
    @seeAlsoLines  = ();
    @synopsisLines = ();
    @returnsLines  = ();
    @errnoLines    = ();

    # finish the list of routine descriptions

    my $blankString = "";
    if ( $::blankWhenNoRoutines )
        {
        $blankString = " blanking=\"yes\"";
        }
    unshift @routineDescs, "$firstLoc$v<$::tagRtnlines>";
    unshift @routineDescs, "$firstLoc$v<$::tagHeading>ROUTINES</$::tagHeading>";
    unshift @routineDescs, "$firstLoc$v<$::tagRtnlist$blankString>";
    push @routineDescs, "$firstLoc$v</$::tagRtnlines>";
    push @routineDescs, "$firstLoc$v</$::tagRtnlist>";

    # parse the library header text

    @bodyLines = apiEntryParse(@textLines);

    # if there was a NOROUTINES directive, mark all routines as private

    if ( $isNoroutines )
        {
        grep { s/<$::tagRtnline>/<$::tagRtnline scope="internal">/ }
            @routineDescs;

        # if there is also a synopsis section, document this as a
        # tool/utility rather than as a library.  Omit the routine list
        # and don't require an INCLUDES section.

        if ( scalar(@synopsisLines) > 0 )
            {
            $::langIncludesRequired = 0;
            shift @routineDescs;
            unshift @routineDescs, "<$::tagRtnlist blanking=\"yes\">";
            }
        }

    # assemble the processed text

    @textLines = @headerLines;

    # if there was a SYNOPSIS section, place it first

    push @textLines, @synopsisLines;

    push @textLines, @routineDescs;

    # the DESCRIPTION and INCLUDE FILES sections are required

    if ( not @bodyLines )
        {
        if ( ! $isNomanual || $::optionInternal )
            {
            print STDERR "$firstLoc: ERROR: no DESCRIPTION section for $name\n";
            $::errorStatus = 1;
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }

        push @bodyLines, "$firstLoc$v<$::tagSection>";
        push @bodyLines, "$firstLoc$v<$::tagHeading>DESCRIPTION<\/$::tagHeading>";
        push @bodyLines, "$firstLoc$v<$::tagPara>";
        push @bodyLines, "$firstLoc${v}none";
        push @bodyLines, "$firstLoc$v<\/$::tagPara>";
        push @bodyLines, "$firstLoc$v<\/$::tagSection>";
        }
    push @textLines, @bodyLines;

    if ( $::langIncludesRequired && scalar(@includesLines) == 0 )
        {
	if ( not $::optionMissingOk )
	    {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$firstLoc: WARNING: no INCLUDE FILES section for $name\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
	    }
        push @includesLines, "$firstLoc$v<$::tagHeading>INCLUDE FILES<\/$::tagHeading>";
        push @includesLines, "$firstLoc$v<$::tagPara>";
        push @includesLines, "$firstLoc${v}none";
        push @includesLines, "$firstLoc$v<\/$::tagPara>";
        push @includesLines, "$firstLoc$v<\/$::tagIncludes>";
        }
    push @textLines, @includesLines;

    # the RETURNS section is optional

    if ( scalar (@returnsLines) > 1 )
        {
        push @textLines, @returnsLines;
        }

    # the ERRNO section is optional

    if ( scalar (@errnoLines) > 1 )
        {
        push @textLines, @errnoLines;
        }

    # the SEE ALSO section is optional

    if ( scalar(@seeAlsoLines) > 1 )
        {
        push @textLines, @seeAlsoLines;
        }

    # the LAST MODIFIED section is derived from the modification history

    if ( $::modDate ne "" )
        {
        push @textLines, "$firstLoc$v<$::tagSection scope=\"internal\">";
        push @textLines, "$firstLoc$v<$::tagHeading>LAST MODIFIED</$::tagHeading>";
        push @textLines, "$firstLoc$v<$::tagPara>";
        push @textLines, "$firstLoc$v$::modDate";
        push @textLines, "$firstLoc$v</$::tagPara>";
        push @textLines, "$firstLoc$v</$::tagSection>";
        }

    push @textLines, "$firstLoc$v</$::tagLibrarydoc>";

    return join "\n", @textLines;
    }


###############################################################################
#
# apiRtnParse - convert routine text to internal XML
#
# This routine does some routine-specific pre- and post-processing for
# the master routine, apiEntryParse(), for putting text into the internal
# format, which is a form of XML.
#

sub apiRtnParse
    {

    my @textLines = apiParsePrep(@_);

    $entryIsRoutine = 1; # shameless hack to signal apiEntryParse

    # The routine apiParseEntry will fill out the following special lists.
    # An empty list is a signal that the special list should not be used
    # -- the section is not to be re-ordered.

    $textLines[0] =~ /^(.*)$v/o;
    my $firstLoc = $1;

    @headerLines   = ("$firstLoc$v<$::tagRoutinedoc>");
    @includesLines = ();
    @seeAlsoLines  = ();
    @synopsisLines = ();
    @returnsLines  = ();
    @errnoLines    = ();

    @bodyLines = apiEntryParse(@textLines);

    # assemble routine entry

    @textLines = @headerLines;
    push @textLines, @synopsisLines;

    if ( not @bodyLines )
        {
	if ( not $::optionMissingOk )
	    {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$firstLoc: WARNING: no DESCRIPTION section for $name\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
	    }
        push @bodyLines, "$firstLoc$v<$::tagSection>";
        push @bodyLines, "$firstLoc$v<$::tagHeading>DESCRIPTION<\/$::tagHeading>";
        push @bodyLines, "$firstLoc$v<$::tagPara>";
        push @bodyLines, "$firstLoc${v}none";
        push @bodyLines, "$firstLoc$v</$::tagPara>";
        push @bodyLines, "$firstLoc$v<\/$::tagSection>";
        }
    push @textLines, @bodyLines;

    if ( $::langReturnsRequired && scalar(@returnsLines) == 0 )
        {
	if ( not $::optionMissingOk && !$::optionCommand)
	    {
            if (! $isNomanual || $::optionInternal )
                {
                print STDERR "$firstLoc: WARNING: missing RETURNS section for $name\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
	    }
	if (!$::optionCommand)   # Instead of returning Not Available for empty Returns
	   {                     # don't return RETURN at all
           push @returnsLines, "$firstLoc$v<$::tagReturns>";
           push @returnsLines, "$firstLoc$v<$::tagHeading>RETURNS<\/$::tagHeading>";
           push @returnsLines, "$firstLoc$v<$::tagPara>";
           push @returnsLines, "$firstLoc${v}Not Available";
           push @returnsLines, "$firstLoc$v</$::tagPara>";
           push @returnsLines, "$firstLoc$v<\/$::tagReturns>";
	   }
        }
    push @textLines, @returnsLines;


    if ( $::langErrnoRequired && scalar(@errnoLines) == 0 )
        {
	if ( (not $::optionMissingOk) && !$::optionCommand)
	    {
            if ( ! $isNomanual || $::optionInternal)
                {
                print STDERR "$firstLoc: WARNING: missing ERRNO/ERROR section for $name\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
	    }
	if (!$::optionCommand)   # Instead of returning Not Available for empty ERRNO
	   {                     # don't return ERRNO at all
            push @errnoLines, "$firstLoc$v<$::tagErrno>";
            push @errnoLines, "$firstLoc$v<$::tagHeading>ERRNO<\/$::tagHeading>";
            push @errnoLines, "$firstLoc$v<$::tagPara>";
            push @errnoLines, "$firstLoc${v}Not Available";
            push @errnoLines, "$firstLoc$v</$::tagPara>";
            push @errnoLines, "$firstLoc$v<\/$::tagErrno>";
	   }
        }
    push @textLines, @errnoLines;

    if ( scalar(@seeAlsoLines) == 0 )
        {
        push @seeAlsoLines, "$firstLoc$v<$::tagSeealso>";
        push @seeAlsoLines, "$firstLoc$v<$::tagHeading>SEE ALSO</$::tagHeading>";
        push @seeAlsoLines, "$firstLoc$v<$::tagPara>";
        push @seeAlsoLines, "$firstLoc$v<$::tagLibrary>$libraryName<\/$::tagLibrary>";
        push @seeAlsoLines, "$firstLoc$v</$::tagPara>";
        push @seeAlsoLines, "$firstLoc$v</$::tagSeealso>";
        }
    push @textLines, @seeAlsoLines; # can't be empty

    push @textLines, "$firstLoc$v</$::tagRoutinedoc>";

    #resets $::optionCommand to false for the next section
    $::optionCommand = '0'; # '0' is false in Perl

    return join "\n", @textLines;
    }


###############################################################################
#
# apiEntryParse - convert text to internal XML
#
# This routine is the master routine for putting text into the internal
# format, which is a form of XML.
#

sub apiEntryParse
    {

    @entryLines = @_;

    # figure out whether the routine is NOMANUAL

    $isNomanual = 0;
    my @shortList = grep /$v\\(NOMANUAL|IFSET\s)/, @entryLines;
    foreach $direct (@shortList)
        {
        if ( $direct =~ /$v\\NOMANUAL\s*$/ )
            {
            $isNomanual = 1;
            }

        # a conditional routine that does not meet a condition becomes NOMANUAL

        if ( ! $isNomanual && $direct =~ /$v\\IFSET\s+(.*)$/ )
            {
            my @condList = split /\s+/, $1;

            my $match = 0;
            foreach $cond ( @condList )
                {
                if ( grep /^$cond$/, @::optionConditions )
                    {
                    $match = 1;
                    last;
                    }
                }
            if ( ! $match )
                {
                $isNomanual = 1;
                }
            }
        }

    # if routine is to be documented, handle IFSET_START/END directives

    if ( $isNomanual )
        {
        @entryLines = apiConditionDoc(@entryLines);
        }
    else
        {
        @entryLines = apiConditionApply(@entryLines);
        }

    # note that any IFSET-type directives left now will be written out
    # because there must be an -internal flag for any output to result

    my @outLines = ();

    my $line = shift @entryLines;
    $line = shift @entryLines while $line =~ /$v\s*$/;  # skip blank lines
    
    # first line should be the short description

    # $name and $desc are global -- beware!
    # note that name may have been (inaccurately) tagged by apiParsePrep()

    my $loc;
    if ( $line =~ /^(.*)$v\s*(<[^>]*>)?(\w+[^<-]*?)(<[^>]*>)?\s+-\s+(.*)/o )
        {
        $loc  = $1;
        $name = $3;
        $desc = $5;
        }
    elsif ( $line =~ /^(.*)$v\s*(<[^>]*>)?(\w+[^<-]*?)(<[^>]*>)?\s+-\s*$/o )
        {
        $loc  = $1;
        $name = $3;
        $desc = "";

        if ( ! $isNomanual || $::optionInternal )
            {
            print STDERR "$loc: ERROR: missing title description\n";
            $::errorStatus = 1;
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }
        }
    else
        {
        $line =~ /^(.*)$v/o;
        $loc  = $1;
        $name = "unknown";
        $desc = "";

        if ( ! $isNomanual || $::optionInternal )
            {
            print STDERR "$loc: ERROR: indecipherable title line\n";
            $::errorStatus = 1;
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }
        }

    if ( $entryIsRoutine and ($extract::apiClassName ne "") and $name !~ /::/ )
	{
	$name = $extract::apiClassName . "::" . $name;
	}


    # all other lines must be part of a section

    while ( @entryLines )
        {
        push @outLines, apiSectionGet();
        }
    
    my $fancyName = $name;
    if ( $::apiFileLanguage =~ /^(asm|bsp|c|cpp|idl|java|pcl|perl)$/ && !$::optionCommand)
        {
	 $fancyName .= "(&nbsp;)";
        }
    # the above $fancyName... section has to be below while (@entryLines) section
    # this is due to $::optionCommand indicating presence of \COMMAND in apiSectionGet
    
    # now set up the header and routine description

    $scope = "";
    $scope = " scope=\"internal\"" if $isNomanual;
    if ( $entryIsRoutine )
        {
        pop  @headerLines;
        push @headerLines, "$loc$v<$::tagRoutinedoc$scope>";
        push @headerLines, "$loc$v<$::tagRtnhead>$fancyName</$::tagRtnhead>";
        push @headerLines, "$loc$v<$::tagRtnname>";
        push @headerLines, "$loc$v<$::tagHeading>NAME</$::tagHeading>";
        push @headerLines, "$loc$v<$::tagRtnshort>";
        push @headerLines, "$loc$v<$::tagRoutine>$fancyName</$::tagRoutine> " .
	                   "&endash; $desc";
        push @headerLines, "$loc$v</$::tagRtnshort>";
        push @headerLines, "$loc$v</$::tagRtnname>";
        push @routineDescs, "$loc$v<$::tagRtnline$scope>";
        push @routineDescs, "$loc$v<$::tagRoutine>$fancyName</$::tagRoutine>" .
	                    " &endash; $desc<$::tagBreak/>";
        push @routineDescs, "$loc$v</$::tagRtnline>";
        }
    else
        {
        pop  @headerLines;
        push @headerLines, "$loc$v<$::tagLibrarydoc$scope>";
        push @headerLines, "$loc$v<$::tagLibhead>$name</$::tagLibhead>";
        push @headerLines, "$loc$v<$::tagLibname>";
        push @headerLines, "$loc$v<$::tagHeading>NAME</$::tagHeading>";
        push @headerLines, "$loc$v<$::tagLibshort>";
        push @headerLines, "$loc$v<$::tagLibrary>$name</$::tagLibrary> &endash; " .
	                   "$desc";
        push @headerLines, "$loc$v</$::tagLibshort>";
        push @headerLines, "$loc$v</$::tagLibname>";
        }

    return @outLines;
    }


###############################################################################
#
# apiConditionDoc - translate IFSET markup into readable text for -internal
#
# This routine is called only when the routine is marked as either NOMANUAL or
# the whole routine requires a condition that is not met.  Thus, it is only
# present in the output if the -internal flag has been specified.  In this
# case, it is appropriate to provide indications to the user about what text is
# marked as conditional and which conditions apply.
#

sub apiConditionDoc
    {
    my @inLines   = @_;
    my @outLines  = ();

    foreach $line (@inLines)
        {
        if ( $line =~ /^(.*)$v\\IFSET\s+(.*)/ )
            {
            push @outLines, "$1$v\\h IFSET";
            push @outLines, "$1${v}Routine documentation is conditional" . 
                " -- Conditions: $2.";
            }
        elsif ( $line =~ /^(.*)$v\\IFSET_START\s+(.*)/ )
            {
            push @outLines, "$1$v\[\[$2\[\[";
            }
        elsif ( $line =~ /^(.*)$v\\IFSET_END(\s+(.*))?$/ )
            {
            push @outLines, "$1$v\]\]$3\]\]";
            }
        else
            {
            push @outLines, $line;
            }
        }

    return @outLines;
    }


###############################################################################
#
# apiConditionApply - remove conditional text appropriately
#
# This routine handles the IFSET_START and IFSET_END directives.
# Text is kept or removed depending on the specified conditions.  Because of
# the directives that can pull in text from other files, it is necessary to
# handle nested conditions.

sub apiConditionApply
    {
    my @inLines   = @_;
    my @outLines  = ();
    my @nestStack = ();
    my $keepFlag  = 1;

    foreach $line (@inLines)
        {
        if ( $line =~ /^(.*)$v\\IFSET_START\s+(.*)$/ )
            {
            my $loc = $1;
            my @condList = split /\s+/, $2;
            my $newFlag = 0;

            foreach $cond (@condList)
                {
                if ( grep /^$cond$/, @::optionConditions )
                    {
                    $newFlag = 1;
                    last;
                    }
                }

            push @nestStack, $keepFlag;
            $keepFlag &&= $newFlag;

            if ( ! $keepFlag && $::optionInternal )
                {
                # print unselected conditional text with indicator

                push @outLines, "$loc$v\[\[$1\[\[";
                }
            }
        elsif ( $line =~ /^(.*)$v\\IFSET_END(\s+(.*))?$/ )
            {
            if ( ! $keepFlag && $::optionInternal )
                {
                push @outLines, "$1$v\]\]$2\]\]";
                }

            if ( @nestStack )
                {
                $keepFlag = pop @nestStack;
                }
            else
                {
                if ( ! $isNomanual || $::optionInternal )
                    {
                    print STDERR "$1: ERROR: more IFSET_ENDs than STARTs\n";
                    $::errorStatus = 1;
                    }
                elsif ( ! $::isWarned )
                    {
                    ::apiPrintWarning();
                    }
                }
            }
        elsif ( $line =~ /$v\\IFSET\s/ )
            {
            # eliminate the \IFSET directives now unless -internal
            }
        elsif ( $keepFlag || $::optionInternal )
            {
            push @outLines, $line;
            }
        }

    if ( @nestStack )
        {
        if ( ! $isNomanual || $::optionInternal )
            {
            $line =~ /^(.*)$v/o;
            print STDERR "$1: ERROR: more IFSET_STARTs than ENDs\n";
            $::errorStatus = 1;
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }
        }

    return @outLines;
    }


###############################################################################
#
# apiSectionGet - convert a section of text, including the section heading
#
# This routine reads a single section of text and returns the XML generated
# from that text.  Sections with certain names are given special treatment
# by other subroutines, as are certain paragraph types.
#

sub apiSectionGet
    {
    $line = shift @entryLines;
    $line = shift @entryLines while ( @entryLines and $line =~ /$v\s*$/o );

    return () if ($line =~ /$v\s*$/o and not @entryLines);

    $line =~ /^(.*)$v/o;
    my $loc= $1;
    my $heading = "DESCRIPTION";  # Only first section can be without a heading
    if ( $line =~ /$v\\h\s+(.*)/ )
        {
        $heading = $1;
        @sectionLines = ("$loc$v<$::tagSection>");
        }
    elsif ( $line =~ /$v\\(INTERNAL)$/ )
        {
        $heading = $1;
        @sectionLines = ("$loc$v<$::tagSection scope=\"internal\">");
        }
    elsif ( $line =~ /$v\\(INTERNAL)\s*(.*)/ )
        {
        $heading = "$2 (internal)";
        @sectionLines = ("$loc$v<$::tagSection scope=\"internal\">");
        }
    elsif ( $line =~ /$v\\NOMANUAL/ )
        {
        return ();
        }
    elsif ( $line =~ /$v\\COMMAND/ )
        {
	  $::optionCommand = '1';	 # sets the optionCmd value to 'true'
          return ();                               # for one section   
        }


   elsif ( $line =~ /$v\\NOROUTINES/ )
        {
        if ( $entryIsRoutine )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: WARNING: NOROUTINES not legal" .
                        " in routine section\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            }
        else
            {
            $isNoroutines = 1;
            }
        return ();
        }
    elsif ( $line =~ /$v\\TITLE/ ) # TITLE only used in library section
	{
	if ( $line !~ /$v\\TITLE\s+([^-]*?)\s+-\s+(.*)/ )
	    {
	    print STDERR "$loc: ERROR: indecipherable TITLE directive\n";
	    return ();
	    }

        if ( $entryIsRoutine )
            {
            print STDERR "$loc: ERROR: TITLE directive not legal in routine\n";
            $::errorStatus = 1;
            }
        else
            {
            $name = $1;
            $desc = $2;
            }
	return ();
        }
    else
        {
        unshift @entryLines, $line;
        @sectionLines = ("$loc$v<$::tagSection>");
        }

    # certain sections require special treatment

    $heading =~ s/\s+$//;

    if ( $heading =~ /^(SYNOPSIS|INPUT)\s*$/ )
        {
        apiSynopsisGet($heading);
        return ();
        }

    if ( $heading =~ /^INCLUDE[\sA-Z]*$/ )
        {
        apiIncludesGet($heading);
        return ();
        }

    if ( $heading =~ /^SEE\s+ALSO\s*$/ )
        {
        apiSeeAlsoGet($heading);
        return ();
        }

    if ( $heading =~ /^RETURNS\s*$/ )
        {
        push @returnsLines, "$loc$v<$::tagReturns>";
        push @returnsLines, apiNormalSectionGet($heading);
        push @returnsLines, "$loc$v</$::tagReturns>";
        return ();
        }

    if ( $heading =~ /^(ERRNO|ERRNOS|ERROR|ERRORS)\s*$/ )
        {
        my $index = 0;
	my $nextLine = $entryLines[$index];
        while ( $nextLine =~ /$v\s*$/ )
            {
            $index++;
            $nextLine = $entryLines[$index];
            }

	# if section starts with an errno code, reformat it --
        # otherwise, treat it as an ordinary section

	if ( $nextLine =~ /$v\s*<$::tagConstant>/ )
	    {
	    apiErrnoGet($heading);
	    }
        else
            {
            push @errnoLines, apiNormalSectionGet($heading);
            push @errnoLines, "$loc$v</$::tagErrno>";
            }

        return ();
        }

    if ( $heading =~ /^NAME$/ )
	{
        if ( ! $isNomanual || $::optionInternal )
            {
	    print STDERR "$loc: WARNING: $heading section ignored in $name\n";
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }
	apiSectionSkip();
	return ();
	}

    # the section is not special -- handle it normally

    push @sectionLines, apiNormalSectionGet($heading);
    push @sectionLines, "$loc$v</$::tagSection>";

    return @sectionLines;
    }


###############################################################################
#
# apiNormalSectionGet - format a section that is not special
#
# This routine reads a non-special section and returns its formatted text.
#

sub apiNormalSectionGet
    {
    my @outLines = ();
    my $heading = shift;
    $entryLines[0] =~ /^(.*)$v/o;
    my $firstLoc = $1;

    push @outLines, "$firstLoc$v<$::tagHeading>$heading</$::tagHeading>";

    while ( @entryLines )
        {
        # skip blank lines

        my $line = shift @entryLines;
        next if $line =~ /$v\s*$/;

        $line =~ /^(.*)$v/o;
        my $loc = $1;

        # quit if a new heading is found

        if ( $line =~ /$v\\(h\s|$::legalDirectives)/ )
            {
	    if ( $loopCount > $loopMax )
		{
		print STDERR "$loc: INTERNAL ERROR: infinite loop - " .
		             "unhandled directive?\n->$line\n";
		$loopCount = 0;
		last;
		}

	    $loopCount++;
            unshift @entryLines, $line;
            last;
            }
	$loopCount = 0;

        # figure out next paragraph type

        if ( $line =~ /$v\\sh\s/ )
            {
            # subheading

            unshift @entryLines, $line;
            push @outLines, apiSubheadGet();
            }
        elsif ( $line =~ /$v\\cs($|\s)/ )
            {
            # code display

            push @outLines, apiCodeGet();
            }
        elsif ( $line =~ /$v\\bs($|\s)/ )
            {
            # smaller code display

            push @outLines, apiCodeSmallGet();
            }
        elsif ( $line =~ /$v\\ss($|\s)/ )
            {
            # preformatted text display

            push @outLines, apiDisplayGet();
            }
        elsif ( $line =~ /$v\\is($|\s)/ )
            {
            # itemized list

            push @outLines, apiIListGet();
            }
        elsif ( $line =~ /$v\\(ms|ml)($|\s)/ )
            {
            # marker list

            push @outLines, apiMListGet();
            }
        elsif ( $line =~ /$v\\ts($|\s)/ )
            {
            # table

            push @outLines, apiTableGet();
            }
        elsif ( $line =~ /$v\\IMAGE\s+(\S+)\s*$/ )
            {
            # image file

            $imageName = $1;
            $imageName =~ s/<[^>]+>//g; # remove any automated markup
            push @outLines, "$loc$v<$::tagPara>";
            push @outLines, "$loc$v<$::tagImage src=\"$imageName\" />";
            push @outLines, "$loc$v</$::tagPara>";
            }
        elsif ( $line =~ /$v\\/ )
            {
            # unknown markup

            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: misplaced or invalid markup in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            push @outLines, $line;
            }
        else
            {
            # ordinary paragraph (default)

            unshift @entryLines, $line;
            push @outLines, apiParaGet();
            }
        }

    return @outLines;
    }


###############################################################################
#
# apiSubHeadGet - convert a section subheading
#
# This routine reads a section of text known to be a subheading and returns
# the XML generated from that text.
#

sub apiSubheadGet
    {
    my $shLine = shift @entryLines;

    $shLine =~ /^(.*)$v\\sh\s+(.*)$/;
    my $loc = $1;
    my $subhead = $2;
    return "$loc$v<$::tagSubheading>$subhead</$::tagSubheading>";
    }


###############################################################################
#
# apiCodeGet - convert a section of code
#
# This routine reads a section of text marked as code, and returns
# the XML generated from that text.  The first line read is the first line
# of code, as the marker for the code section has already been read.  Since
# all the essential substitutions have already been made, this section just
# copies the input lines to the output.
#

sub apiCodeGet
    {
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;
    my @outLines = ("$loc$v<$::tagCode>");

    while (1)
        {
        my $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        last if $line =~ /$v\\ce/;

        if ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: code section not closed in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            unshift @entryLines, $line;
            last;
            }

        push @outLines, $line;

        if ( not @entryLines )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: text ended in code section in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            last;
            }
        }

    push @outLines, "$loc$v</$::tagCode>";

    return @outLines;
    }


###############################################################################
#
# apiCodeSmallGet - convert a section of small code
#
# This routine reads a section of text marked as small code, and returns
# the XML generated from that text.  The first line read is the first line
# of code, as the marker for the code section has already been read.  Since
# all the essential substitutions have already been made, this section just
# copies the input lines to the output.
#

sub apiCodeSmallGet
    {
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;
    my @outLines = ("$loc$v<$::tagCodesmall>");

    while (1)
        {
        my $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        last if $line =~ /$v\\be$/;

        if ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: small code section not closed in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            unshift @entryLines, $line;
            last;
            }

        push @outLines, $line;

        if ( not @entryLines )
            {
            if ( ! $inNomanual )
                {
                print STDERR "$loc: ERROR: text ended in small code" .
                        " section in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            last;
            }
        }

    push @outLines, "$loc$v</$::tagCodesmall>";

    return @outLines;
    }


###############################################################################
#
# apiDisplayGet - convert a section of preformatted text
#
# This routine reads a section of text marked as preformatted, and returns
# the XML generated from that text.  The first line read is the first line
# of text, as the marker for the section has already been read.  Since
# all the essential substitutions have already been made, this section just
# copies the input lines to the output.
#

sub apiDisplayGet
    {
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;
    my @outLines = ("$loc$v<$::tagDisplay>");

    while (1) {
        my $line = shift @entryLines;
        last if $line =~ /$v\\se$/;

        if ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: display section not closed in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            unshift @entryLines, $line;
            last;
            }

        push @outLines, $line;

        if ( not @entryLines )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: text ended in display section in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            last;
            }
        }

    push @outLines, "$loc$v</$::tagDisplay>";

    return @outLines;
    }


###############################################################################
#
# apiIListGet - convert an itemized list
#
# This routine reads a section of text marked as an itemized list, and returns
# the XML generated from that text.  The first line read should be the first
# item name line, as the marker for the section has already been read.  Since
# all the essential substitutions have already been made, this section just
# copies the input lines to the output.
#

sub apiIListGet
    {
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;
    my @outLines = ("$loc$v<$::tagItemlist>");

    my $line = shift @entryLines;
    while ( @entryLines )
        {
        # skip blank lines outside of marked text

        $line = shift @entryLines while $line =~ /$v\s*$/;

        $line =~ /^(.*)$v/o;
        $loc = $1;

        # get item name

        my $itemName = "";
        if ( $line =~ /$v\\i\s+\"(.*)\"\s*$/ )
            {
            $itemName = $1;
            }
        elsif ( $line =~ /$v\\i\s+(.*?)\s*:\s+(\S.*)$/ )
            {
            $itemName = $1;
            unshift @entryLines, "$loc$v$2";
            }
        elsif ( $line =~ /$v\\i\s+(\S.*)$/ )
            {
            $itemName = $1;
            }
        elsif ( $line =~ /$v\\i\s*$/ )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: empty item in item list\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            }
        elsif ( $line =~ /$v\\ie\s*$/ )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: emtpy item list in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            last;
            }
        else
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: no item name in item list for $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            unshift @entryLines, $line;
            }

        push @outLines, "$loc$v<$::tagItem>$itemName</$::tagItem>";
        push @outLines, "$loc$v<$::tagItemtext>";

        # get item text

        my $inPara = 0;
        while ( @entryLines )
            {
            $line = shift @entryLines;
            next if $line =~ /$v\s*$/;

            $line =~ /^(.*)$v/o;
            $loc = $1;

            last if $line =~ /$v\\i\s/;
            last if $line =~ /$v\\ie\s*$/;

            if ( $line =~ /$v\\cs($|\s)/ )
                {
                # code display

                push @outLines, apiCodeGet();
                }
            elsif ( $line =~ /$v\\bs($|\s)/ )
                {
                # smaller code display

                push @outLines, apiCodeSmallGet();
                }
            elsif ( $line =~ /$v\\ss($|\s)/ )
                {
                # preformatted text display

                push @outLines, apiDisplayGet();
                }
            elsif ( $line =~ /$v\\is($|\s)/ )
                {
                # itemized list

                push @outLines, apiIListGet();
                }
            elsif ( $line =~ /$v\\(ms|ml)($|\s)/ )
                {
                # marker list

                push @outLines, apiMListGet();
                }
            elsif ( $line =~ /$v\\ts($|\s)/ )
                {
                # table

                push @outLines, apiTableGet();
                }
            elsif ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
                {
                if ( ! $isNomanual || $::optionInternal )
                    {
                    print STDERR "$loc: ERROR: item list not closed for $name\n";
                    $::errorStatus = 1;
                    }
                elsif ( ! $::isWarned )
                    {
                    ::apiPrintWarning();
                    }
                last;
                }
            else
                {
                # ordinary paragraph

                unshift @entryLines, $line;
                push @outLines, apiParaGet();
                }
            }

        # end or get ready for next item

        push @outLines, "$loc$v</$::tagItemtext>";

        if ( $line =~ /$v\\i\s/ )
            {
            }
        elsif ( $line =~ /$v\\ie\s*$/ )
            {
            last;
            }
        elsif ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
            {
	    if ( $loopCount > $loopMax )
		{
		print STDERR "$loc: INTERNAL ERROR: infinite loop in item" .
                        " list for $name\n";
		$loopCount = 0;
		last;
		}

	    $loopCount++;
            unshift @entryLines, $line;
            last;
            }
        }

    push @outLines, "$loc$v</$::tagItemlist>";

    return @outLines;
    }


###############################################################################
#
# apiTableGet - convert a table
#
# This routine reads a section of text marked as a table, and returns
# the XML generated from that text.  Each line represents a single table row.
# Since all the essential substitutions have already been made, this section
# can assume that all the vertical bars represent cell divisions.
#

sub apiTableGet
    {
    @entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    my @outLines = ("$loc$v<$::tagTable columns=\"0\">");
    my $maxColCount = 0;
    my $marker = chr 129;
    my $cellTag = $marker; # header cells before hr only if hr is present
    my $subTag  = $::tagCell;

    while ( @entryLines )
        {
        my $line = shift @entryLines;
        next if $line =~ /$v\s*$/;

        $line =~ /^(.*)$v/o;
        $loc = $1;

        last if $line =~ /$v\\te\s*$/;

        if ( $line =~ /$v\\($allMarks)(\s.*)?$/o )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: table not closed in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            unshift @entryLines, $line;
            last;
            }

        # count number of columns

        my @matches = $line =~ /\|/g;
        my $colCount = scalar(@matches) + 1;
        if ( $colCount > $maxColCount )
            {
            $maxColCount = $colCount;
            }

        if ( $line =~ /$v-[-+|]*\s*$/ )
            {
            push @outLines, "$loc$v<span><$::tagRule/></span>";
            $cellTag = $::tagCell;
            $subTag  = $::tagHcell;
            }
        else
            {
            # put something in empty cell at end of line

            $line =~ s/\|$/| /;

            # split cells and output one cell per line

            $line =~ s/^.*$v//o;
            @cellEntries = split /\|/, $line;

            push @outLines, "$loc$v<$::tagRow>";
            foreach $cell (@cellEntries)
                {
                $cell =~ /^\s*(.*?)\s*$/;
                $cell = $1;
                push @outLines, "$loc$v<$cellTag>$cell</$cellTag>";
                }
            push @outLines, "$loc$v</$::tagRow>";
            }
        }

    # put in header cells only if there was a divider

    foreach (@outLines)
        {
        s/$marker/$subTag/go;
        }

    # correct the number of columns

    my $line = shift @outLines;
    $line =~ s/\"0\"/\"$maxColCount\"/;
    unshift @outLines, $line;
    push @outLines, "$loc$v</$::tagTable>";

    return @outLines;
    }


###############################################################################
#
# apiParaGet - convert an ordinary text paragraph
#
# This routine reads a section of text marked (implicitly) as a simple
# paragraph, and returns the XML generated from that text.  Lines are copied
# verbatim.  Unlike other paragraph types, plain paragraphs are ended by a
# blank line.
#

sub apiParaGet
    {
    @entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    my @outLines = ("$loc$v<$::tagPara>");
    my $inList;  # leading spaces imply keep spacing and line breaks

    # process up to next section or blank line

    while ( @entryLines )
        {
        my $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        last if $line =~ /$v\s*$/;

        if ( $line =~ /$v\s/ )
            {
            if ( (! $inList) and (scalar @outLines) > 1 )
                {
                my $prevLine = pop @outLines;
                $prevLine .= "<br/>";
                push @outLines, $prevLine;
                }
            $line =~ s/\s/&nbsp;/g;
            $line .= "<br/>";
            $inList = 1;
            }
        else
            {
            $inList = 0;
            }

        if ( $entryIsRoutine )
            {
            if ( $line =~ /$v\\NOMANUAL/ )
                {
                unshift @entryLines, $line;
                last;
                }
            }
        else
            {
            if ( $line =~ /$v\\NOROUTINES/ )
                {
                unshift @entryLines, $line;
                last;
                }
            }

	# any kind of markup indicates a new paragraph (or section)

        if ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
            {
            if ($loopCount > $loopMax )
                {
                print STDERR "$loc: INTERNAL ERROR: infinite loop in" .
                        " paragraph for $name\n";
                $loopCount = 0;
                }
            else
                {
                $loopCount++;
                unshift @entryLines, $line;
                }
            last;
            }

        push @outLines, $line;
        }

    push @outLines, "$loc$v</$::tagPara>";

    return @outLines;
    }


###############################################################################
#
# apiMListGet - convert an itemized list
#
# This routine reads a section of text marked as an itemized list, and returns
# the XML generated from that text.  The first line read should be the first
# item name line, as the marker for the section has already been read.  Since
# all the essential substitutions have already been made, this section just
# copies the input lines to the output.
#

sub apiMListGet
    {
    @entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    my @outLines = ("$loc$v<$::tagMarkerlist>");

    my $line = shift @entryLines;
    while ( @entryLines )
        {
        # skip empty lines outside of marked text

        $line = shift @entryLines while $line =~ /$v\s*$/;

        $line =~ /^(.*)$v/o;
        $loc = $1;

        # get marker

        my $marker = "";
        if ( $line =~ /$v\\m\s+\"(.*)\"\s*$/ )
            {
            $marker = $1;
            }
        elsif ( $line =~ /$v\\m\s+(.*?)\s*:\s+(\S.*)$/ )
            {
            $marker = $1;
            unshift @entryLines, "$loc$v$2";
            }
        elsif ( $line =~ /$v\\m\s+(\S+)\s+(\S.*)$/ )
            {
            $marker = $1;
            unshift @entryLines, "$loc$v$2";
            }
        elsif ( $line =~ /$v\\m\s+(\S.*)$/ )
            {
            $marker = $1;
            }
        elsif ( $line =~ /$v\\m\s*$/ )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: empty marker in marker list\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            }
        elsif ( $line =~ /$v\\me\s*$/ )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: emtpy marker list in $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            last;
            }
        else
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: no marker in marker list $name\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            }

        push @outLines, "$loc$v<$::tagMarker>$marker</$::tagMarker>";
        push @outLines, "$loc$v<$::tagMarkertext>";

        # get text

        while ( @entryLines )
            {
            $line = shift @entryLines;
            next if $line =~ /$v\s*$/;

            $line =~ /^(.*)$v/o;
            $loc = $1;

            last if $line =~ /$v\\m\s/;
            last if $line =~ /$v\\me\s*$/;

            if ( $line =~ /$v\\cs($|\s)/ )
                {
                # code display

                push @outLines, apiCodeGet();
                }
            elsif ( $line =~ /$v\\bs($|\s)/ )
                {
                # smaller code display

                push @outLines, apiCodeSmallGet();
                }
            elsif ( $line =~ /$v\\ss($|\s)/ )
                {
                # preformatted text display

                push @outLines, apiDisplayGet();
                }
            elsif ( $line =~ /$v\\is($|\s)/ )
                {
                # itemized list

                push @outLines, apiIListGet();
                }
            elsif ( $line =~ /$v\\(ms|ml)($|\s)/ )
                {
                # marker list

                push @outLines, apiMListGet();
                }
            elsif ( $line =~ /$v\\ts($|\s)/ )
                {
                # table

                push @outLines, apiTableGet();
                }
            elsif ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
                {
                if ( ! $isNomanual || $::optionInternal )
                    {
                    print STDERR "$loc: ERROR: marker list not closed in $name\n";
                    $::errorStatus = 1;
                    }
                elsif ( ! $::isWarned )
                    {
                    ::apiPrintWarning();
                    }
                last;
                }
            else
                {
                # ordinary paragraph

                unshift @entryLines, $line;
                push @outLines, apiParaGet();
                }
            }

        # end or get ready for next marker

        push @outLines, "$loc$v</$::tagMarkertext>";

        if ( $line =~ /$v\\m\s/ )
            {
            }
        elsif ( $line =~ /$v\\me\s*$/ )
            {
            last;
            }
        elsif ( $line =~ /$v\\($allMarks|$sectionEnds)(\s.*)?$/o )
            {
            if ($loopCount > $loopMax )
                {
                print STDERR "$loc: INTERNAL ERROR: infinite loop in" .
                        " marker list within $name\n";
                $loopCount = 0;
                }
            else
                {
                $loopCount++;
                unshift @entryLines, $line;
                }
            last;
            }
        }

    push @outLines, "$loc$v</$::tagMarkerlist>";

    return @outLines;
    }

#------------------------------------
#
# routines for specialized sections
#
#------------------------------------

###############################################################################
#
# apiSynopsisGet - process a synopsis (prototype) section
#
# This routine reads a section of text with the heading "SYNOPSIS".  Since
# synopsis sections are preformatted, the processing is minimal.
#

sub apiSynopsisGet
    {
    my $heading = shift;
    my $line = $entryLines[0];
    $line =~ /^(.*)$v/o;
    my $loc = $1;

    @synopsisLines = ();
    push @synopsisLines, "$loc$v<$::tagSynopsis>";
    push @synopsisLines, "$loc$v<$::tagHeading>$heading</$::tagHeading>";

    while ( @entryLines )
        {

        # copy lines until next section

        $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        if ( $line =~ /$v\\($sectionEnds)/ )
            {
            unshift @entryLines, $line;

            # if a last line is blank, delete it

            $line = pop @synopsisLines;
            if ( not $line =~ /$v\s*$/ )
                {
                push @synopsisLines, $line;
                }

            last;
            }
        elsif ( $line =~ /$v\\cs/ )
            {
            push @synopsisLines, "$loc$v<$::tagCode>";
            }
        elsif ( $line =~ /$v\\ce/ )
            {
            push @synopsisLines, "$loc$v</$::tagCode>";
            }
        elsif ( $line =~ /$v\\ss/ )
            {
            push @synopsisLines, "$loc$v<$::tagDisplay>";
            }
        elsif ( $line =~ /$v\\se/ )
            {
            push @synopsisLines, "$loc$v</$::tagDisplay>";
            }
        else
            {
            push @synopsisLines, $line;
            }
        }

    push @synopsisLines, "$loc$v</$::tagSynopsis>";

    if ( ($heading eq "INPUT") and ($entryLines[0] =~ /$v\\h\s+OUTPUT\s*$/) )
        {
        $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        push @synopsisLines, "$loc$v<$::tagSection>";
        push @synopsisLines, "$loc$v<$::tagHeading>OUTPUT</$::tagHeading>";

        while ( @entryLines )
            {

            # copy lines until next section

            $line = shift @entryLines;
            $line =~ /^(.*)$v/o;
            $loc = $1;

            if ( $line =~ /$v\\($sectionEnds)/ )
                {
                unshift @entryLines, $line;

                # if a line is blank, delete it

                $line = pop @synopsisLines;
                if ( not $line =~ /$v\s*$/ )
                    {
                    push @synopsisLines, $line;
                    }

                last;
                }
            elsif ( $line =~ /$v\\cs/ )
                {
                push @synopsisLines, "<$loc$v$::tagCode>";
                }
            elsif ( $line =~ /$v\\ce/ )
                {
                push @synopsisLines, "$loc$v</$::tagCode>";
                }
            elsif ( $line =~ /$v\\ss/ )
                {
                push @synopsisLines, "$loc$v<$::tagDisplay>";
                }
            elsif ( $line =~ /$v\\se/ )
                {
                push @synopsisLines, "$loc$v</$::tagDisplay>";
                }
            else
                {
                push @synopsisLines, $line;
                }
            }

        push @synopsisLines, "$loc$v</$::tagSection>";
        }
    }


###############################################################################
#
# apiIncludesGet - process an INCLUDES section
#
# This routine reads a section of text with the heading "INCLUDES".  Since
# includes sections contain only lists of header files, which should already
# be marked as bold, the formatting does nothing but ensure that the list is
# delimited by commas.
#

sub apiIncludesGet
    {
    my $heading = shift;
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    @includesLines = ("$loc$v<$::tagIncludes>");
    push @includesLines, "$loc$v<$::tagHeading>$heading</$::tagHeading>";
    push @includesLines, "$loc$v<$::tagPara>";

    my @inLines = ();

    while ( @entryLines )
        {

        # copy lines until next section

        my $line = shift @entryLines;

        if ( $line =~ /$v\\($sectionEnds)/ )
            {
            unshift @entryLines, $line;
            last;
            }
        else
            {
            push @inLines, $line;
            }
        }

    grep s/^.*$v//o, @inLines; # remove line numbers;
    my $inText = join ', ', @inLines;
    $inText =~ s/,(\s*,)+/,/g; # remove empty list elements
    $inText =~ s/^[\s,]+//; # remove empty starting elements
    $inText =~ s/[\s,]+$//; # remove empty final commas
    $inText =~ s/,\s*/, /g;    # regularize post-comma spaces
    $inText = "$loc$v" . $inText;

    push @includesLines, $inText;
    push @includesLines, "$loc$v</$::tagPara>";
    push @includesLines, "$loc$v</$::tagIncludes>";
    }


###############################################################################
#
# apiSeeAlsoGet - process a SEE ALSO section
#
# This routine reads a section of text with the heading "SEE ALSO".  Since
# includes sections contain only lists of references, the formatting does
# nothing but ensure that the list is delimited by commas.
#

sub apiSeeAlsoGet
    {
    my $heading = shift;
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    @seeAlsoLines = ("$loc$v<$::tagSeealso>");
    push @seeAlsoLines, "$loc$v<$::tagHeading>$heading</$::tagHeading>";
    push @seeAlsoLines, "$loc$v<$::tagPara>";

    my @inLines = ();

    while ( @entryLines )
        {

        # copy lines until next section

        my $line = shift @entryLines;

        if ( $line =~ /$v\\($sectionEnds)/ )
            {
            unshift @entryLines, $line;
            last;
            }
        else
            {
	    # The following IF-statement 'treats' SEE ALSO section for TCL scripts
	    # it will generally bold anything that hasn't been bolded / italicized
	    # the $::isTcl is declared in apigen.pl and is activated at apigen1.pl
	    
	    if ($::isTcl)
	      {
	       $openSEEALSO;       ## part that tells it's OPEN (non-zero) or CLOSED (empty)
	       $locSEEALSO;        ## part which contains "$loc" 
	                           ## (location, line number,and $v value)
	       $withoutLocSEEALSO;   ## part without the "$loc" part
	    
	       if ( $line =~ /(.*$v)(.*)/)
	         {
		  $locSEEALSO = $1;   ## part which contains "$loc" 
		                        ##(location line number etc and $v value)
	          $withoutLocSEEALSO = $2; # part without the "$loc" part
	    	 }
		
	       ## split into arrays if there's  comma and space
	       @arrayWithoutLoc = split (/, /,$withoutLocSEEALSO);
	        
	       $ResultLineSEEALSO = "";  ## the modified version put together
	    
	       $withoutLocSEEALSO = "";  ## reusing the variable name(below)
	    
	       foreach $withoutLocSEEALSO (@arrayWithoutLoc)
	     	 {
  # check if it's 'OPEN' or 'CLOSED'
  # this had to be done for situations where $withoutLocSEEALSO is
  # <i>something, something1, something2, something3<\i>
  # and make sure that all of them are in their own format.
  # OPEN happens when the $withoutLocSEEALSO starts with < but doesn't end with >
  # commas are ignored because @arrayWithoutLoc is splited by ", "
  # The state becomes CLOSED when there's > in the end without < in the front
  # Usually, the system ($openSEEALSO) is CLOSED.
		  
		  if ($withoutLocSEEALSO =~ /^[<](.*)/ && 
		         $withoutLocSEEALSO =~ /(.*)[^>]$/)
			{
			 $openSEEALSO = '1';  ## it's open
			}
		  elsif($withoutLocSEEALSO =~ /[^<](.*)/ && 
		         $withoutLocSEEALSO =~ /(.*)[>]$/)
		        {
			 $openSEEALSO = "";   ## closed
			}
		
		  # if the part exist and it's not N/A 	
		  if ($withoutLocSEEALSO && $withoutLocSEEALSO =~ /^[^<](.*)/  && 
	                !($withoutLocSEEALSO =~ /\s*N\/?A\s*$/) && 
		        $withoutLocSEEALSO =~ /(.*)[^>]$/ )
		    {
		    
		     if (!$openSEEALSO)   ## When closed
		         {
		          $ResultLineSEEALSO .= "<b>$withoutLocSEEALSO</b>,";
		         }
		     else
		         {        ##OPEN  concatenate them w/o bolding 
			  $ResultLineSEEALSO .= "$withoutLocSEEALSO,";   
		         }
		     
		    }
		  # if it's already bolded just concatenate it
		  # make sure there's no N/A in in SEE ALSO
		  elsif (!($withoutLocSEEALSO =~ /\s*N\/?A\s*$/))               
		    {                        
		     $ResultLineSEEALSO .= "$withoutLocSEEALSO,";	
		    }
		    
		  }   ## END OF FOREACH LOOP
	
		$line = "$locSEEALSO$ResultLineSEEALSO";
	    	
		}  ## END of isTCL IF-STATEMENT
		
            push @inLines, $line;
            }
        }

    # add the current library to the SEE ALSO list

    if ( $entryIsRoutine and not (grep />$libraryName</, @inLines) )
        {
        unshift @inLines, "$loc$v<$::tagLibrary>$libraryName<\/$::tagLibrary>";
        }

    grep s/^.*$v//, @inLines;   # remove line numbers
    my $inText = join ', ', @inLines;
    $inText =~ s/,(\s*,)+/,/g; # remove empty list elements
    $inText =~ s/^[\s,]+//; # remove empty starting elements
    $inText =~ s/[\s,]+$//; # remove empty final commas
    $inText =~ s/,\s*/, /g; # regularize post-comma spaces
    $inText = "$loc$v" . $inText;

    push @seeAlsoLines, $inText;
    push @seeAlsoLines, "$loc$v</$::tagPara>";
    push @seeAlsoLines, "$loc$v</$::tagSeealso>";
    }


###############################################################################
#
# apiReturnsGet - process a RETURNS section
#
# This routine reads a section of text with the heading "RETURNS".  Since
# these sections should already be formatted, this routine does little.
# 
# NOTE: This routine is no longer used.  It is kept in case we change our
# minds about formatting RETURNS sections as normal sections.
#

sub apiReturnsGet
    {
    my $heading = shift;
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    @returnsLines = ("$loc$v<$::tagReturns>");
    push @returnsLines, "$loc$v<$::tagHeading>$heading</$::tagHeading>";
    push @returnsLines, "$loc$v<$::tagPara>";

    while ( @entryLines )
        {

        # copy lines until next section

        my $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        if ( $line =~ /$v\\($sectionEnds)/ )
            {
            unshift @entryLines, $line;
            last;
            }
        else
            {
            # remove blank lines and leading spaces

            next if $line =~ /$v\s*$/;
            $line =~ s/$v\s+/$v/;
            $line .= "<$::tagBreak/>";
            push @returnsLines, $line;
            }
        }

    # remove last break

    my $line = pop @returnsLines;
    $line =~ s/<$::tagBreak\/>//;
    push @returnsLines, $line;

    push @returnsLines, "$loc$v</$::tagPara>";
    push @returnsLines, "$loc$v</$::tagReturns>";
    }


###############################################################################
#
# apiErrnoGet - process an ERRNOS section
#
# This routine reads a section of text with the heading "ERRNO" or "ERROR."
# This is complicated by the two formats used for errnos.  Both of these
# formats must be put into the form of each errno code starting a line,
# perhaps followed by a description.
#

sub apiErrnoGet
    {
    my $heading = shift;
    $entryLines[0] =~ /^(.*)$v/o;
    my $loc = $1;

    @errnoLines = ("$loc$v<$::tagErrno>");
    push @errnoLines, "$loc$v<$::tagHeading>$heading</$::tagHeading>";
    push @errnoLines, "$loc$v<$::tagPara>";

    my @inLines = ();

    while ( @entryLines )
        {

        # copy lines until next section

        my $line = shift @entryLines;
        $line =~ /^(.*)$v/o;
        $loc = $1;

        if ( $line =~ /$v\\($sectionEnds)/ )
            {
            unshift @entryLines, $line;
            last;
            }
        elsif ( not $line =~ /$v\s*$/ )
            {
            $line =~ s/$v\s*(.*?)\s*$/$v\1/;
            push @inLines, $line;
            }
        }

    # if the section consists only of "N/A", format this properly and
    # return immediately

    if ( scalar(@inLines) == 1 )
        {
        my $line = $inLines[0];

        if ( $line =~ /$v\s*N\/?A\s*$/ )
            {
            push @errnoLines, "$loc${v}N/A";
            push @errnoLines, "$loc$v</$::tagPara>";
            push @errnoLines, "$loc$v</$::tagErrno>";
            return;
            }
        }

    # mark the start of each errno code description

    my $mark = chr 129;
    foreach (@inLines)
        {
        s/\s*(<$::tagConstant>)/$mark\1/og;
        }

    grep s/^.*$v//, @inLines;  # remove line numbers
    my $inText = join ' ', @inLines;
    $inText =~ s/^$mark//o;
    $inText =~ s/,?\s*($mark)/\1/og;
    $inText =~ s/\s\s+/ /g;
    $inText =~ s/\s+-\s+/ &endash; /g;
    $inText =~ s/($mark)/<$::tagBreak\/>\1/og;

    @inLines = split /$mark/, $inText;
    grep s/^/$loc$v/, @inLines;  # add back best line number available

    push @errnoLines, @inLines;
    push @errnoLines, "$loc$v</$::tagPara>";
    push @errnoLines, "$loc$v</$::tagErrno>";
    }


###############################################################################
#
# apiSectionSkip - skip over a section
#
# This routine reads a section of text with a forbidden heading.
# No output is produced.
#

sub apiSectionSkip
    {

    while ( @entryLines )
        {

        # skip lines until next section

        my $line = shift @entryLines;

        if ( $line =~ /$v\\($sectionEnds)/ )
            {
            unshift @entryLines, $line;
            last;
            }
        }
    }

1;  # ugly necessity for putting this file in 'require' directive
