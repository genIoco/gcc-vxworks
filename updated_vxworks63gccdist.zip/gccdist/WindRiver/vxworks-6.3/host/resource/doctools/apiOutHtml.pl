# apiOutHtml.pl - produce HTML or XHTML output format from internal XML
#
# Copyright (c) 2003-2005 Wind River Systems, Inc.
#
# The right to copy, distribute, modify or otherwise make use
# of this software may be licensed only pursuant to the terms
# of an applicable Wind River license agreement.
#
# modification history
# --------------------
# 01k,10oct05,lei  generate .rtn file for these with a NOMANUAL directive
#                  in the library header section
# 01j,09aug05,khs  fixed SPR#107289
# 01i,10jan05,lll  Standalone apigen, SPR#105634 and SPR#104090
# 01h,01oct04,wsl  add line numbers to error messages, SPR 93816
# 01g,30sep04,wsl  link to bold routine names, not only known routines
# 01f,24sep04,wsl  more changes in support of style sheets, SPR 102026
# 01e,24sep04,wsl  SPR 101440, fix misaligned marker lists
# 01d,21sep04,wsl  add markup for style sheet, SPR 101587
# 01c,16sep04,wsl  fix SPR 97004, rare spurious HTML output
# 01b,02oct03,jdi  fixed error in line 86: changed tagRoutine to tagLibrary
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This subroutine takes the internal XML and converts it to HTML or XHTML.
#
# NOROUTINES
#

# set the name space

package htmlOut;


###############################################################################
#
# apiGenerate - convert internal XML to HTML or XHTML output
#
# This routine is the master routine for putting the text into HTML
# or XHTML formats.
#



sub apiGenerate
    {
    $v = $::v;

    $singleIndent = "<blockquote>";
    $endIndent    = "</blockquote>";
    $headingSection = "h4";
    $headingLib   = "h1";
    $headingRtn   = "h1";
    $outFileName  = "$::outFileBase.html";
    $htmlTitle    = "";
    
    my ($textLines, $forRtnLines)  = @_;
   
    grep s/^.*$v//o, @$textLines; # eliminate line numbers as no error msgs here

    # lines with internal section for .rtn files

    grep s/^.*$v//o, @$forRtnLines; 

    @outLines = ();

    if ( $::outForm eq "xhtml" )
        {
        $outFileName = "$::outFileBase.xhtml";
        }
    elsif ( $::outForm eq "htmldoc" )
        {
        $headingSection = "b";
        $headingLib     = "h3";
        $headingRtn     = "h4";
        }

     # extract information for .lib and .rtn files

    if ( $::outForm ne "htmldoc" )
        {
	outputFiles($forRtnLines);
        }

    if ( not $::optionInternal )
        {

        # internal sections have already been removed

        @outLines = @$textLines;
        }
    else
        {

        # remove internal markup (simplifies processing, minimizes errors)

        while (@$textLines)
            {
            my $line = shift @$textLines;
            $line =~ s/^(<\w+)\s+scope="internal">/\1>/;
            push @outLines, $line;
            }
        }

    # prevent NAME section from becoming a link
    # also find name of document for HTML title

    my $inName = 0;
    foreach (@outLines)
	{
        if ( /<title>([^<]+)/ )
            {
            $htmlTitle = $1;
            }
	$inName = 0 if /<$::tagHeading>/;
	$inName = 1 if /<$::tagHeading>NAME</;
	if ( $inName && s/<$::tagLibrary>/<strong class="library">/ )
	    {
	    s/<\/$::tagLibrary>/<\/strong>/;
	    }
	elsif ( $inName && s/<$::tagRoutine>/<strong class="routine">/ )
	    {
	    s/<\/$::tagRoutine>/<\/strong>/;
	    }
	}
               
    # add indents and process tables -- @inLines and @outLines reverse roles

    $realIndent = 0;
    $needIndent = 0;

    my $tagsNil    = "$::tagSection|$::tagHeading|$::tagSubheading|" .
                     "$::tagLibname|$::tagRtnname|$::tagLibhead|" .
                     "$::tagRtnhead|$::tagRule";
    my $tagsSingle = "$::tagLibshort|$::tagRtnshort|$::tagRtnlines|" .
                     "$::tagPara|$::tagDisplay|$::tagCode|" .
                     "$::tagCodesmall|$::tagTable|$::tagItemlist|" .
                     "$::tagMarker|$::tagMarkerlist";
    my $tagsReverse = "$::tagItemtext"; # to compensate for other indents

    @inLines = ();
    my $numCols;
    my @nestStack = ();
    while (@outLines)
        {
        my $line = shift @outLines;
        my $changeIndent = 0;

        if ( $line =~ /^<($tagsNil)( .*)?>/o )
            {
            $needIndent = 0;
            $changeIndent = 1;
            }
        elsif ( $line =~ /^<($tagsSingle)( .*)?>/o )
            {
            $needIndent++;
            $changeIndent = 1;
            }
        elsif ( $line =~ /^<\/($tagsReverse)>/o )
            {
            $needIndent++;
            }

        if ( $changeIndent )
            {
            while ( $needIndent > $realIndent )
                {
                push @inLines, $singleIndent;
                $realIndent++;
                }
            while ( $needIndent < $realIndent )
                {
                push @inLines, $endIndent;
                $realIndent--;
                }
            }

        if ( $line =~ /^<$::tagMarkerlist>/ )
            {

            # marker lists are implemented with a table, so require special
            # treatment

            push @nestStack, $realIndent;
            $realIndent = 1;
            $needIndent = 0;
            }
        elsif ( $line =~ /^<\/$::tagMarkerlist>/ )
            {
            $realIndent = pop @nestStack;
            $needIndent = $realIndent;
            }

        if ( $line =~ /<\/($tagsSingle)>/o )
            {
            # note: NOT at start of line

            $needIndent--;
            }
        elsif ( $line =~ /^<($tagsReverse)( .*)?>/o )
            {
            $needIndent--;
            }

        if ( $line =~ /<table columns="(\w+)"/ )
            {
            $numCols = $1;
            }

        if ( $line =~ /<$::tagSpan/o )
            {
            $line =~ s/<$::tagSpan/<$::tagSpan colspan="$numCols"/o;
            }

        push @inLines, $line;
        }

    # remove unneeded lines

    my $tagsRemove = "$::tagApidoc|$::tagLibrarydoc|$::tagRoutinedoc|" .
                     "$::tagLibshort|$::tagLibname|" .
                     "$::tagRtnname|$::tagRtnshort|$::tagRtnline|" .
                     "$::tagSection|$::tagSynopsis|$::tagIncludes|" .
                     "$::tagSeealso|$::tagReturns|$::tagErrno";

    $outLines = ();
    while (@inLines)
        {
        my $line = shift @inLines;

        next if $line =~ /^<\/?($tagsRemove)>/o;

        push @outLines, $line;
        }

    $fullText = join "\n", @outLines;

    # remaining changes can be handled with global replacements

    my $NCRmsg = "No user-callable routines";

    $fullText =~ s/<$::tagLibhead>/<$headingLib class="libhead">/go;
    $fullText =~ s/<\/$::tagLibhead>/<\/$headingLib>/go;
    $fullText =~ s/<$::tagRtnlist blanking="yes">\n<\/blockquote>\n<$::tagHeading>\w*<\/$::tagHeading>\n<blockquote>\n<$::tagRtnlines>\n<\/$::tagRtnlines>\n<\/$::tagRtnlist>\n//go;
    $fullText =~ s/<\/?$::tagRtnlist>\n//go;
    if ( $::outForm eq "htmldoc" )
        {
        $fullText =~ s/<$::tagRtnhead>([^\n]*)<\/$::tagRtnhead>/\n<$headingRtn class="rtnhead">\1<\/$headingRtn>/go;
        }
    else
        {
        $fullText =~ s/<$::tagRtnhead>([^\(\n]*)(\(&nbsp;\))?<\/$::tagRtnhead>/\n<hr\/>\n<a name="\1"><\/a>\n<p align="right"><a href="rtnIndex.htm" class="rtnindex">API Reference: Routines<\/a><\/p>\n<$headingRtn class="rtnhead">\1\2<\/$headingRtn>/go;
        }
    $fullText =~ s/<$::tagRtnlines>\n<\/$::tagRtnlines>/<p>\n$NCRmsg\n<\/p>/go;
    $fullText =~ s/<$::tagRtnlines>/<p>/go;
    $fullText =~ s/<\/$::tagRtnlines>/<\/p>/go;
    $fullText =~ s/<$::tagHeading>/<$headingSection class="heading">/go;
    $fullText =~ s/<\/$::tagHeading>/<\/$headingSection>/go;
    $fullText =~ s/<$::tagSubheading>/<$headingSection class="subheading">/go;
    $fullText =~ s/<\/$::tagSubheading>/<\/$headingSection>/go;
    $fullText =~ s/<$::tagDisplay>/<pre class="display">/go;
    $fullText =~ s/<\/$::tagDisplay>/<\/pre>/go;
    $fullText =~ s/<$::tagCode>/<pre class="code">/go;
    $fullText =~ s/<\/$::tagCode>/<\/pre>/go;
    $fullText =~ s/<$::tagCodesmall>/<pre class="codesmall">/go;
    $fullText =~ s/<\/$::tagCodesmall>/<\/pre>/go;
    $fullText =~ s/<$::tagTable[^>]*>/<table class="table">/go;
    $fullText =~ s/<\/$::tagTable[^>]*>/<\/table>/go;
    $fullText =~ s/<$::tagRow>/<tr valign="top">/go;
    $fullText =~ s/<\/$::tagRow>/<\/tr>/go;
    $fullText =~ s/<$::tagHcell>/<th align="left">/go;
    $fullText =~ s/<\/$::tagHcell>/<\/th>/go;
    $fullText =~ s/<$::tagCell>/<td align="left">/go;
    $fullText =~ s/<\/$::tagCell>/<\/td>/go;
    $fullText =~ s/<$::tagSpan([^>]*)>/<tr>\n<td\1>/go;
    $fullText =~ s/<\/$::tagSpan>/<\/td>\n<\/tr>/go;
    $fullText =~ s/(<\/?)$::tagItemlist>/\1dl>/go;
    $fullText =~ s/<$::tagItem>/<dt class="item">/go;
    $fullText =~ s/<\/$::tagItem>/<\/dt>/go;
    $fullText =~ s/<$::tagItemtext>/<dd class="itemtext">/go;
    $fullText =~ s/<\/$::tagItemtext>/<\/dd>/go;
    $fullText =~ s/<$::tagMarkerlist>/<table class="markerlist">/go;
    $fullText =~ s/<\/$::tagMarkerlist>/<\/table>/go;
    $fullText =~ s/<$::tagMarker>/<tr valign="top">\n<td class="marker"><p>/go;
    $fullText =~ s/<\/$::tagMarker>/<\/p><\/td>/go;
    $fullText =~ s/<$::tagMarkertext>/<td align="left" class="markertext">/go;
    $fullText =~ s/<\/$::tagMarkertext>/<\/td>\n<\/tr>/go;
    $fullText =~ s/<$::tagLibrary>/<b class="library">/go;
    $fullText =~ s/<$::tagRoutine>/<b class="routine">/go;
    $fullText =~ s/<$::tagFile>/<b class="file">/go;
    $fullText =~ s/<$::tagConstant>/<b class="constant">/go;
    $fullText =~ s/<\/($::tagLibrary|$::tagRoutine|$::tagFile|$::tagConstant)>/<\/b>/go;
    $fullText =~ s/<$::tagUrl>([^<]*)<\/$::tagUrl>/<a href="\1" class="url">\1<\/a>/go;
    $fullText =~ s/(<\/?)$::tagEmail>([^<]*)<\/$::tagEmail>/<a href="mailto:\1" class="email">\1<\/a>/go;

    # handle images

    my $imageCount = 1;
    while ( $fullText =~ /<$::tagImage\s+src=\"([^\"]+)\"\s*\/>/ )
        {
        my $imgName = $1;
        $imgName =~ /(\.\w+)$/;
        my $imgExt = $1;
        my $imgOutName = "$::outFileBase$imageCount$imgExt";
        my $imgBase = ::basename($imgName);
        my $imgDir  = ::dirname($imgName);
        my $inDirName = ::dirname($::inFile);

        # check that source and destination files are not the same

        chdir $inDirName;
        chdir $imgDir;
        my $srcDir = ::cwd();
        chdir $::cwDir;
        chdir $::outDir;
        my $destDir = ::cwd();
        chdir $::cwDir;

        if ( ($imgOutName ne $imgBase) or ($srcDir ne $destDir) )
            {
            $imgName = $srcDir . "/" . $imgBase;
            my $imgOutFileName = $destDir . "/" . $imgOutName;
            ::copy($imgName, $imgOutFileName);
            }
        $fullText =~ s/<$::tagImage\s+src=\"[^\"]+\"\s*\/>/<img src=\"$imgOutName\" \/>/;

        $imgCount++;
        }

    # the following substitutions could be omitted given the current values
    # of tagPara, tagRule, tagBreak, tagBold, and tagItalic, but are included
    # in case these values change

    $fullText =~ s/(<\/?)$::tagPara>/\1p>/go;
    $fullText =~ s/<$::tagRule\/>/<hr\/>/go;
    $fullText =~ s/<$::tagBreak\/>/<br\/>/go;
    $fullText =~ s/(<\/?)$::tagBold>/\1b>/go;
    $fullText =~ s/(<\/?)$::tagItalic>/\1i>/go;

    $fullText =~ s/&bslash;/\\/g;
    $fullText =~ s/&btick;/\`/g;
    $fullText =~ s/&vbar;/|/g;
    $fullText =~ s/&endash;/-/g;

    # output to proper file

    my $ruleTag = "<hr/>";

    open OUTFILE, ">$::outDir/$outFileName";

    if ( $::outForm eq "xhtml" )
        {

        # print header information unique to XHTML

        print OUTFILE "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"\n";
        print OUTFILE "    \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n";
        print OUTFILE "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
        }
    else
        {
        # remove XHTMLisms

        $fullText =~ s/<([^>]+)\/>/<\1>/g;
        $ruleTag = "<hr>";

        # print header information unique to HTML

        print OUTFILE "<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.0//EN\">\n";
        print OUTFILE "<html>\n";
        }

    # print common part of header information

    print OUTFILE "<link rel=\"stylesheet\" type=\"text/css\" href=\"wr_api.css\">\n";
    if ( not $htmlTitle )
        {
        $htmlTitle = $::outFileBase;
        }
    print OUTFILE "<head>\n";
    print OUTFILE "<title>$htmlTitle</title>\n";
    print OUTFILE "</head>\n";
    print OUTFILE "<body bgcolor=\"#FFFFFF\">\n";

    if ( $::outForm ne "htmldoc" )
        {
        print OUTFILE "<a name=\"top\"></a>\n";
        print OUTFILE "$ruleTag\n";
        print OUTFILE "<p align=\"right\">\n";
        print OUTFILE "<a href=\"libIndex.htm\" class=\"libindex\">API Reference: Libraries</a>\n";
        print OUTFILE "</p>\n";
        }

    # print output

    print OUTFILE $fullText;
    print OUTFILE "\n";

    # close indent

    while ( $realIndent > 0 )
        {
        print OUTFILE "$endIndent\n";
        $realIndent--;
        }

    # print tail end of file

    print OUTFILE "</body>\n";
    print OUTFILE "</html>\n";

    close OUTFILE;

    return;
    }


###############################################################################
#
# outputFiles - generate .lib and .rtn files
#
# This routine is the master routine for generating .lib and .rtn files 
# when necessary.
#

sub outputFiles
    {    
    my $text = $_[0];
    my $libHeaderNoManual = 0;
    my @rtnList = ();
    my $libNext = 0;
    my $rtnNext = 0;

    $libHeaderNoManual = 1 if (grep /<$::tagLibrarydoc\s+scope=\"internal\">/, @$text);
      
    # extract information for .lib and .rtn files

    foreach (@$text)
        {
        last if /<\/$::tagRtnlines>/;

        if ( !$libHeaderNoManual && $libNext )
            {
            /^(.*?)\s+&endash;\s+(.*)$/;
            $libOutLine = "{$::libraryTitle} {$2}" . 
               " {<b( class=\"library\")?>$::libraryTitle</b>}" .
               " {<b class=\"library\">" .
               "<a href=\"./$outFileName#top\" class=\"library\">" . 
               "$::libraryTitle</a></b>}" .
               " {$::optionBook} {$::optionChapter} {$::optionCategory} {}";

            # Note that the class="library" is optional because of all the
            # legacy code that marks non-standard library names as bold
            # rather than as \lib.  Maybe this is a bad idea, but...

            $libNext = 0;
            }

        if ( $rtnNext )
            {
            /^<$::tagRoutine>([^<]*)<\/$::tagRoutine>\s+&endash;\s+(.*)$/;
            my $rtn = $1;
            my $desc = $2;
            my $rtnBase = $rtn;
	    my $rtnLink = $rtn;
            $rtnBase =~ s/\(&nbsp;\)//;
	    $rtn     =~ s/([\(\)\.&])/\\\1/g;  # protect special chars
	    $rtnLink =~ s/([\.&])/\\\1/g;
            $desc =~ s/<$::tagBreak\/>//;
        
            if ( $::optionFName )
                {
                $desc = "[$::inFile] " . $desc;
                }
        
            push @rtnList, "{$rtnBase} {$desc}" . 
                 " {<b( class=\"routine\")?>$rtn</b>}" .
                 " {<b class=\"routine\">" .
                 "<a href=\"./$outFileName#$rtnBase\" class=\"routine\">" .
                 "$rtnLink</a></b>}" .
                 " {$::optionBook} {$::optionChapter} {$::optionCategory} {}";

             $rtnNext = 0;
             }

        $libNext = 1 if (!$libHeaderNoManual && /<$::tagLibshort>/);
        $rtnNext = 1 if /<$::tagRtnline>/;
        }

        # write .lib and .rtn files

        open LIBOUT, ">$::outDir/$::outFileBase.lib";
        print LIBOUT "$libOutLine\n";
        close LIBOUT;
	$libOutLine = "";   ### empty the $libOutLine to avoid writing it on other .lib files

        open RTNOUT, ">$::outDir/$::outFileBase.rtn";
        my $rtnOutLines = join "\n", @rtnList;
        print RTNOUT "$rtnOutLines\n";
        close RTNOUT;
        }

1;  # ugly necessity for putting this file in 'require' directive
