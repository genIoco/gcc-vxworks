# apiMifCollate.pl - collate, sort, and convert XML references to MIF
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01c,02oct04,wsl  adapt to line numbers in apigen, SPR 93816
# 01b,23sep04,wsl  SPR 101947, fix spurious error messages
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This utility reads all XML files (produced by apigen) in a directory,
# separates out the library and routine entries, sorts them, then uses
# apigen's MIF output processor to create complete reference chapters.
# apiMifCollate.pl must be run from the directory containing the XML files.
#
# SYNOPSIS
#
# apiMifCollate.pl
#

package main;

$v = chr 132; # this must be defined here so that apiOutMif.pl will have it
my $maxsize = 1000000;

my @path = split /\/|\\/, $0;
pop @path;
$utilPath = join '/', @path;
$utilPath = "." if "$utilPath" eq "";

require "$::utilPath/apigen0.pl";
require "$::utilPath/apiOutMif.pl";

# read in all XML files in this directory

@fileList = <*.xml>;
foreach $file (@fileList)
    {
    open INFILE, "<$file";
    my $fullText;
    my $size = read INFILE, $fullText, $maxsize;
    die "ERROR: file $file is too large" if $size == $maxsize;
    close INFILE;

    # trim file header and trailer

    $fullText =~ s/^.*<apidoc[^>]*>\n//s;
    $fullText =~ s/\n<\/apidoc>.*//s;

    # split file into routine and library entries

    $marker = chr 129;
    $fullText =~ s/\n<routinedoc>/$marker<routinedoc>/g;
    @segments = split /$marker/, $fullText;

    # put each segment into the appropriate hash

    foreach $segment (@segments)
        {
        if ( $segment =~ /^<librarydoc>/ )
            {
            $segment =~ /<libhead>(.*)<\/libhead>/;
            if ( $libs{$1} )
                {
                my $count = 1;
                while ( $libs{$1 . ";$count"} )
                    {
                    $count++;
                    }
                $libs{$1 . ";$count"} = $segment;
                print STDOUT "Duplicate library: $1;$count\n";
                }
            else
                {
                $libs{$1} = $segment;
                }
            }
        else
            {
            $segment =~ /<rtnhead>(.*)<\/rtnhead>/;
            if ( $rtns{$1} )
                {
                my $count = 1;
                while ( $rtns{$1 . ";$count"} )
                    {
                    $count++;
                    }
                $rtns{$1 . ";$count"} = $segment;
                print STDOUT "Duplicate routine: $1;$count\n";
                }
            else
                {
                $rtns{$1} = $segment;
                }
            }
        }
    }

# sort hash keys

@libKeys = sort keys %libs;
@rtnKeys = sort keys %rtns;

# construct list of libraries and process it

foreach $key (@libKeys)
    {
    push @libraries, $libs{$key};
    }

$outFileBase = "Libraries";
$outDir      = ".";
mifOut::apiGenerate (@libraries);

# construct list of routines and process it

foreach $key (@rtnKeys)
    {
    push @routines, $rtns{$key};
    }

$outFileBase = "Routines";
$outDir      = ".";
mifOut::apiGenerate (@routines);

exit 0;
