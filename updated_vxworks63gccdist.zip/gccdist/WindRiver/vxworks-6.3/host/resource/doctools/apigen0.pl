# apigen0.pl - initialize certain constants used in more than one utility
#
# Copyright 2003 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01b,21sep04,wsl  add <file> tag in support of CSS, SPR 101587
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This module simply defines some variables used as constants in apigen and
# apiCollate.
#

# tag names

$tagApidoc     = "apidoc";
$tagLibrarydoc = "librarydoc";
$tagRoutinedoc = "routinedoc";
$tagLibhead    = "libhead";
$tagLibname    = "libname";
$tagLibshort   = "libshort";
$tagRtnlist    = "rtnlist";
$tagRtnlines   = "rtnlines";
$tagRtnline    = "rtnline";
$tagRtnhead    = "rtnhead";
$tagRtnname    = "rtnname";
$tagRtnshort   = "rtnshort";
$tagSynopsis   = "synopsis";
$tagIncludes   = "includes";
$tagSeealso    = "seealso";
$tagReturns    = "returns";
$tagErrno      = "errno";
$tagSection    = "section";
$tagHeading    = "heading";
$tagSubheading = "subheading";
$tagPara       = "p";
$tagDisplay    = "display";
$tagCode       = "code";
$tagCodesmall  = "codesmall";
$tagTable      = "table";
$tagRow        = "row";
$tagSpan       = "span";
$tagHcell      = "hcell";
$tagCell       = "cell";
$tagRule       = "hr";
$tagBreak      = "br";
$tagItemlist   = "itemlist";
$tagItem       = "item";
$tagItemtext   = "itemtext";
$tagMarkerlist = "markerlist";
$tagMarker     = "marker";
$tagMarkertext = "markertext";
$tagBold       = "b";
$tagItalic     = "i";
$tagConstant   = "constant";
$tagLibrary    = "library";
$tagRoutine    = "routine";
$tagFile       = "file";
$tagUrl        = "url";
$tagEmail      = "email";
$tagImage      = "image";
$tagTab        = "tab";
$tagEndash     = "endash";
$tagHardspace  = "hardspace";

