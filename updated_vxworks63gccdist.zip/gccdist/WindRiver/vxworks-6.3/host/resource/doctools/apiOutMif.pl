# apiOutMif.pl - produce MIF output format from internal XML
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01h,01oct04,wsl  add line numbers to error messages, SPR 93816
# 01g,23sep04,wsl  SPR 101588, support nested lists
# 01f,23sep04,wsl  SPR 101947, fix spurious error messages
# 01e,21feb04,jdi  added "M" to names of *_head paratags
# 01d,13feb04,jdi  Changed AT_apigenTbl to MS_manSingle
# 01c,24jan04,jdi  changed tagnames, etc. to new templateMan
# 01b,21mar03,wsl  change \bs to the 'bS' Frame tag
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This subroutine takes the internal XML and converts it to MIF format.
#
# NOROUTINES
#

# set the name space

package mifOut;

###############################################################################
#
# apiGenerate - convert internal XML to text output
#
# This is the master routine for putting the text into external XML.  Since
# the internal markup is XML, this consists of little more than adding a
# header.
#

sub apiGenerate
    {
    $v = $::v;

    $prologFileBase = "apiPreamble";
    $pageFileBase   = "apiPages";

    $tableNumBase = 1;

    $indentLevel  = 0; # global
    $indentEffect = 0; # min of $indentLevel and $indentMax
    $indentMax    = 2; # base is zero, so three levels allowed
                       # if more tags are introduced, they can be supported
                       # simply by raising $indentMax.

    # get and print prologue

    $outFileName = "$::outFileBase.mif";
    open OUTFILE, ">$::outDir/$outFileName";

    my $buffer;
    open TEMPLATEFILE, "<$::utilPath/$prologFileBase.mif";
    while ( read TEMPLATEFILE, $buffer, 1000000 )
        {
        $buffer =~ s/$prologFileBase/$::outFileBase/g; # can miss, but unlikely
        print OUTFILE $buffer;
        }
    close TEMPLATEFILE;
    $buffer = "";

    # prepare text

    grep s/^.*$v//o, @_; # eliminate line numbers as no error msgs here
    my $fullText = join "\n", @_;
    @_ = ();

    $fullText =~ s/&bslash;/\\/g;
    $fullText =~ s/&btick;/\`/g;
    $fullText =~ s/&vbar;/\|/g;
    $fullText =~ s/&endash;/<$::tagEndash\/>/g;

    my @inLines = split /\n/, $fullText; # combine lib/routines into single list
    $fullText = "";
    my @outLines = ();

    if ( not $::optionInternal )
        {

        # internal sections have already been removed

        @outLines = @inLines;
        }
    else
        {

        # remove "internal" markup

        while (@inLines)
            {
            my $line = shift @inLines;
            $line =~ s/^(<\w+)\s+scope="internal">/\1>/;
            push @outLines, $line;
            }
        }

    # separate out tables

    my @tableList = ();
    my @textList = ();
    while ( @outLines )
        {
        my $line = shift @outLines;

        if ( $line =~ /^<$::tagTable[^>]*>$/ )
            {
            push @textList, $line;  # preserve position of table
            my @tableLines = ();
            while ( $line !~ /^<\/$::tagTable>/ )
                {
                push @tableLines, $line;
                $line = shift @outLines;
                }
            push @tableLines, $line;
            push @tableList, [ @tableLines ];
            }

        # note that this leaves both <table> and </table> in textList --
        # this is essential

        push @textList, $line;
        }

    # process the tables first

    apiTableOut(@tableList);

    open INFILE, "<$::utilPath/$pageFileBase.mif";
    while ( read INFILE, $buffer, 1000000 )
        {
        print OUTFILE $buffer;
        }
    close INFILE;
    $buffer = "";

    # next process text

    apiTextOut(@textList);

    # complete file

    print OUTFILE "> # end of TextFlow\n";
    print OUTFILE "# END OF MIFFILE\n";

    close OUTFILE;
    
    return;
    }


################################################################################
#
# apiTableOut - convert list of XML tables into MIF text
#
# This routine takes a list of references to lists, each containing the text
# lines of a single table in XML format.  It converts all of these into a
# single string in MIF format.

sub apiTableOut
    {
    my $tableNum = $tableNumBase;
    my @tableLines;

    print OUTFILE "<Tbls\n";

    foreach $tableRef (@_)
        {
        $tableNum++;
        @tableLines = ();

        # get the number of columns

        my $line = shift @{$tableRef};
        $line =~ /columns="(\d+)"/;
        $numCols = $1;

        # output the table header, which includes column formats

        push @tableLines, " <Tbl";
        push @tableLines, "  <TblID $tableNum>";
        push @tableLines, "  <TblTag \`MS_manSingle\'>";
        push @tableLines, "  <TblNumColumns $numCols>";

        my $col;
        for ( $col=0 ; $col < $numCols ; $col++ )
            {
            push @tableLines, "  <TblColumnWidth  1.0\">";
            }

        # look ahead to see if there is a header row

        my $isHeader = 0;
        foreach $line (@{$tableRef})
            {
            if ( $line =~ /^<$::tagHcell>/ )
                {
                $isHeader = 1;
                last;
                }
            elsif ( $line =~ /^<$::tagCell>/ )
                {
                last;
                }
            }

        if ( $isHeader )
            {
            push @tableLines, "  <TblH";
            }
        else
            {
            push @tableLines, "  <TblBody";
            }

        # read table row by row

        while ( @{$tableRef} )
            {
            $line = shift @{$tableRef};
            if ( $line =~ /^<\/$::tagTable>$/ )
                {
                if ( $isHeader )
                    {
                    push @tableLines, "  > # end of TblH";
                    }
                else
                    {
                    push @tableLines, "  > # end of TblBody";
                    }
                push @tableLines, " > # end of Tbl";
                last;
                }
            next if $line !~ /^<$::tagRow>$/; # skip <span> lines

            # must be a <row> marker

            push @tableLines, "   <Row";
            push @tableLines, "    <RowMaxHeight  14.0\">";

            # read row cell by cell

            while ( @{$tableRef} )
                {
                $line = shift @{$tableRef};
                if ( $line =~ /^<\/$::tagRow>$/ )
                    {
                    push @tableLines, "   > # end of Row";
                    last;
                    }
                next if $line !~ /^<($::tagCell|$::tagHcell)>/; # error

                if ( $isHeader and $line =~ /^<$::tagCell>/ )
                    {
                    pop @tableLines;
                    pop @tableLines;
                    push @tableLines, "  > # end of TblH";
                    push @tableLines, "  <TblBody";
                    push @tableLines, "   <Row";
                    push @tableLines, "    <RowMaxHeight  14.0\">";
                    $isHeader = 0;
                    }

                push @tableLines, "    <Cell";
                push @tableLines, "     <CellContent";
                push @tableLines, "      <Notes";
                push @tableLines, "      > # end of Notes";
                push @tableLines, "      <Para";

                if ( $isHeader )
                    {
                    push @tableLines, "       <PgfTag `HC_headCell'>";
                    }
                else
                    {
                    push @tableLines, "       <PgfTag `B1_body'>";
                    }

                push @tableLines, "       <ParaLine ";

                $line =~ s/^<($::tagCell|$::tagHcell)>(.*)<\/($::tagCell|$::tagHcell)>/\2/;

                # split line into sections with same font

                my @newLines = apiLineFormat($line);
                foreach $frag (@newLines)
                    {
                    $frag = "     " . $frag;
                    }
                push @tableLines, @newLines;

                push @tableLines, "       > # end of ParaLine";
                push @tableLines, "      > # end of Para";
                push @tableLines, "     > # end of CellContent";
                push @tableLines, "    > # end of Cell";
                }
            }

        my $fullText = join "\n", @tableLines;
        $fullText .= "\n";
        print OUTFILE $fullText;
        }

    print OUTFILE "> # end of Tbls\n";
    return;
    }


################################################################################
#
# apiTextOut - convert  XML text into MIF text
#
# This routine takes a list of text lines from which the tables have been
# removed, and converts it to a single string in MIF format.

sub apiTextOut
    {
    my @outLines = ();

    $tableCount   = $tableNumBase;
    my $routineCount = 0;
    $afterItem       = 0; # global
    $firstMarkerText = 0; # global
    my $blankWhenNoRoutines = 0; # not the global variable

    my $tagsSkip = "$::tagLibrarydoc|$::tagRoutinedoc|$::tagLibname|" .
                   "$::tagRtnname|$::tagRtnlines|" .
                   "$::tagSection|$::tagSynopsis|$::tagIncludes|" .
                   "$::tagSeealso|$::tagReturns|$::tagErrno";

    @inLines = @_; # global

    while ( @inLines )
        {
        my $line = shift @inLines;

        next if $line =~ /^<\/?($tagsSkip)>/;

        if ( $line =~ /^<($::tagLibhead|$::tagRtnhead)>([^<]*)<\/($::tagLibhead|$::tagRtnhead)>/o )
            {
            apiBufferPrint(@outLines);
            @outLines = ();
            push @outLines, " <Para";
            push @outLines, "  <PgfTag `1H_headM'>";
            push @outLines, "  <ParaLine";
            push @outLines, "   <TextRectID 18>";
            push @outLines, apiLineFormat($2);
            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";
            }
        elsif ( $line =~ /^<$::tagHeading>([^<]*)<\/$::tagHeading>/o )
            {
            push @outLines, " <Para";
            if ( (length $1) < 15 )
                {
                push @outLines, "  <PgfTag `2H_headM'>";
                }
            else
                {
                push @outLines, "  <PgfTag `2W_headWideM'>";
                }
            push @outLines, "  <ParaLine";
            push @outLines, apiLineFormat($1);
            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";
            }
        elsif ( $line =~ /^<$::tagSubheading>(.*)<\/$::tagSubheading>$/o )
            {
            push @outLines, " <Para";
            if ( (length $1) < 10 )
                {
                push @outLines, "  <PgfTag `3H_headM'>";
                }
            else
                {
                push @outLines, "  <PgfTag `3W_headWideM'>";
                }
            push @outLines, "  <ParaLine";
            push @outLines, apiLineFormat($1);
            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";
            }
        elsif ( $line =~ /^<$::tagRtnlist blanking="yes">/ )
            {
            $blankWhenNoRoutines = 1;
            }
        elsif ( $line =~ /^<$::tagRtnlist.*>/ )
            {
            $blankWhenNoRoutines = 0;
            }
        elsif ( $line =~ /^<$::tagRtnline>$/ )
            {
            push @outLines, " <Para";
            push @outLines, "  <PgfTag `BS_bodySingle'>";
            push @outLines, "  <ParaLine";

            $line = shift @inLines;
            $line =~ s/<$::tagBreak\/>//o;
            push @outLines, apiLineFormat($line);

            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";

            shift @inLines; # must be closing markup
            $routineCount++;
            }
        elsif ( $line =~ /^<\/$::tagRtnlist>$/ )
            {
            if ( $routineCount == 0 )
                {
                if ( $blankWhenNoRoutines )
                    {

                    # delete the preceeding header

                    $line = pop @outLines until ( $line eq " <Para" );
                    }
                else
                    {

                    # add message indicating no routines

                    push @outLines, " <Para";
                    push @outLines, "  <PgfTag `BS_bodySingle'>";
                    push @outLines, "  <ParaLine";
                    push @outLines, "   <String `No user-callable routines'>";
                    push @outLines, "  > # end of ParaLine";
                    push @outLines, " > # end of Para";
                    }
                }
            }
        elsif ( $line =~ /^<($::tagLibshort|$::tagRtnshort)>$/ )
            {
            push @outLines, " <Para";
	    if ( $line =~ /^<$::tagRtnshort>$/ )
		{
		push @outLines, "  <PgfTag `TLR_titleLineRoutine'>";
		}
	    else
		{
		push @outLines, "  <PgfTag `TLL_titleLineLibrary'>";
		}
            push @outLines, "  <ParaLine";

            $line = shift @inLines;
            $line =~ s/\s<$::tagEndash\/>\s/<$::tagTab\/> <$::tagEndash\/> <$::tagTab\/>/;
            push @outLines, apiLineFormat($line);

            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";

            shift @inLines; # must be closing markup
            }
        else
            {
            unshift @inLines, $line;

            # note that apiChunkGet() can alter @outLines when necessary to
            # undo something

            my @paraLines = apiChunkGet();
            push @outLines, @paraLines;
            }
        }

    apiBufferPrint(@outLines);
    return;
    }


################################################################################
#
# apiChunkGet - convert a single paragraph to MIF format
#
# This routine takes a list of text lines from which the tables have been
# removed, and converts it to a single string in MIF format.
#
# This routine is called recursively.

sub apiChunkGet
    {
    my @outLines = ();
    
    my $line = shift @inLines;
    $line = shift @inLines while $line =~ /^\s*$/;  # skip blank lines

    my $lev;

    if ( $line =~ /^<$::tagPara>/o )
        {
        if ( ! $firstMarkerText )
            {
            push @outLines, " <Para";
            if ( $afterItem )
		{ 
		push @outLines, "  <PgfTag `IF$indentEffect" . "_itemFollow'>";
		$afterItem = 0;
		}
            else
		{
                $lev = $indentEffect + 1;
		push @outLines, "  <PgfTag `B$lev" . "_body'>";
		}
            }
        $firstMarkerText = 0;

        $line = shift @inLines;
        until ( $line =~ /^<\/$::tagPara>/ or not @inLines )
            {
            $line .= " ";
            push @outLines, "  <ParaLine";
            push @outLines, apiLineFormat($line);
            push @outLines, "  > # end of ParaLine";
            $line = shift @inLines;
            }

        push @outLines, " > # end of Para";
        }
    elsif ( $line =~ /^<($::tagCode|$::tagCodesmall|$::tagDisplay)>$/o )
        {
        my $tag = $1;
        $afterItem = 0;
        $line = shift @inLines;

        if ( $firstMarkerText )
            {
            push @outLines, " > # end of Para";
            $firstMarkerText = 0;
            }

        until ( $line =~ /^<\/$tag>/ or not @inLines )
            {
            push @outLines, " <Para";
            if ( $indentLevel == 0 )
                {
		if ( $tag eq $::tagCodesmall )
		    {
		    push @outLines, "  <PgfTag `zzDrawAscii'>";
		    }
                elsif ( $line =~ /^    \(/ )
                    {
                    push @outLines, "  <PgfTag `CN1_codeKeepNext'>";
                    }
                elsif ( $line =~ /^    \)/ )
                    {
                    push @outLines, "  <PgfTag `CP1_codeKeepPrev'>";
                    }
                else
                    {
                    push @outLines, "  <PgfTag `C1_code'>";
                    }
                }
            else
                {
                $lev = $levelEffect + 1;
                push @outLines, "  <PgfTag `C$lev" . "_code'>";
                }
            push @outLines, "  <ParaLine";
            push @outLines, apiLineFormat($line);
            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";
            $line = shift @inLines;
            }
        }
    elsif ( $line =~ /^<$::tagTable columns="\w+">/ )
        {
        $afterItem = 0;

        if ( $firstMarkerText )
            {
            push @outLines, " > # end of Para";
            $firstMarkerText = 0;
            }

        $line = shift @inLines until $line=~ /^<\/$::tagTable>/;

        $tableCount++;
        push @outLines, "<anchor>";
        push @outLines, " <Para";
        push @outLines, "  <PgfTag `AN_anchor'>";
        push @outLines, "  <ParaLine";
        push @outLines, "   <ATbl $tableCount>";
        push @outLines, "  > # end of ParaLine";
        push @outLines, " > # end of Para";
        }
    elsif ( $line =~ /^<$::tagItemlist>/ )
        {
        if ( $firstMarkerText )
            {
            push @outLines, " > # end of Para";
            $firstMarkerText = 0;
            }

        push @outLines, apiItemListGet();
        }
    elsif ( $line =~ /^<$::tagMarkerlist>/ )
        {
        if ( $firstMarkerText )
            {
            push @outLines, " > # end of Para";
            $firstMarkerText = 0;
            }

        push @outLines, apiMarkerListGet();
        }
    else
        {
        print STDERR "INTERNAL ERROR: unrecognized markup:\n";
        print STDERR "line: $line\n";
        print STDERR "indent level: $indentLevel\n";
        $::errorStatus = 1;
        }

    return @outLines;
    }


################################################################################
#
# apiItemListGet - format an item list
#
# This routine reads in an item list and puts it into MIF format.  Lists can
# nest, so this routine can be called recursively.

sub apiItemListGet
    {
    my @outLines = ();

    $indentLevel++;
    $indentEffect = $indentLevel;
    $indentEffect = $indentMax if $indentLevel > $indentMax;

    while ( @inLines )
        {
        my $line = shift @inLines;

        if ( $line =~ /^<$::tagItem>(.*?)<\/$::tagItem>/ )
            {
            my $itemText = $1;
            push @outLines, " <Para";
            push @outLines, "  <PgfTag `I$indentEffect" . "_item'>";
            push @outLines, "  <ParaLine";
            push @outLines, apiLineFormat($itemText);
            push @outLines, "  > # end of ParaLine";
            push @outLines, " > # end of Para";
	    $afterItem = 1;
            }
        elsif ( $line =~ /^<\/?$::tagItemtext>/o )
            {
            }
        elsif ( $line =~ /^<\/$::tagItemlist>/o )
            {
            $indentLevel--;
            if ( $indentLevel < 0 )
                {
                print STDERR "INTERNAL ERROR: indentLevel less than zero\n";
                $indentLevel = 0;
                $::errorStatus = 1;
                }
            $indentEffect = $indentLevel;
            last;
            }
        else
            {
            unshift @inLines, $line;
            push @outLines, apiChunkGet();
            }
        }

    return @outLines;
    }


################################################################################
#
# apiMarkerListGet - format a marker list
#
# This routine reads in a marker list and puts it into MIF format.  Lists can
# nest, so this routine can be called recursively.

sub apiMarkerListGet
    {
    my @outLines = ();

    $afterItem = 0;

    $indentLevel++;
    $indentEffect = $indentLevel;
    $indentEffect = $indentMax if $indentLevel > $indentMax;

    while ( @inLines )
        {
        my $line = shift @inLines;

        if ( $line =~ /^<$::tagMarker>(.*?)<\/$::tagMarker>/ )
            {
            my $itemText = $1;
            push @outLines, " <Para";
            push @outLines, "  <PgfTag `SC$indentEffect" . "_stepCustom'>";
            push @outLines, "  <ParaLine";
            push @outLines, apiLineFormat($1);
            push @outLines, "   <Char Tab>";
            push @outLines, "  > # end of ParaLine";
            $firstMarkerText = 1;
            }
        elsif ( $line =~ /^<\/?$::tagMarkertext>/o )
            {
            }
        elsif ( $line =~ /^<\/$::tagMarkerlist>/o )
            {
            $indentLevel--;
            if ( $indentLevel < 0 )
                {
                print STDERR "INTERNAL ERROR: indentLevel less than zero\n";
                $indentLevel = 0;
                $::errorStatus = 1;
                }
            $indentEffect = $indentLevel;
            last;
            }
        else
            {
            unshift @inLines, $line;
            push @outLines, apiChunkGet();
            }
        }

    return @outLines;
    }


################################################################################
#
# apiLineFormat - convert single line of text to MIF
#
# This routine takes a single line of would-be text, interprets any in-line
# markup, and produces MIF lines.

sub apiLineFormat
    {
    my $marker = chr 129;
    my $line = shift;
    my @outLines = ();

    $line =~ s/\&nbsp;/<$::tagHardspace\/>/go;
    $line =~ s/(<\/?\w+\/?>)/$marker\1/go;
    my @frags = split /$marker/, $line;

    foreach (@frags)
        {
        if ( s/^<($::tagBold|$::tagUrl|$::tagEmail)>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `nameLiteral'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }
        elsif ( s/^<$::tagItalic>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `placeholder'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }
        elsif ( s/^<$::tagLibrary>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `library'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }
        elsif ( s/^<$::tagRoutine>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `routine'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }
        elsif ( s/^<$::tagFile>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `nameLiteral'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }
        elsif ( s/^<$::tagConstant>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `nameLiteral-uc'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }
        elsif ( /^<$::tagBreak\/>/ )
            {
            push @outLines, "   <Char HardReturn>";
            push @outLines, "  > # end of ParaLine";
            push @outLines, "  <ParaLine";
            next;
            }
        elsif ( s/^<$::tagTab\/>// )
            {
            push @outLines, "   <Char Tab>";
            }
        elsif ( s/^<$::tagEndash\/>// )
            {
            push @outLines, "   <Char EnDash>";
            }
        elsif ( s/^<$::tagHardspace\/>// )
            {
            push @outLines, "   <Char HardSpace>";
            }
        elsif ( s/<\/\w+>// )
            {
            push @outLines, "   <Font";
            push @outLines, "    <FTag `'>";
            push @outLines, "    <FLocked No>";
            push @outLines, "   > # end of Font";
            }

        s/\\/\\\\/g;
        s/\`/\\Q/g;
        s/\'/\\q/g;
        s/(>|&gt;)/\\>/g;
        s/&lt;/</g;
        s/&amp;/&/g;

        $_ = "   <String `" . $_ . "'>";
        push @outLines, $_;
        }

    return @outLines;
    }


################################################################################
#
# apiBufferPrint - print out part of converted text
#
# This routine takes a list of lines ready for printing and prints them.
# This is to reduce memory usage, which can be large for large libraries.

sub apiBufferPrint
    {
    my $buffer = join "\n", @_;
    $buffer .= "\n";

    # make a last-minute adjustment for table anchors

    # following commented out so anchors are kept in own paragraph
#    $buffer =~ s/ > # end of Para\n<anchor>\n <Para\n  <PgfTag `B1_body'>\n//g;

     $buffer =~ s/<anchor>\n//g;

    print OUTFILE $buffer;
    }


1;  # ugly necessity for putting this file in 'require' directive
