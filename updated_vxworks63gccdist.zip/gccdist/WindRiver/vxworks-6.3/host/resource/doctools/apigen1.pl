# apigen1.pl - read in complete source text for api doc generation
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01j,30jun05,khs  Activate $::isTcl for Tcl in apiLangFind
# 01i,26apr05,lll  Force BSP primary output filename to be "target" when 
#                  processing target.{nr|ref} to facilitate automated creation
#                  of Eclipse online help TOC for BSPs
# 01h,10jan05,lll  Standalone apigen, SPR#105634 and SPR#104090
# 01g,08oct04,???  adjust the regexp for finding CPP linenum info
# 01f,07oct04,wsl  handle pre-processed input file, SPR 102362
# 01e,05oct04,wsl  fix format of error messages
# 01d,30sep04,wsl  add line numbers to error messages, SPR 93816
# 01c,14sep04,wsl  fix SPR 97002, search for title in first 5 lines instead of
#                  just 3
# 01b,22mar03,wsl  make file name mismatch a warning rather than an error
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This group of subroutines determines the language of an input file,
# reads in that input file along with any text specified in APPEND or
# EXPAND directives, or, if needed, constructs a dependency list and
# prints the corresponding makefile rule to the standard output.
#
# The name of the input file is taken from $inFile, and the result is
# returned as a list of lines.
#
# NOROUTINES
#

package assemble;

###############################################################################
#
# apiAssemble - assemble complete text for processing
#
# This routine is the master routine for assembling the text.
# When this stage is complete, we are done with reading files.
# 
# This routine determines the name of the output file, which might seem
# like it belongs in the final stage, but this information is needed to
# generate a make rule, and the text it is derived from should not be
# passed on to other sections.
#
# This routine also handles any \LANGUAGE directive.  Again, this might
# seem out of place, but since the later sections cannot determine which
# file such a directive was in, we must do it now.
#

sub apiAssemble
    {
    $v = $::v; # ubiquitous separator between line numbers and text

    if ( $::optionDebug )
        {
        print STDERR "Starting Stage 1 -- assembly\n";
        }

    my $inFile = shift;

    # The list of dependency files -- @apiDependList -- is kept as a global
    # list to allow duplicate entries to be avoided rather than removed later.
    # This in turn guarantees that we can't get into any infinite loops with
    # appended files.
    # The list actually used to construct the dependency string is constructed
    # separately, partly to simplify and underscore the recursive nature of
    # the process, partly out of a stubborn desire to maintain a certain
    # ordering.  The actual files in the lists should be the same.

    @apiDependList = ();

    # generate the output file basename (no extension) -- global variable

    $::outFileBase = apiOutFileNameGen($inFile);

    # figure out the language of the input file -- global variable

    $::apiFileLanguage = apiLangFind($inFile);

    # find all the APPEND files recursively

    @fileAppendList = apiAppendFind($inFile);  # includes $inFile

    # if we are only generating the dependencies, generate them and return
    # NOTE: this is formatted only for UNIX platforms

    if ( $::optionDepend )
        {
        # add EXPAND, IMPLEMENTS, and IMAGE files to dependency list

        my @dependList = @fileAppendList;
        for $appFile (@fileAppendList)
            {
            push @dependList, apiExpand($appFile, $::optionDepend);
            }

        push @dependList, apiImagesFind($inFile);

        # shorten file names if under current directory

        foreach $name (@dependList)
            {
            if ( length($name) > length($::cwDir) and
                 substr($name, 0, length($::cwDir)) eq $::cwDir )
                {
                $name = substr($name, length($::cwDir)+1);
                }
            }

        # construct rule

        my $dependString = "";
        my $index = 0;
        foreach $outDir (@::optionOutDir)
            {
            $dependString .= $outDir . "/$::outFileBase." .
              $::formatExtension{$::optionFormat[$index]} . " ";
            $index++;
            }
        $dependString .= ":";
        
        foreach $file (@dependList)
            {
            $dependString .= " $file";
            }

        print STDOUT $dependString;
	return 0;
        }

    # append them all

    my @inLines = ();
    foreach $appFile (@fileAppendList)
        {
        push @inLines, apiExpand($appFile, $::optionDepend);
        }

    # Remove \APPEND, \EXPAND, \EXPANDPATH, and \LANGUAGE directives.
    # Also replace tabs with appropriate number of spaces, but only
    # outside of mangen tables, which use tabs as column separators.

    my $appendPattern = "";
    if ( $::optionStrict )
        {
        $appendPattern = '(\S{1,3}\s+)?\\\\(APPEND|EXPAND|EXPANDPATH|IMPLEMENTS)\s+(\S+)(\s+(\S+))?\s*$'; #'
        }
    else
        {
        $appendPattern = '(\S{1,3}\s+)?\\\\?(APPEND|EXPAND|EXPANDPATH|IMPLEMENTS)\s+(\S+)(\s+(\w+))?\s*$'; #'
        }

    my $inTable = 0;
    my @textLines = ();
    foreach $line (@inLines)
        {
        next if $line =~ /$v$appendPattern/o;
        next if $line =~ /$v(\S{1,3}\s+)?\\LANGUAGE\s+(\w+)\s*$/o;

        if ( $line =~ /$v(\S{1,3}\s+)?\.(TS|nf)/o )
            {
            $inTable = 1;
            }
        elsif ( $line =~ /$v(\S{1,3}\s+)?\.(TE|fi)/o )
            {
            $inTable = 0;
            }

        if ( (! $inTable) && ($line =~ /\t/) )
            {
            my @frags = split "\t", $line;
            foreach $frag (@frags)
                {
                my $extraSpaces = 8 - (length $frag) % 8;
                $frag .= " " x $extraSpaces;
                }
            $line = join "", @frags;
            $line =~ s/\s+$//;
            }

        push @textLines, $line;
        }

    # save some space

    %apiFileGrabHash = ();

    # print any debug information

    if ( $::optionDebug )
        {
        my $debugFile = $::outFileBase . ".1";
        my $debugText = join "\n", @textLines;
        $debugText =~ s/$v/:/go;

        open DEBUG, ">$debugFile";
        print DEBUG $debugText, "\n";
        close DEBUG;

        print STDERR "  Finished with stage 1\n";
        }

    return @textLines;  # only fatal error is no text
}


###############################################################################
#
# apiOutFileNameGen - produce name of output file
#
# This routine looks in the first few lines of the input file for syntax
# that directs it to change the name of the output file.  This is a one-line
# description of the form:
#
# newnamestem/filename.nr - library to do blah
#
# and is used primarily in target.nr and target.ref files for BSPs
#

sub apiOutFileNameGen
    {
    my $inFile = shift;

    # get the text

    my @fileLines = split /\n/, apiFileGrab("", $inFile);

    # get proximal name of input file

    my @inPath     = split /\\|\//, $inFile;
    my $inFileName = pop @inPath;

    # try first five lines looking for the title line

    my $newName     = "";
    my $oldName     = "";
    my $description = "";
    my $i = 0;
    my $titleLine;
    foreach $line (@fileLines)
        {
        $titleLine = $line;
        if ( $line =~ m:$v(\S{1,3}\s+)?([^\s/]+)/(\S+)\s+-(.*)$:o )
            {
            $newName = $2;
            $oldName = $3;
            $description = $4;
            last;
            }
        elsif ( $line =~ m:$v(\S{1,3}\s+)?(\S+)\s+-(.*)$:o )
            {
            $oldName = $2;
            $description = $3;
            last;
            }

        $i++;
        last if $i >= 5;
        }

    $titleLine =~/^(.*)$v/o;
    my $loc = $1;

    if ( "$oldName" eq "" )
        {
        print STDERR "$loc: ERROR: Could not find title line for $inFile\n";
        $::errorStatus = 1;
        $oldName = $inFileName;
        }

    if ( "$oldName" ne "$inFileName" )
        {
        print STDOUT "$loc: WARNING: File name in title not name of file: $oldName\n";
        $oldName = $inFileName;
        }

    if ( $description =~ /^\s*$/ )
        {  # no description
        print STDOUT "$loc: WARNING: no module description for $inFile\n";
        }

    if ( "$newName" eq "" )
        {
        $newName = $oldName;
        }

    $newName =~ s/\.\w*$//;  # kill any extension

    # Generate a title line (which may have an end-of-comment mark).
    # This is used in the next stage.

    $::apiLibTitle = $newName . " - " . $description;

    # Beginning with VxWorks 6.1, force BSP primary output filename to 
    # always be "target" when processing target.{nr|ref} to facilitate 
    # automated creation of Eclipse online help TOC for BSPs.

    if ( $::inFile =~ /^target\.(nr|ref)/i )
        {
        $newName = "target";
        }

    return $newName;
    }


###############################################################################
#
# apiFileGrab - read in text of a complete file and save it in a hash
#
# This routine locates the absolute path name for the given file, then
# reads it into a hash, if necessary, then returns the saved text.
#

sub apiFileGrab
    {
    my $fileLine = shift;
    my $inFile   = shift;
    my $inBuffer;
    $fileLine =~ /^(.*)$v/;
    my $fileLoc  = $1;

    # convert file path to a complete absolute path

    $absFile = apiAbsoluteForce($inFile);

    # read in file if not already in hash

    if ( not exists $apiFileGrabHash{$absFile} )
        {
        if ( not -T $inFile )
            {
            print STDERR "$fileLoc: ERROR: $inFile is not a text file\n";
            return "";
            }
        if ( not -r $inFile )
            {
            print STDERR "$fileLoc: ERROR: $inFile is not readable\n";
            return "";
            }

        my $openStatus = open INFILE, "<$absFile";
        if ( ! $openStatus )
            {
            print STDERR "$fileLoc: ERROR: could not open readable text file $absFile\n";
            return "";
            }

	$apiFileGrabHash{$absFile} = "";
	while ( read INFILE, $inBuffer, 100000 )
	    {
	    $apiFileGrabHash{$absFile} .= $inBuffer;
	    }
        close INFILE;

        # add line numbers to input file

        my $shortFile = $inFile;
        $shortFile =~ s/^$::cwDir\//.\//;
        my $isPreprocessed = ($inFile =~ /\.i\s*$/);

        $apiFileGrabHash{$absFile} =~ s/[\s\n]+$//;
        my @fileLines = split /\n/, $apiFileGrabHash{$absFile};
        my $lineCount = 1;
        foreach $line (@fileLines)
            {
            if ( $line =~ /^#/ && $isPreprocessed )
                {

                # interpret preprocessor line num info

                if ( $line =~ /^#\s+(\d+)\s+\"(.*)\"(\s|$)/ )
                    {
                    $lineCount = $1;
                    $shortFile = $2;
                    }
                next;
                }
            $line = "$shortFile:$lineCount$v" . $line;
            $lineCount++;
            }

        @fileLines = grep !/^#/, @fileLines; # delete preprocessor stuff
        $apiFileGrabHash{$absFile} = join "\n", @fileLines;
        }

    return $apiFileGrabHash{$absFile};
    }    


###############################################################################
#
# apiLangFind - figure out the language of the input file
#
# This routine decides what computer language the input file is written
# in based on any \\LANGUAGE directive, any -lang option, and the file
# extension in that order of precedence.
#

sub apiLangFind
    {

    my $inFile = shift;

    # first look for a \LANGUAGE directive

    my $inFileText = apiFileGrab("", $inFile);
    if ( $inFileText =~ /^(.*)$v(\S{1,3}\s+)?\\LANGUAGE\s+(\S+)\s*$/o )
        {
        my $loc = $1;
        my $maybeLang = lc $3;
        if ( $maybeLang =~ /^($::legalLangs)$/ )
            {
	    if ($maybeLang =~ /tcl/)            # if the script is tcl
	    	{
		 $::isTcl = '1';
	    	}
            return $maybeLang;
            }
        else
            {
            print STDERR "$loc: ERROR: illegal \\LANGUAGE directive: $maybeLang\n";
            $::errorStatus = 1;
            }
        }
    
    # if none, look for a -lang input option

    if ( "$::optionLang" ne "" )
        {
	if ($::optionLang =~ /tcl/)            # if the script is tcl
	    	{
		 $::isTcl = '1';
	    	}
        return $::optionLang;
        }

    # if still nothing, look at extention

    if ( $inFile =~ /[^\/\\]+\.(\w+)$/ )
        {
        my $maybeLang = $1;
        if ( $maybeLang =~ /^($::legalExtensions)$/ )
            {

            # look up language tag based on file extension

            $maybeLang = $::extLanguage{$maybeLang};
	    if ($maybeLang =~ /tcl/)
	    	{
		 $::isTcl = '1';   # if the script is tcl
	    	}

            return $maybeLang;
            }
        }

    # nothing to go on, so assume C but print error message

    print STDERR "Unknown file type -- treat as $::optionLangDefault\n";
    $::errorStatus = 1;
    return $::optionLangDefault
    }


###############################################################################
#
# apiAbsoluteForce - make a path absolute with no symlinks
#
# this routine makes the input path, which may be relative and may have
# symbolic links, into an absolute path
#

sub apiAbsoluteForce
    {

    my $pathName = shift;

    # split path to get parent directory, then cd into it to get absolute path

    my @path = split /\\|\//, $pathName;
    my $base = pop @path;
    my $fileDir = join '/', @path;
    if ( scalar(@path) == 0 )
        {
        $fileDir = ".";
        }
    chdir $fileDir;
    my $newPath = ::cwd();
    chdir $::cwDir;
    my $absFile = $newPath . '/' . $base;

    return $absFile;
    }


###############################################################################
#
# apiAppendFind - recursively compile list of files to append
#
# This routine looks through the given file for APPEND directives
# and calls itself to look through all APPEND files it finds.  It
# returns a list of file names with absolute paths that includes
# the name of the input file.
#

sub apiAppendFind
    {
    my $srcFile = shift;

    if ( not -e $srcFile )
        {
        # unfortunately, we don't know line number

        print STDERR "Cannot find APPEND file $srcFile\n";
        $::errorStatus = 1;
        return ($srcFile);  # this file must still go in dependency list
                            # -- the build must die
        }

    # get absolute path without symbolic links
    # (note that this is redundant except for the initial call)

    $srcFile = apiAbsoluteForce($srcFile);
    my @srcPath = split /\\|\//, $srcFile;
    pop @srcPath;
    my $srcDir = join '/', @srcPath;

    # get the file text

    my @srcLines = split /\n/, apiFileGrab($origLine, $srcFile);

    # hunt for \APPEND directives, skipping duplicates

    my $appendPattern = "";
    if ( $::optionStrict )
        {
        $appendPattern = '(\S{1,3}\s+)?\\\\APPEND\s+(\S+)\s*$'; #'
        }
    else
        {
        $appendPattern = '(\S{1,3}\s+)?\\\\?APPEND\s+(\S+)\s*$'; #'
        }

    my @foundList = ();
    foreach $line (@srcLines)
        {
        if ( $line =~ /^(.*)$v$appendPattern/ )
            {
            my $loc = $1;
            my $appFile = $3;

            # construct proper path (no symlinks)

            if ( $appFile =~ m:^(/|\\): )
                {
                # path is relative to WIND_BASE

                if ( "$::windBase" eq "" )
                    {
                    print STDERR "$loc: ERROR: WIND_BASE required and not set\n";
                    $::errorStatus = 1;
                    next;
                    }
                $appFile = $::windBase . $appFile;
                }
            else
                {
                # path is relative to $srcFile

                $appFile = $srcDir . '/' . $appFile;
                }

            # If file doesn't exist, print an error message and skip it.
            # If we include it in a dependency list, the build will stop
            # instead of merely logging an error.

            if ( not -e $appFile )
                {
                print STDERR "$loc: ERROR: append file not found: $appFile\n";
                $::errorStatus = 1;
                next;
                }

            # force unique absolute path

            $appFile = apiAbsoluteForce($appFile);

            # test for duplicates

            my @dups = grep { $_ eq $appFile } @apiDependList;
            my $numDups = @dups;

            next if $numDups > 0;

            push @foundList, $appFile;
            push @apiDependList, $appFile;
            }
        }

    # construct the append list recursively

    my @appendList = ($srcFile);
    foreach $appFile (@foundList)
        {
        push @appendList, apiAppendFind($appFile);
        }

    return @appendList;
    }



###############################################################################
#
# apiImagesFind - find the names of all files in IMAGE directives
#
# This routine takes a file name as its argument, and returns a list of file
# names found in IMAGE directives.
#
# The input file path is assumed to be relative to the current directory.
#

sub apiImagesFind
    {
    my $origLine = shift;
    my $inFile = shift;
    my @imageFileList = ();

    my $inFileText = apiFileGrab($origLine, $inFile);
    my @inFileLines = split /\n/, $inFileLines;
    foreach (@inFileLines)
        {
        if ( /$v\\IMAGE\s+(\S+)\s*$/o )
            {
            push @imageFileList, $1;
            }
        }

    return @imageFileList;
    }



###############################################################################
#
# apiExpand - handle all the \EXPAND and \IMPLEMENTS directives in a file
#
# This routine takes a file name as its argument, and returns the text of the
# file after all its \EXPAND and \IMPLEMENTS directives have been handled.
# This includes handling of the \EXPANDPATH directives, which apply only to
# the file they inhabit.
#
# The input file path is assumed to be absolute.
#

sub apiExpand
    {
    my $inFile     = shift;
    my $dependFlag = shift;

    my @dependList = ();

    # get directory of file

    my @filePath = split /\\|\//, $inFile;
    pop @filePath;
    my $dirName = join '/', @filePath;

    # get file text

    my @inFileLines  = split /\n/, apiFileGrab($origLine, $inFile);

    # start by processing \EXPANDPATH directives

    my $pathPattern = "";
    if ( $::optionStrict )
        {
        $pathPattern = '(\S{1,3}\s+)?\\\\EXPANDPATH\s+(\S+)\s*$'; #'
        }
    else
        {
        $pathPattern = '(\S{1,3}\s+)?\\\\?EXPANDPATH\s+(\S+)\s*$'; #'
        }
    my @expandPathList = ();
    foreach $line (@inFileLines)
        {
        if ( $line =~ /^(.*)$v$pathPattern/ )
            {
            my $loc = $1;
            @newPathList = split /:/, $3;
            foreach $path (@newPathList) {
                
                if ( $path =~ m:^(/|\\): )
                    {
                    # path is relative to WIND_BASE

                    if ( "$::windBase" eq "" )
                        {
                        print STDERR "$loc: ERROR: WIND_BASE required and not set\n";
                        $::errorStatus = 1;
                        next;
                        }
                    $path = $::windBase . $path;
                    }
                else
                    {
                    # path is relative to input file directory

                    $path = $dirName . '/' . $path;
                    }

                # reality check

                if ( not -d $path )
                    {
                    print STDERR "$loc: ERROR: directory in EXPANDPATH does";
                    print STDERR " not exist: $path\n";
                    $::errorStatus = 1;
                    next;
                    }

                # make path absolute

                chdir $path;
                $path = ::cwd();
                chdir $::cwDir;

                push @expandPathList, $path;
                }
            }
        }

    my $pathLen = @expandPathList;
    if ( 0 == $pathLen )
	{
	@expandPathList = ($dirName);
	}

    # now process \EXPAND and \IMPLEMENTS directives

    my $expPattern;
    my $impPattern;
    if ( $::optionStrict )
        {
        $expPattern = '(\S{1,3}\s+)?\\\\EXPAND\s+(\S+)\s+(\w+)\s*$'; #'
        $impPattern = '(\S{1,3}\s+)?\\\\IMPLEMENTS\s+(\S+)(\s+(\w+))?\s*$'; #'
        }
    else
        {
        $expPattern = '(\S{1,3}\s+)?\\\\?EXPAND\s+(\S+)\s+(\w+)\s*$'; #'
        $impPattern = '(\S{1,3}\s+)?\\\\?IMPLEMENTS\s+(\S+)(\s+(\w+))?\s*$'; #'
        }

    my @outFileLines = ();

    foreach $line (@inFileLines)
        {
        if ( $line =~ /^(.*)$v$expPattern/ )
            {
            my $loc = $1;
            my $prefix = $2;
            my $hFileName = $3;
            my $structName = $4;
            my $newText = apiEntryExpand($line, $structName, $hFileName,
                                 $dependFlag, @expandPathList);
            if ( $dependFlag )
                {
                if ( "$newText" ne "" )
                    {
                    push @dependList, $newText;
                    }
                next;
                }

            # replace /* and */ with /@ and @/

            $newText =~ s:/\*:/@:g;
            $newText =~ s:\*/:@/:g;

            # split into lines

            my @newLines = split /\n/, $newText;

            # replace tab characters to tabstops of 8 -- must be done
            # separately from tab removal in main text because of extra indent

            foreach (@newLines)
                {
                my @frags = split "\t";
                foreach $frag (@frags)
                    {
                    my $extraSpaces = 8 - (length $frag) % 8;
                    $frag .= " " x $extraSpaces;
                    }
                $_ = join "", @frags;
                s/\s+$//;
                }

            # add markup lines

            unshift @newLines, "$loc$v\\cs";
            push    @newLines, "$loc$v\\ce";

            # language is indeterminate, so use prefix found

            grep { s/^(.*$v)(.*)$/\1$prefix\2/ } @newLines;

            push @outFileLines, @newLines;
            }
	elsif ( $line =~ /^(.*)$v$impPattern/ )
	    {
            my $loc = $1;
	    my $prefix = $2;
	    my $hFileName = $3;
	    my $className = $4;
	    my $newText = apiClassExpand($line, $hFileName, $dependFlag,
                                 $dirName);

	    if ( $dependFlag )
		{
		if ( "$newText" ne "" )
		    {
		    push @dependList, $newText;
		    }
		next;
		}

            # add markup lines

            unshift @newLines, "$loc$v\\cs";
            push    @newLines, "$loc$v\\ce";

	    # no need to add prefix, so just split into lines and add text

	    my @newLines = split /\n/, $newText;
	    push @outFileLines, @newLines;
	    }
        else
            {
            push @outFileLines, $line;
            }
        }

    if ( $dependFlag )
        {
        return @dependList;
        }
    else
        {
        return @outFileLines;
        }
    }


###############################################################################
#
# apiEntryExpand - locate and extract text for EXPAND directive
#
# This routine searches for a structure definition for the given structure
# name in files with the given file name.  If the given file name is
# relative, the given expand path is searched until a matching structure
# definition is found.
#

sub apiEntryExpand
    {
    my $expandLine = shift; # original line
    my $sName = shift;      # type name
    my $hName = shift;      # header file name
    my $dependFlag = shift; # flag for dependency information
    my @ePath = @_;         # expand path

    $expandLine =~ /^(.*)$v/;
    my $loc = $1;

    # start by assembling a list of files that match the given name

    my @fileList = ();

    if ( $hName =~ m:^(/|\\): )
        {

        # file name is relative to WIND_BASE, and is entire search path

        if ( "$::windBase" eq "" )
            {
            print STDERR "$loc: ERROR: WIND_BASE not defined, needed by EXPAND\n";
            $::errorStatus = 1;
            return "$loc$v" . "EXPAND failed for $sName";
            }

        my $fileName = $::windBase . $hName;

        if ( not -e $fileName )
            {
            print STDERR "$loc: ERROR: EXPAND file does not exist: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "EXPAND failed for $sName";
            }
        if ( not -T $fileName )
            {
            print STDERR "$loc: ERROR: EXPAND file is not a text file: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "EXPAND failed for $sName";
            }
        if ( not -r $fileName )
            {
            print STDERR "$loc: ERROR: EXPAND file cannot be read: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "EXPAND failed for $sName";
            }

        push @fileList, apiAbsoluteForce($::windBase . $hName);
        }
    else
        {

        # file name is relative to the directories in $ePath

        foreach $dir (@ePath)
            {
            my $fileName = $dir . '/' . $hName;

            if ( (-T $fileName) and (-r $fileName) )
                {
                push @fileList, apiAbsoluteForce($fileName);
                }
            }

        if ( scalar(@fileList) == 0 )
            {
            print STDERR "$loc: ERROR: EXPAND file not found: $hName\n";
            $::errorStatus = 1;
            return "$loc$v" . "EXPAND failed for $sName";
            }
        }

    # look in each file for the definition of the structure

    foreach $file (@fileList)
        {
        my $fileText = apiFileGrab($expandLine, $file);
        my $mark = chr(129);
        $fileText =~ s/typedef/$mark/g;
        if ( $fileText =~
            /\n([^$v]*$v$mark\s+(struct|enum)\s[^$mark]*\}\s*$sName;[^\n]*\n)/ )
            {
            if ( not $dependFlag )
                {
                
                my $definition = $1;
                $definition =~ s/$mark/typedef/g;
                return $definition;
                }
            else
                {
                my @dups = grep { $_ eq $file } @apiDependList;
                my $numDups = @dups;

                if ( $numDups > 0 )
                    {
                    return "";
                    }

                push @apiDependList, $file;
                return $file;
                }
            }
        }

    # didn't find the definition

    print STDERR "$loc: ERROR: EXPAND definition not found: $sName\n";
    $::errorStatus = 1;
    return "$loc$v" . "EXPAND failed for $sName";
    }


###############################################################################
#
# apiClassExpand - locate and import text for \IMPLEMENTS directive
#
# This routine searches for a class header file and includes its entire text
# in place of the \IMPLEMENTS directive.  This routine carries some unnecessary
# baggage because it is a stripped-down version of apiEntryExpand.
#

sub apiClassExpand
    {
    my $classLine  = shift; # original text line
    my $hName      = shift; # header file name
    my $dependFlag = shift; # flag for dependency information
    my $dirName    = shift; # name of file directory

    $classLine =~ /^(.*)$v/;
    my $loc = $1;

    # start by assembling a list of files that match the given name

    my @fileList = ();

    if ( $hName =~ m:^(/|\\): )
        {

        # file name is relative to WIND_BASE, and is entire search path

        if ( "$::windBase" eq "" )
            {
            print STDERR "$loc: ERROR: WIND_BASE not defined, needed by IMPLEMENTS\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }

        my $fileName = $::windBase . $hName;

        if ( not -e $fileName )
            {
            print STDERR "$loc: ERROR: IMPLEMENTS file does not exist: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }
        if ( not -T $fileName )
            {
            print STDERR "$loc: ERROR: IMPLEMENTS file is not a text file: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }
        if ( not -r $fileName )
            {
            print STDERR "$loc: ERROR: IMPLEMENTS file cannot be read: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }

        push @fileList, apiAbsoluteForce($::windBase . $hName);
        }
    else
        {

        # file name is relative to the current directory

	my $fileName = $dirName . "/" . $hName;
        if ( not -e $fileName )
            {
            print STDERR "$loc: ERROR: IMPLEMENTS file does not exist: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }
        if ( not -T $fileName )
            {
            print STDERR "$loc: ERROR: IMPLEMENTS file is not a text file: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }
        if ( not -r $fileName )
            {
            print STDERR "$loc: ERROR: IMPLEMENTS file cannot be read: $fileName\n";
            $::errorStatus = 1;
            return "$loc$v" . "IMPLEMENTS failed for $hName";
            }

	push @fileList, apiAbsoluteForce($fileName);
	}

    if ( scalar(@fileList) == 0 )
	{
	print STDERR "$loc: ERROR: IMPLEMENTS file not found: $hName\n";
	$::errorStatus = 1;
        return "$loc$v" . "IMPLEMENTS failed for $hName";
	}

    # import the file (there should only be one in the list)

    foreach $file (@fileList)
        {
        my $fileText = apiFileGrab($classLine, $file);
	if ( not $dependFlag )
	    {
	    return $fileText;
	    }
	else
	    {
	    my @dups = grep { $_ eq $file } @apiDependList;
	    my $numDups = @dups;

	    if ( $numDups > 0 )
		{
		return "";
		}

	    push @apiDependList, $file;
	    return $file;
            }
        }
    }

1;  # ugly necessity for putting this file in 'require' directive
