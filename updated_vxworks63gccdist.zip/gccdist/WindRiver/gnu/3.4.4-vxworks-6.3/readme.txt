Installation and Licensing

Please refer to the Developer Install Guide included in your shipment for details on how to install and activate this software. Further information can also be found online at http://www.windriver.com/licensing


Host Requirements

For important information regarding this product's host and operating system requirements, see the release notes supplied with this product. These release notes are also available on the product's support Web pages.


Support

Up-to-date information on known problems, patches, and reference documentation can be obtained online.  Log on to Wind River's Online Support page at the URL below and navigate to the support pages for your product.

http://www.windriver.com/support

If you do not know your Wind River Support login, contact support@windriver.com.


CD details

For reference, the mediaId file on this CD contains the CD name, ID number, and manufacturing date.


readme.txt
v0506
