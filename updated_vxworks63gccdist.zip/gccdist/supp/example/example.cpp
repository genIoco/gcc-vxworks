#include <stdio.h>

class exampleclass {
	int exampleConstant;
public:
	exampleclass() {
		printf("exampleclass constructing\n");
		exampleConstant=5;
	}
	~exampleclass() {
		printf("exampleclass destructing\n");
	}
	int get() {
		return exampleConstant;
	}
	void set(int c) {
		exampleConstant = c;
	}
};

exampleclass gExample;

extern "C" double exampleFunction(double x, double y) {
	return x*y + (double) gExample.get();
}

extern "C" void exampleSetFunction(int c) {
	gExample.set(c);
}
