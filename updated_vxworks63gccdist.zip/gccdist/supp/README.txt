VxWorks compatibility
---
This gcc distribution is meant to be used with LabVIEW RT 8.5 controllers
ONLY. 


Installing the gcc redistributable
---
Unzip this zip file to a hard drive location such as c:\gccdist.
In the directory supp\ underneath this, edit setup-gcc.bat to set GCCPATH
to be the unzip location.

Run setup-gcc.bat in a command shell to allow the use of the gcc toolchain
and the versions of make and several GNU utils distributed with Wind River's
version of gcc.


Building and running the example code
---
After running setup-gcc.bat, enter the example\ directory and type make.
The file PPC603gnu\example.out should be generated. FTP this to your
VxWorks controller's ni-rt/system directory. Open
example\example.lvproj in LabVIEW 8.20 (or later) and adjust the IP 
address of the cRIO target to match your own. Finally, open and run
example.vi, which calls two functions in example.cpp. Compare the source code
with the VI output to ensure proper operation.

Consult "Developing Shared Libraries for CompactRIO-901x and Other VxWorks
Controllers" for more information on developing on LabVIEW RT controllers
running VxWorks.

