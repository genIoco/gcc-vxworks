# apiInC.pl - C language specifics for apigen
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01e,30sep04,wsl  add line numbers to error messages, SPR 93816
# 01d,14sep04,wsl  fix SPR 97660, spaces at end of routine separator comment
#                  cause loss of routine
# 01c,21mar03,wsl  add langSynopsisRequired variable
# 01b,20mar03,wsl  make pattern for start of routine more specific
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This script sets up the variables and routines required for handling input
# files in the C language and relatives like C++ and IDL.
#
# The following variables must be defined by any "apiIn" file:
# \is
# \i $langLibStart
# Pattern that starts a library header
# (line-oriented - see apiInC.pl for an example).
# Used to find the beginning of real text in libraries.
#
# \i $langCommentEnd
# String that ends a comment
# (string-oriented - like '\*\/' or "").
# Used to eliminate the comment end from title line.
#
# \i $langHeaderEnd
# Pattern that ends a comment header
# (line-oriented - like '\*\/$' or '\s*([^#].*)?$').
# Used to find the end of all comment headers.
#
# \i $langCommentPrefix
# String that begins lines in continuing comment
# (string-oriented - like '\*' or '#').
# Used to remove markup at the start of each routine line.
#
# \i $langRoutineStart
# Pattern that starts a routine's comments
# (text-oriented - like '\/\*{11,}\n' or '#{11,}\n').
# Used to split the file into routines.
#
# \i $::langIncludesRequired
# Flag indicating that a missing INCLUDES section is an error.
#
# \i $::langSynopsisRequired
# Flag indication that a missing SYNOPSIS section is an error.
#
# \i $::langReturnsRequired
# Flag indicating that a missing RETURNS section is an error.
#
# \i $::langErrnoRequired
# Flag indicating that a missing ERRNO/ERRORS section is an error.
#
# \i $::blankWhenNoRoutines
# Logical flag, when non-zero, no ROUTINES section is printed when there
# are no documented routines.  When zero, the ROUTINES section says
# "No user-callable routines".
# \ie
#
# The following routines must be defined by any "apiIn" file:
# \is
# \i apiLangInit()
# Set the required global variables.
# \i apiPreprocess (@textLines)
# Do any processing necessary before removing any comment characters
# \i apiSynopsisGet($text)
# Return the synopsis extracted from the code text.
# \ie
#
# NOROUTINES
#

# specify namespace

package inC;

###############################################################################
#
# apiLangInit - initialize for processing of C-language files
#
# This routine just sets the values of some variables.  These variables are
# documented in the header for the routine apiExtract().
#

sub apiLangInit
    {
    $extract::langLibStart      =
         '\s*([A-Z][-,_A-Z0-9\s]*($|\:)|\\\\h\s.*|\\\\TITLE.*|\.TH.*|\.SH.*)';
    $extract::langCommentEnd    = '\*\/';
    $extract::langHeaderEnd     = '\*\/\s*$'; # '
    $extract::langCommentPrefix = '(\*|\/\/)';
    $extract::langRoutineStart  = '\/\*{11,}\s*\n|\n\/{12,}\s*\n';
                       # note that this pattern must not contain any
                       # grouped (parenthesized) subpatterns

    $::langIncludesRequired = 1;
    $::langSynopsisRequired = 1;
    $::langReturnsRequired  = 1;
    $::langErrnoRequired    = 1;

    $::blankWhenNoRoutines = 0;
    }


###############################################################################
#
# apiPreprocess - do any preprocessing required by the input format
#
# This routine is not needed for C or its cousins.  It is executed once for
# each routine.
#

sub apiPreprocess
    {
    return @_;
    }


###############################################################################
#
# apiSynopsisGet - find and format a C synopsis
#
# This routine simply calls the vanilla version in apigen2.pl.
#

sub apiSynopsisGet
    {
    return extract::apiLangCLikeSynopsisGet(@_);
    }

1;
