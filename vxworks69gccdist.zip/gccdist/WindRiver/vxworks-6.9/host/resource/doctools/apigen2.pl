# apigen2.pl - remove input language dependencies
#
# Copyright (c) 2003-2005 Wind River Systems, Inc.
#
# The right to copy, distribute, modify or otherwise make use
# of this software may be licensed only pursuant to the terms
# of an applicable Wind River license agreement.
#
# modification history
# --------------------
# 01p,31jul09.mmg  handle fully qualified function pointer arguments
# 01o,19oct07,???  change format of routine-like comment error message
# 01n,12oct07,???  include filename in error message when run on .i file
# 01m,10oct05,lei  suppressed error message for NOMANUAL routines SPR 112278
# 01l,25aug05,dlk  Handle _WRS_INITTEXT or _WRS_FASTTEXT in
#                  apiLangCLikeSynopsisGet. These must be on a separate line
#                  preceeding the rest of the definition.
# 01k,16jun05,khs  Changed 'Error: bad formatting' to just warning 
# 01j,09nov04,joe  Change header check to use spaces before { (SPR 104220)
# 01i,06oct04,wsl  allow comment on routine declaration, SPR 102335
# 01h,05oct04,wsl  fix format of error messages
# 01g,30sep04,wsl  add line numbers to error messages, SPR 93816
# 01f,22sep04,wsl  SPR 94608, suppress errors for NOMANUAL routines
# 01e,22sep04,wsl  SPR 101642, handle illegal comments better
# 01d,15sep04,wsl  fix SPRs 93808, 97554, 97902: handle mod hist section
#                  separately
# 01c,21mar03,wsl  print error when prototype looks wrong
# 01b,20mar03,wsl  change error to warning when synopsis cannot be found
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This group of subroutines removes all input language dependencies
# from the input text.  The result is text containing refgen markup
# and possibly nroff markup, but no artifacts of the input language,
# and no source code.  If the synopses must be found in the source code,
# this is done here, leaving the synopses as marked text.
# The beginnings of routines are marked with lines containing the string
#"\ROUTINE."
#
# The input text is a list of text lines, and the output is a list of
# one library and zero or more routine entries.
#
# NOROUTINES
#

# import the language-dependent packages

require "$::utilPath/apiInAsm.pl";
require "$::utilPath/apiInBsp.pl";
require "$::utilPath/apiInC.pl";
require "$::utilPath/apiInPcl.pl";
require "$::utilPath/apiInScript.pl";

# set the name space

package extract;


###############################################################################
#
# apiExtract - separate the markup from code and comment formats
#
# This routine is the master routine for removing language dependencies.
#
# The following variables must be defined by any "apiIn" file:
# \is
# \i $langLibStart
# Pattern that starts a library header
# (line-oriented - see apiInC.pl for an example).
# Used to find the beginning of real text in libraries.
#
# \i $langCommentEnd
# String that ends a comment
# (string-oriented - like '\*\/' or "").
# Used to eliminate the comment end from title line.
#
# \i $langHeaderEnd
# Pattern that ends a comment header
# (line-oriented - like '\*\/$' or '\s*([^#].*)?$').
# Used to find the end of all comment headers.
#
# \i $langCommentPrefix
# String that begins lines in continuing comment
# (string-oriented - like '\*' or '#').
# Used to remove markup at the start of each routine line.
#
# \i $langRoutineStart
# Pattern that starts a routine's comments
# (text-oriented - like '\/\*{11,}' or '#{11,}').
# Used to split the file into routines.
#
# \i $::langIncludesRequired
# Flag indicating that a missing INCLUDES section is an error.
#
# \i $::langReturnsRequired
# Flag indicating that a missing RETURNS section is an error.
#
# \i $::langErrnoRequired
# Flag indicating that a missing ERRNO/ERRORS section is an error.
#
# \i $::blankWhenNoRoutines
# Logical flag, when non-zero, no ROUTINES section is printed when there
# are no documented routines.  When zero, the ROUTINES section says
# "No user-callable routines".
# \ie
#
# The following routines must be defined by any "apiIn" file:
# \is
# \i apiLangInit()
# Set the required global variables.
# \i apiPreprocess (@textLines)
# Do any processing necessary before removing any comment characters
# \i apiSynopsisGet($text)
# Return the synopsis extracted from the code text.
# \ie
#

sub apiExtract
    {
    $v = $::v; # ubiquitous separator between line number and text

    $moduleName = ""; # global, name of lib or rtn, used for error messages
    $isNoroutines = 0;
    $errorFile = ""; # keeps track of file names for .i file error messages
    $prevErrorFile = ""; # same as above

    if ( $::optionDebug )
        {
        print STDERR "Starting Stage 2 -- extraction\n";
        }

    # initialize to handle the language of the input file

    $apiClassName = "";

    if ( $::apiFileLanguage eq "asm" )
        {
        $langPackage = "inAsm";
        }
    elsif ( $::apiFileLanguage =~ /^(bsp)$/ )
        {
        $langPackage = "inBsp";
        }
    elsif ( $::apiFileLanguage =~ /^(c|cpp|ctcl|idl)$/ )
        {
        $langPackage = "inC";
        }
    elsif ( $::apiFileLanguage =~ /^(perl|shell|tcl)$/ )
        {
        $langPackage = "inScript";
        }
    elsif ( $::apiFileLanguage eq "pcl" )
        {
        $langPackage = "inPcl";
        }
    else
        {
        print STDERR "ERROR: $::apiFileLanguage input format not implemented yet\n";
        $::errorStatus = 1;
        return ();
        }

    eval("$langPackage" . "::apiLangInit()");

    # C++ gets special treatment to compensate for use of // in the past

    if ( $::apiFileLanguage eq "cpp" )
	{
	my $notWarned = 1;
        my $inComment = 0;
	my @outText = ();

	while ( @_ )
	    {
	    $_ = shift;
            /^(.*)$v/o;
            my $loc = $1;

	    if ( m%$v\s*//\s[A-Z]+\s*$%o )
		{
		push @outText, "$loc$v/*";
		while ( s%$v//\s?%$v%o )
		    {
		    push @outText, $_;
		    $_ = shift;
		    }
		push @outText, "$loc$v*/";
		if ( $notWarned )
		    {
		    print STDOUT "$loc: WARNING: headings should not use // style comments\n";
		    $notWarned = 0;
		    }
		}

	    if ( m%$v/{12,}%o )
		{
		push @outText, "$loc$v/" . ('*' x 79);
		$_ = shift;
		while ( s%$v//%$v*%o )
		    {
		    push @outText, $_;
		    $_ = shift;
		    }
		push @outText, "$loc$v*/";
		if ( $notWarned )
		    {
		    print STDERR "$loc: WARNING: headings should not use // style comments\n";
		    $notWarned = 0;
		    }
		}

            if ( /$v\s*\/\*/ )
                {
                $inComment = 1;
                }
            if ( /\*\// )
                {
                $inComment = 0;
                }

	    if ( 0 == $inComment and /$v\s*class\s+(\w+)/ )
		{
		$extract::apiClassName = $1;
		}

	    push @outText, $_;
	    }

	@_ = @outText;
	}

    # separate text into a library and routines

    my @langRoutines = split /\n[^$v]*$v$langRoutineStart/, join("\n", @_);
    my $langLibrary  = shift @langRoutines;

    # process them all separately

    $langLibrary = apiLangLibProcess($langLibrary);

    foreach $routine (@langRoutines)
        {
        $routine = apiLangRtnProcess($routine);
        }

    @langRoutines = grep /./, @langRoutines; # remove empty entries

    if ( $::optionDebug )
        {
        my $debugFile = $::outFileBase . ".2";
        my $debugLines = join "\n", $langLibrary, @langRoutines, "\n";
        $debugLines =~ s/$v/:/go;

        open DEBUG, ">$debugFile";
        print DEBUG $debugLines;
        close DEBUG;

        print STDERR "  Finished Stage 2\n";
        }

    return ($langLibrary, @langRoutines);
    }


###############################################################################
#
# apiLangLibProcess - remove language-dependent markup from library comments
#
# This routine is fairly simple, as all it needs to do is omit lines before
# and after the library comments, then strip any comment markers before the
# lines it keeps.  Note that the library name and description were found
# earlier.
#

sub apiLangLibProcess
    {
    my @inLines = split /\n/, shift;
    my @outLines = ();

    # remove any end-of-comment marker (e.g., */) from title line

    $::apiLibTitle =~ s/\s*$langCommentEnd\s*$//;
    $moduleName = $::apiLibTitle;
    
    # process lines one at a time

    my $firstLine = shift @inLines;
    $firstLine =~ /^(.*)$v/o;
    my $loc = $1;
    unshift @inLines, $firstLine;

    my @outLines = ("$loc$v$::apiLibTitle", "$loc$v");
    my $startFlag = 0;
    $::modDate = "";
    my $inModHist = 0;
    foreach $line (@inLines)
        {
        # process mod hist section in its entirety
        # allow for some misspelling of "modification history"

        $testLine = lc $line;
        if ( $testLine =~ /$v(. )?\s*mod\w{8,10}\s+hist\w{2,4}\s*$/ )
            {
            $inModHist = 1;
            }

        if ( 1 == $inModHist and ($line =~ /$v(. )?(\s*|[A-Z\\].*)$/o or
                                  $line =~ /$langHeaderEnd/ ) )
            {
            # mod hist can end due to a blank line, a blank comment line,
            # a directive, non-indented character text, or a language-
            # specific end-of-section marker (like */ in C)

            $inModHist = 0;
            }

        if ( 1 == $inModHist )
            {
            # look for last modification date

            if ( $::modDate eq "" and
                     $line =~ /$v(. )?\d\d\w,(\d\d)(\w\w\w)(\d\d)/o )
                {
                $::modDate = $2 . " " . (ucfirst $3) . " " . $4;
                }

            next;
            }

        # skip to start of text proper

        if ( not $startFlag and $line =~ /$v$langLibStart/ )
            {
            $startFlag = 1;
            }

        next if not $startFlag;

        last if $line =~ /$langHeaderEnd/;

        $line =~ s/$v$langCommentPrefix ?/$v/;

        if ( $line =~ /$v\\NOROUTINES/ )
            {
            $isNoroutines = 1;
            }
        push @outLines, $line;
        }

    # only fatal error is if there is no text

    if ( scalar(@outLines) == 0 )
        {
        print STDERR "$loc: ERROR: No library description for $::inFile\n";
        $::errorStatus = 1;
        }

    # remove leading blank lines

    my $line = shift @outLines;
    $line = shift @outLines while $line =~ /$v\s*$/o;
    unshift @outLines, $line;

    return join "\n", @outLines;
    }


###############################################################################
#
# apiLangRtnProcess - remove language-dependent markup from routine comments
#
# This routine must do everything that langLibProcess does, plus it must
# extract the synopsis if necessary.  A section named "SYNOPSIS" will override
# this and prevent automatic extraction of a synopsis.
#

sub apiLangRtnProcess
    {
    my @inLines = split /\n/, shift;
    my @outLines = ();
    $isNomanual = $isNoroutines;
        
    $formatWarning = ""; #formatWarning is set false

    # do any required preprocessing

    @inLines = eval("$langPackage"."::apiPreprocess(\@inLines)");

    my $firstLine = shift @inLines;
    $firstLine =~ /^(.*)$v/o;
    my $firstLoc  = $1;
    unshift @inLines, $firstLine;

    # first find out whether routine is NOMANUAL

    if ( ! $isNomanual )
        {
        foreach $line (@inLines)
            {
            last if $line =~ /$v\s*\{/;
            if ( $line =~ /$v\s*$langCommentPrefix\s?\\?NOMANUAL/ ||
                 $line =~ /$v(LOCAL|static)/o )
                {
                $isNomanual = 1;
                last;
                }
            }
        }

    # process lines one at a time

    my @codeLines = ();
    my $inCode = 0;
    my $needSynopsis = $::langSynopsisRequired;
    my $routineName = $::inFile;
    foreach $line (@inLines)
        {
        $line =~ /^(.*)$v/o;
        my $loc = $1;

	# Keeps track of the line if it looks like a file name
	# This is used in error messages for .i files
        if ( $line =~ /^(.*)$v(.*)\/\*\s\w+\.(c|h)\s-(.*)\*\// )
    	    {
    	    $errorFile = (split /\s/, $line)[1];
    	    }

        if ( ! $inCode && $line =~ /$v\\NOMANUAL/o )
            {
            $isNomanual = 1;
            }
        
        if ( (! $inCode) && $line =~ /$langHeaderEnd/ )
            {
            $inCode = 1;
            next;
            }

        if ( $inCode )
            {
            push @codeLines, $line;
            }
        else
            {

            # the comment prefix should always be present
            # (if this changes, use $::apiFileLanguage to be selective)

            if ( $line !~ s/$v$langCommentPrefix ?/$v/ )
                {
                # warn and attempt to correct
		# this used to be an error but now changed to warning

                if ( ! $isNomanual || $::optionInternal )
                    {
		    if (! $formatWarning)
		    {
                    print STDERR "$loc: WARNING: bad formatting of routine comments\n";
		    $formatWarning = '1';
		    }	
                    }
		elsif ( ! $::isWarned )
		    {
		    ::apiPrintWarning();
		    }
                $line =~ s/$v\s*$langCommentPrefix ?/$v/;
                }
            push @outLines, $line;


            # if an explicit synopsis is supplied, we won't need to make one

            $needSynopsis = 0 if $line =~ /$v(\\h\s*)?SYNOPSIS$/o;

            # look for routine name for diagnostics

            if ( ($routineName eq $::inFile) and
                 ($line =~ /$v\s*(\w+[^-]*)\s+-/o) )
                {
                $routineName = $1;
                $moduleName  = $routineName;
                }
            }
        }

    # NOTE: in the following section, the error message will print unless
    # the CURRENT (not the previous) banner has a NOMANUAL under it.  Thus,
    # if a comment in a NOMANUAL routine looks like a routine comment, it
    # will produce an error message. This is appropriate, as there is no way
    # for apigen to be sure that it is not the beginning of a routine.

    if ( $routineName eq $::inFile ) # can't find routine name
        {
        if ( ! $isNomanual || $::optionInternal )
            {
            print STDERR "$firstLoc: ERROR: "; 
	    if ( $::inFile =~ /\.i/ ) # Print the file name with the error for debugging .i files
                {
                print STDERR "Check file \'$prevErrorFile\': ";
                }
	    print STDERR "routine-like comment or else badly formatted routine header\n";

            $::errorStatus = 1;
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }
	$prevErrorFile = $errorFile;
        return "";
        }
    $prevErrorFile = $errorFile;

    my @synopsisLines;
    if ( $needSynopsis )
        {
        @synopsisLines = eval("$langPackage"."::apiSynopsisGet(\@codeLines)");
        if ( scalar(@synopsisLines) == 0 )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$firstLoc: WARNING: cannot make synopsis for $routineName\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            }

        # add synopsis to text -- order will be fixed later

        push @outLines, @synopsisLines;
        }

    # remove leading blank lines

    my $line = shift @outLines;
    $line = shift @outLines while $line =~ /$v\s*$/o;
    unshift @outLines, $line;

    return join "\n", @outLines;
    }


###############################################################################
#
# apiLangCLikeSynopsisGet - find synopsis for C-like languages
#
# This is a vanilla routine for C-like languages.  It should cover
# BSP, C, and IDL files.  It looks at source code and constructs a synopsis.
# This job is somewhat complicated by having to cover C++ as well as C,
# including both comment styles.
#

sub apiLangCLikeSynopsisGet
    {
    
    my $mark  = chr 129;
    my $mark2 = chr 130;
    
    my $firstLine = shift;
    $firstLine =~ /^(.*)$v/;
    my $firstLoc = $1;
    unshift @_, $firstLine;

    # collect the prototype

    my $rtnName = "";
    my @proto = ();
    my @outProto = ("$firstLoc$v", "$firstLoc$v\\h SYNOPSIS",
                    "$firstLoc$v\\cs");
    my $netParens = 0;
    my $inArgs = 0;
    my $loc;

    foreach (@_)
        {

        # skip precompiler directives and blank lines

        next if /$v#/;
        next if /$v\s*$/;

        # skip _WRS_INITTEXT or _WRS_FASTTEXT lines

        next if /$v\s*(_WRS_INITTEXT|_WRS_FASTTEXT)\s*$/;

        # skip down to prototype

        # Note that there are legal C declarations that are not properly
        # interpreted by this, or any, regular expression -- mainly
        # functions returning function pointers.
        
        /^(.*)$v/o;
        $loc = $1;

        if ( not $rtnName )
            {
            if ( /(\w+)\s*(\(.*)?\s*(\/\*.*\*\/)?\s*$/ )
                {
                $rtnName = $1;
                if ( /(LOCAL|static)/ )
                    {
                    $isNomanual = 1;
                    }
                }
            else
                {
                if ( ! $isNomanual || $::optionInternal )
                    {
		    print STDERR "$loc: ERROR: illegal/unrecognizable prototype\n";
		    $::errorStatus = 1;
                    }
                elsif ( ! $::isWarned )
                    {
                    ::apiPrintWarning();
                    }
                return ();
                }
            }

        # add lines to prototype until parentheses balance

        push @proto, $_;
        s/\/\*.*\*\///g;  # remove comments to count parens
        $lefts = s/\(/$mark/g;
        $inArgs = 1 if $lefts > 0;
        $rights = s/\)/$mark/g;
        $netParens += $lefts - $rights;
        last if $inArgs and 0 == $netParens;
    }

    if ( $isNomanual )
        {
        unshift @outProto, "$loc$v\\NOMANUAL";
        unshift @outProto, "$loc$v";
        }

    # if no synopsis was found, return nothing.  If this constitutes an
    # error, it will be handled elsewhere.

    my $numProtoLines = @proto;
    if ( 0 == $numProtoLines || 0 != $netParens)
	{
	return ();
	}

    # If there is only one line in the synopsis, the arguments should be void.
    # If not, attempt to correct, but print error message.

    if ( $numProtoLines == 1 )
	{
	my $protoText = shift @proto;
	if ( $protoText =~ s/\(\s*(void|VOID)?\s*\)([^\)]*)$/\(void\)\2/ )
	    {
	    push @outProto, $protoText;
	    push @outProto, "$firstLoc$v\\ce";
	    return @outProto;
	    }
	else
	    {
            if ( ! $isNomanual || $::optionInternal )
                {
	        print STDERR "$firstLoc: ERROR: must list one argument per line\n";
	        $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }

            # Want to split line at left and right parens and at commas,
            # but only at last set of parens and only at commas not inside
            # brackets (for IDL) or comments.  This requires some contortions.

            $protoText =~ s/[^\n$v]*$v//go; # strip old line numbers

            while ( $protoText =~ s/(\[[^\]]*),/\1$mark/ )
            {
                ;
            }
            $protoText =~ s/\*\//$mark2/g;
            while ( $protoText =~ s/(\/\*[^$mark2]*),/\1$mark/ )
            {
                ;
            }
            $protoText =~ s/$mark2/\*\//g;

            $protoText =~ s/\(([^\(]*)$/\n\(\n\1/;
            $protoText =~ s/,/,\n/g;
            $protoText =~ s/\)([^\)]*)$/\n\)\1/;
            $protoText =~ s/$mark/,/g;

            $protoText =~ s/\n/\n$firstLoc$v/g; # add new line numbers
            $protoText = "$firstLoc$v" . $protoText;

            @proto = split /\n/, $protoText;
	    }
	}
	
    # it can now be assumed that the prototype is (almost) compliant
    # with one parameter per line

    # format first line -- check for left paren on same line

    $_ = shift @proto;
    s/$v\s*/$v/o;
    if ( s/\s*\(\s*$// )  # left paren must be moved to next line
	{
	unshift @proto, "$firstLoc$v(";
	}
    push @outProto, $_;

    # add second line, which should be a single left paren

    $_ = shift @proto;
    if ( not /$v\s*\(\s*$/o )
	{
        if ( ! $isNomanual || $::optionInternal )
            {
	    print STDERR "$firstLoc: ERROR: bad formatting in prototype\n";
	    $::errorStatus = 1;
            }
        elsif ( ! $::isWarned )
            {
            ::apiPrintWarning();
            }
	}
    push @outProto, "$firstLoc$v    (";    

    @proto = grep /$v./o, @proto; # eliminate empty lines

    # variable to track nested levels
    my $nestedLevel = 0;
    my $maxNextedLevel = 0;
    
    # Following lines should be one param per line up to closing paren.
    # These must be handled as a group to format them cleanly.

    # make lists of types, names, and comments

    my @level    = ();
    my @locList  = ();
    my @typeList = ();
    my @argList  = ();
    my @commentList = ();
    foreach (@proto)
    {
        # closing bracket and comment
        if ( m:^(.*)$v\s*(\))\s*(/(\*|/).*)?$: )
        {     
            push @level,       $nestedLevel;
            push @locList,     $1;
            push @typeList,    ")";
            push @argList,     "";
            push @commentList, $3;
            $nestedLevel--;
        }
        # opening bracket and comment
        elsif ( m:^(.*)$v\s*(\()\s*(/(\*|/).*)?$: )
        {    
            $nestedLevel++;
            $maxNextedLevel++;
            push @level,       $nestedLevel;
            push @locList,     $1;
            push @typeList,    "(";
            push @argList,     "";
            push @commentList, $3;
        }
        # type , argument and comment
        elsif ( m:^(.*)$v\s*([^\s/][^/]*?)\s+([^\s/]+)\s*(/(\*|/).*)?$: )
        {   
            push @level,       $nestedLevel;
            push @locList,     $1;
            push @typeList,    $2;
            push @argList,     $3;
            push @commentList, $4;
        }
        # blank line (discard)
        elsif ( /$v\s*$/ )
        {    
            next;
        }
        # comment only
        elsif ( m:^(.*)$v\s*(/(\*|/).*)$: )
        {      
            push @level,       $nestedLevel;
            push @locList,     $1;
            push @typeList,    "";
            push @argList,     "";
            push @commentList, $2;
        }
        # wild card and comment
        # grasping at straws -- picks up ellipses and such in faked entries
        elsif ( m:^(.*)$v\s*([^ /][^/]*?)\s*(/(\*|/).*)?$: )
        {         
            push @level,       $nestedLevel;
            push @locList,     $1;
            push @typeList,    $2;
            push @argList,     "";
            push @commentList, $3;
        }
        else
        {
            if ( ! $isNomanual || $::optionInternal )
            {
                print STDERR "$firstLoc: ERROR: could not decipher argument in $rtnName:\n";
                print STDERR "  $_\n";
                $::errorStatus = 1;
            }
            elsif ( ! $::isWarned )
            {
                ::apiPrintWarning();
            }
            return "";
        }
   }

    s/$v\s*\)/$v    \)/;
    my $lastLine = $_;

    # get maximum lengths for each field

    my $maxTypeLen = 0;
    foreach (@typeList)
        {
        $maxTypeLen = length $_ if length $_ > $maxTypeLen;
        }
    $maxTypeLen = 25 if $maxTypeLen > 25;

    my $maxArgLen = 0;
    foreach (@argList)
        {
        $maxArgLen = length $_ if length $_ > $maxArgLen;
        }
    $maxArgLen = 25 if $maxArgLen > 25;

    my $i;
    my $spacer = 0;
    my $spacer2 = 0;
    for ( $i = 0 ; $i < scalar(@typeList) ; $i++ )
        {
        $spacer = ((($level[$i] + 1) * 4) - 2);
        $spacer2 = ((($maxNextedLevel - $level[$i]) * 4) + 1);
        my $newLine = sprintf("%s%s %-${spacer}"."s %-$maxTypeLen"."s %-$maxArgLen"."s %-${spacer2}"."s %s",
                              $locList[$i], $v, " ", $typeList[$i],
                              $argList[$i], " ", $commentList[$i]); 
        $newLine =~ s/$mark/,/g;        # replace commas in IDL brackets
        push @outProto, $newLine;
        }

    push @outProto, "$firstLoc$v\\ce";
    
    return @outProto;
    }


1;  # ugly necessity for putting this file in 'require' directive
