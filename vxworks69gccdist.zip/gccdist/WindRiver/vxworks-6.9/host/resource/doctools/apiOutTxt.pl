# apiOutTxt.pl - produce plain text (man page) output format from internal XML
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01e,10apr05,zhr  fixed SPR#107847 "division by zero"
# 01d,10jan05,lll  Standalone apigen, SPR#105634 and SPR#104090
# 01c,02oct04,wsl  add line numbers to error messages, SPR 93816
# 01b,24sep04,wsl  add handling of XML <file> tag, part of SPR 101587
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This subroutine takes the internal XML and converts it to plain text
# man pages.
#
# NOROUTINES
#

# set the name space

package txtOut;


###############################################################################
#
# apiGenerate - convert internal XML to text output
#
# This is the master routine for putting the text into 'man page' format.
#

sub apiGenerate
    {
    $v = $::v;

    $indentWidth  = 5;
    $partialWidth = 2;
    $lineWidth  = 80;
    $padWidth   = 2;

    grep s/^.*$v//o, @_; # eliminate line numbers, since no error msgs here
    my $fullText = join "\n", @_;

    # eliminate inachievable and unnecessary markup

    my $tagsDelete = "$::tagBold|$::tagItalic|$::tagLibrary|" .
                     "$::tagRoutine|$::tagFile|$::tagConstant|" .
                     "$::tagUrl|$::tagEmail";
    my $paraTypes = "$::tagPara|$::tagCode|$::tagCodesmall|$::tagDisplay|" .
                    "$::tagTable\\s*.*|$::tagItemlist|$::tagMarkerlist";

    $fullText =~ s/<\/?($tagsDelete)>//go;
    $fullText =~ s/&gt;/>/g;
    $fullText =~ s/&bslash;/\\/g;
    $fullText =~ s/&btick;/\`/g;
    $fullText =~ s/&vbar;/|/g;
    $fullText =~ s/&endash;/-/g;
    $fullText =~ s/\(&nbsp;\)/()/g;
    $fullText =~ s/&nbsp;/ /g;

    # &lt;  must be handled at the last moment to avoid confusion
    # between markup and text, and &amp; must be handled after this

#    $fullText =~ s/&lt;/</g; # problem!  can get confused - should wait
#    $fullText =~ s/&amp;/&/g; # problem!  should wait

    # note that @inLines is global so that the subroutines can access it

    @inLines = split /\n/, $fullText;
    my @outLines = ();

    $outFileName = "$::outFileBase.txt";

    if ( $::optionInternal )
        {

        # remove internal markup (simplifies processing, minimizes errors)

        while (@inLines)
            {
            my $line = shift @inLines;
            $line =~ s/^(<\w+)\s+scope="internal">/\1>/;
            push @outLines, $line;
            }

        @inLines = @outLines;
        @outLines = ();
        }

    # format remaining text

    # The nest indent comes into play with lists.  Entering a list adds to the
    # nest indent, leaving the list undoes this.

    my $numCols;
    my $routineCount = 0;
    my $currIndent   = 0;
    my $blanking     = 0;
    while ( @inLines ) {
        my $line = shift @inLines;
        $line = shift @inLines while $line =~ /^\s*$/;

        if ( $line =~ /^<$::tagLibhead>([^<]*)<\/$::tagLibhead>/o )
            {
            my $libName = $1;
            my $chapName = "Libraries and Utilities";
            my $outLine = $chapName;
            $outLine .= " " x ($lineWidth - (length $chapName) -
                          (length $libName) - 3);
            $outLine .= $libName . "(1)";
            push @outLines, $outLine;
            push @outLines, "";
            }
        elsif ( $line =~ /^<$::tagRtnhead>([^<\(]*)(\(\))?<\/$::tagRtnhead>/o )
            {
            my $rtnName = $1;
            my $chapName = "Routines and Procedures";
            my $outLine = $chapName;
            $outLine .= " " x ($lineWidth - (length $chapName) -
                               (length $rtnName) - 3);
            $outLine .= $rtnName . "(2)";
            push @outLines, "_______________________________________ @@@ ____________________________________";
            push @outLines, "";
            push @outLines, $outLine;
            push @outLines, "";
            }
        elsif ( $line =~ /^<$::tagHeading>([^<]*)<\/$::tagHeading>/o )
            {
            my $heading = $1;
            $heading =~ s/&lt;/</g;
            $heading =~ s/&amp;/&/g;
            push @outLines, $heading;
            }
        elsif ( $line =~ /^<$::tagSubheading>([^<]*)<\/$::tagSubheading>/o )
            {
            $subHeading = $1;
            $subHeading =~ s/&lt;/</g;
            $subHeading =~ s/&amp;/&/g;
            push @outLines, " " x $partialWidth . $subHeading;
            }
        elsif ( $line =~ /^<($::tagLibshort|$::tagRtnshort)>$/ )
            {
            $line = shift @inLines;
            $line =~ s/&lt;/</g;
            $line =~ s/&amp;/&/g;
            $line = " " x $indentWidth . $line;
            push @outLines, $line;
            push @outLines, "";
            shift @inLines; # must be closing markup
            }
        elsif ( $line =~ /^<$::tagRtnlist blanking="yes">/ )
            {
            $blanking = 1;
            }
        elsif ( $line =~ /^<$::tagRtnline>$/ )
            {
            $line = shift @inLines;
            $line = " " x $indentWidth . $line;
            $line =~ s/<$::tagBreak\/>//o;
            $line =~ s/&lt;/</g;
            $line =~ s/&amp;/&/g;
            push @outLines, $line;
            shift @inLines; # must be closing markup
            $routineCount++;
            }
        elsif ( $line =~ /^<\/$::tagRtnlines>$/ )
            {
            if ( $routineCount == 0 )
                {
                if ( $blanking )
                    {
                    pop @outLines; # kill heading
                    }
                else
                    {
                    push @outLines, " " x $indentWidth
                                    . "No user-callable routines";
                    }
                }
            push @outLines, "";
            }
        elsif ( $line =~ /^<($paraTypes)>/ )
            {
            unshift @inLines, $line;
            $currentIndent += $indentWidth;
            push @outLines, chunkGet();
            $currentIndent -= $indentWidth;
            }

        # other markup ignored -- might be better to check for errors
        }

    $fullText = join "\n", @outLines;

    # output to proper file

    open OUTFILE, ">$::outDir/$outFileName";

    print OUTFILE $fullText;
    print OUTFILE "\n";

    close OUTFILE;

    return;
    }

###############################################################################
#
# chunkGet - get a paragraph of any type
#
# This routine reads in an entire paragraph (of types p, code, smallcode,
# table, and so on), formats it, and returns the result.  This routine is
# called recursively, and must be re-entrant.  The global variable @inLines
# is used as input.
#
# NOTE: chunkGet() must never return without having read in at least one line
# of input.  If it does, an infinite loop will result.
#

sub chunkGet
    {
    my $line = shift @inLines;
    $line = shift @inLines while $line =~ /^\s*$/;

    my @outLines = ();

    if ( $line =~ /^<$::tagPara>/o )
        {
        my $tag = $1;
        my @paraLines = ();
        $line = shift @inLines;
        until ( $line =~ /^<\/$::tagPara>/ or not scalar(@inLines) )
            {
            $line =~ s/&lt;/</g;
            $line =~ s/&amp;/&/g;
            push @paraLines, $line;
            $line = shift @inLines;
            }
        push @outLines, paraFormat(@paraLines);
        }
    elsif ( $line =~ /^<($::tagCode|$::tagCodesmall|$::tagDisplay)>$/ )
        {
        my $tag = $1;
        $line = shift @inLines;
        until ( $line =~ /^<\/$tag>/ or not @inLines )
            {
            $line =~ s/&lt;/</g;
            $line =~ s/&amp;/&/g;
            if ( $hangIndent )
                {
                $line = $hangIndent . $line;
                $hangIndent = "";
                }
            else
                {
                $line = " " x $currentIndent . $line;
                }
            push @outLines, $line;
            $line = shift @inLines;
            }
        push @outLines, "";
        }
    elsif ( $line =~ /^<($::tagTable)\s+columns="(\d+)">/ )
        {
        my $tag = $1;
        $numCols = $2; # global variable
        my @tableLines = ();
        $line = shift @inLines;
        until ( $line =~ /^<\/$tag>/ or not scalar(@inLines) )
            {
            $line =~ s/&lt;/</g;
            $line =~ s/&amp;/&/g;
            push @tableLines, $line;
            $line = shift @inLines;
            }
        push @outLines, tableFormat(@tableLines);
        }
    elsif ( $line =~ /^<$::tagItemlist>/o )
        {
        push @outLines, itemListGet();
        }
    elsif ( $line =~ /^<$::tagMarkerlist>/o )
        {
        push @outLines, markerListGet();
        }


    else ## final else 
        {

        ### hyperlinks addition start
        if ( $optionHyperLink )
        {
         # Accept links
         if ( $line !~ /^(.*)href/o )
            {
            print STDERR "INTERNAL ERROR: expected legal openning tag:\n";
            print STDERR "  $line\n";
            $::errorStatus = 1;
            }
        }  
        ### hyperlinks addition end

        else ## if not hyperlinks then do original
        {
        ### original start 
        print STDERR "INTERNAL ERROR: expected legal openning tag:\n";
        print STDERR "  $line\n";
        $::errorStatus = 1;
        }
        ### original end


        } ## final else close


    return @outLines;
    }


###############################################################################
#
# paraFormat - create new line breaks in a paragraph
#
# This routine joins the lines in a paragraph, then splits them to fit
# into the line size.
#

sub paraFormat
    {

    # check for lines beginning with blanks

    my $marker = chr 129;
    
    foreach (@_) {
        if ( /^(\s+)(.*)$/ )
            {
            my $leader = $1;
            my $remainder = $2;
            $leader =~ s/\s/$marker/go;
            $_ = $leader . $remainder;
            }
        }

    my $inText   = join " ", @_;

    # check for an image paragraph

    if ( $inText =~ /<$::tagImage\s+src=\"([^\"]+)\"\s*\/>/ )
         {
         my $imgName = ::dirname($::inFile) . "/" . $1;
         my $newText = "See image file $imgName.";
         $newText =~ s:/:\/:;
         $inText =~ s/<$::tagImage\s+src=\"([^\"]+)\"\s*\/>/$newText/;
         }

    # regroup words into lines

    my @words    = split /\s+/, $inText;
    my @outLines = ();

    return () if not @words; # no extra space for empty paragraphs

    while (@words)
        {

        # start new line

        my $line;
        if ( $hangIndent )
            {
            $line = $hangIndent;
            $hangIndent = "";
            }
        else
            {
            $line = " " x $currentIndent;
            }
        my $lineCount = length $line;

        # if first word is longer than line, split it

        my $break = 0;
        my $word = shift @words;
        $break = 1 if $word =~ s/<$::tagBreak\/>$//o;
        if ( (length $word) + $lineCount > $lineWidth )
            {
            unshift @words, (substr $word, ($lineWidth - $lineCount));
            $word = substr $word, 0, ($lineWidth - $lineCount);
            }
        unshift @words, $word;

        # add as many words as will fit

        while (@words)
            {
            $word = shift @words;
            $break = 1 if $word =~ s/<$::tagBreak\/>$//o;
            if ( $lineCount + (length $word) > $lineWidth )
                {
                unshift @words, $word;
                last;
                }

            $line .= $word;
            $line .= " ";
            $lineCount = length $line;
            last if $break;
            }

        $line =~ s/$marker/ /go;
        $line =~ s/ $//;
        push @outLines, $line;
        }

    push @outLines, "";
    return @outLines;
    }


###############################################################################
#
# tableFormat - convert internal XML table to formatted plain text
#
# This routine formats a table into plain text.  It must ensure that columns
# are wide enough for their widest cells, and break lines in tables if the
# table would be too wide.  Lines are not joined.
#
# If the sum of the maximum column widths is less than the max line size,
# no resizing is necessary.  If resizing is necessary, the algorithm is:
# 1) Compute the width of (hypothetical) equal columns.
# 2) Columns narrower than this width are given their natural widths.
# 3) The remaining space is divided evenly among the remaining columns.
# 4) Steps 2 and 3 are repeated until no more columns can have their natural
#    widths.
#

sub tableFormat
    {
    my $marker = chr 129;

    # fill array of arrays

    my @rows = ();
    my @maxCellSizes = ();
    while (@_)
        {
        my @cells = ();
        my $cellCount = 0;
        while (@_)
            {
            $_ = shift;
            next if /^<$::tagRow>$/;
            last if /^<\/$::tagRow>$/;
            if ( /^<($::tagHcell|$::tagCell)>(.*)<\/\1>$/ )
                {
                my $cell = $2;
                push @cells, $cell;
                my $size = length $cell;
                if ( $size > $maxCellSizes[$cellCount] )
                    {
                    $maxCellSizes[$cellCount] = $size;
                    }
                $cellCount++;
                }
            elsif ( /^<$::tagSpan><$::tagRule\/><\/$::tagSpan>$/ )
                {
                push @cells, $marker;
                last;
                }
            else
                {
                print STDERR "INTERNAL ERROR: malformed table: $_\n";
                }
            }
        push @rows, [@cells];
        }

    # compute width of table

    my $totalWidth = 0;
    my $numCols = 0;
    foreach $size (@maxCellSizes)
        {
        $totalWidth += $size;
        $numCols++;
        }
    $totalWidth += $padWidth*($numCols - 1);

    # resize columns if necessary

    if ( $totalWidth > $lineWidth )
        {
        my $nominalWidth = int $totalWidth/$numCols;;

        my $fits = -1;
        my $oldFits = -2;
        while ( $fits != $oldFits )
            {
            $oldFits = $fits;
            $fits = 0;
            my $fitWidth = $padWidth*($numCols - 1);
            foreach $size (@maxCellSizes)
                {
                if ( $size <= $nominalWidth )
                    {
                    $fits += 1;
                    $fitWidth += $size;
                    }
                }
            if ( $numCols - $fits == 0 )
                {
                $totalWidth -=  int $lineWidth - totalWidth;
                $nominalWidth = int ($totalWidth - $padWidth*($numCols - 1))/$numCols;
                }
            else
                {
                $nominalWidth = int(($lineWidth - $fitWidth)/($numCols - $fits));
                }
            }

        my $cumSize = $padWidth*($numCols - 1);
        foreach $size (@maxCellSizes)
            {
            if ( $size > $nominalWidth )
                {
                $size = $nominalWidth;
                if ( $cumSize + 2*$size > $lineWidth )
                    {
                    $size = $lineWidth - $cumSize; # a horrible kludge, but...
                    }
                }
            $cumSize += $size;
            }
        $totalWidth = $cumSize;
        }

    # output the formatted table

    my @outLines = ();

    my $tableIndent = " " x $currentIndent;
    if ( $hangIndent )
        {
        $tableIndent = $hangIndent;
        $hangIndent = "";
        }
    if ( $totalWidth > ($lineWidth - length($tableIndent)) )
        {
        if ( $tableIndent =~ /\S/ )
            {
            push @outLines, $tableIndent;
            }
        $tableIndent = "";
        }
        
    foreach $rowRef (@rows)
        {
        # must loop over each row until all its data has been printed
        # because it may be necessary to create additional rows

        my $moreData = 1;
        while ( $moreData )
            {
            $moreData = 0;
            my $newLine = $tableIndent;
            my $cellNum = 0;
            foreach $cell (@{$rowRef})
                {
                if ( $cellNum == 0 and ($cell =~ /^$marker$/o) )
                    {
                    $newLine .= "-" x $totalWidth;
                    last;
                    }

                my $cellWidth = $maxCellSizes[$cellNum];
                $newLine .= " " x $padWidth if $cellNum > 0;
                if ( length $cell <= $cellWidth )
                    {

                    # contents fit in cell

                    $newLine .= $cell;
                    $newLine .= " " x ($cellWidth - length $cell);
                    $cell = "";
                    }
                else
                    {

                    # cell must be split

                    $moreData = 1;

                    # split first word of line if it is too wide to fit

                    my $outCell = "";
                    my @words = split /\s+/, $cell;
                    my $word = shift @words;
                    if ( (length $word) > $cellWidth )
                        {
                        unshift @words, substr $word, $cellWidth;
                        $word = substr $word, 0, $cellWidth;
                        }
                    $outCell .= $word;

                    # add as many words as will fit

                    while ( @words )
                        {
                        $word = shift @words;
                        if ( (length $outCell) + (length $word) + 1
                             <= $cellWidth ) {
                            $outCell .= " " . $word;
                            }
                        else
                            {
                            unshift @words, $word;
                            last;
                            }
                        }
                    $newLine .= $outCell;
                    $newLine .= " " x ($cellWidth - length $outCell);
                    $cell = join " ", @words;
                    }

                $cellNum++;
                }

            $newLine =~ s/\s+$//; # remove trailing spaces
            push @outLines, $newLine;
            }
        }

    push @outLines, "";
    return @outLines;
    }


###############################################################################
#
# itemListGet - format an item list that may contain nested paragraphs
#
# This routine reads in and formats an item list.  It works recursively, so
# any paragraph type, including other lists, are allowed.
#

sub itemListGet
    {
    my @outLines = ();
    my $newLine;

    while (1)
        {
        if ( ! scalar(@inLines) )
            {
            print STDERR "INTERNAL ERROR: item list not closed\n";
            $::errorStatus = 1;
            last;
            }

        my $line = shift @inLines;
        last if $line =~ /^<\/$::tagItemlist>/;
        next if $line =~ /^\s*$/;

        # first line must be the item

        if ( $line =~ /^<$::tagItem>(.*)<\/$::tagItem>/ )
            {
            my $item = $1;
            $item =~ s/&lt;/</g;
            $item =~ s/&amp;/&/g;
            $newline = " " x $currentIndent . $item;
            push @outLines, $newline;
            }
        else
            {
            print STDERR "INTERNAL ERROR: missing item in list\n";
            $::errorStatus = 1;
            }

        $line = shift @inLines until $line =~ /^<$::tagItemtext>/;

        $currentIndent += $indentWidth;

        while (1)
            {
            last if ! scalar(@inLines);

            $line = shift @inLines;
            last if $line =~ /^<\/$::tagItemtext>/;
            next if $line =~ /^\s*$/;

            unshift @inLines, $line;
            push @outLines, chunkGet();
            }

        $currentIndent -= $indentWidth;
        }

    return @outLines;
    }


###############################################################################
#
# markerListGet - format a marker list that may contain nested paragraphs
#
# This routine reads in and formats a marker list.  It works recursively, so
# any paragraph type, including other lists, are allowed.
#

sub markerListGet
    {
    my @outLines = ();
    my $newLine;

    # look ahead to find the widest marker

    my $maxMarkerWidth = 0;
    my $nestLevel = 0;
    foreach $line (@inLines)
        {
        last if ($nestLevel == 0) && ($line =~ /^<\/$::tagMarkerlist>/);

        $nestLevel++ if $line =~ /^<$::tagMarkerlist>/;
        $nestLevel-- if $line =~ /^<\/$::tagMarkerlist>/;
        next if $nestLevel > 0;

        if ( $line =~ /^<$::tagMarker>\s*(.*)<\/$::tagMarker>/ )
            {
            my $marker = $1;
            $marker =~ s/\s+$//;
            $marker =~ s/&lt;/</g;
            $marker =~ s/&amp;/&/g;
            if ( length($marker) > $maxMarkerWidth )
                {
                $maxMarkerWidth = length($marker);
                }
            }
        }

    # get one marker at a time

    while (1)
        {
        if ( ! scalar(@inLines) )
            {
            print STDERR "INTERNAL ERROR: marker list not closed\n";
            $::errorStatus = 1;
            last;
            }

        my $line = shift @inLines;
        last if $line =~ /^<\/$::tagMarkerlist>/;
        next if $line =~ /^\s*$/;

        # first line must be the item

        if ( $line =~ /^<$::tagMarker>(.*)<\/$::tagMarker>/ )
            {
            my $marker = $1;
            $marker =~ s/&lt;/</g;
            $marker =~ s/&amp;/&/g;
            # global:
            $hangIndent = (" " x $currentIndent) . $marker;
            $hangIndent .= " " x ($maxMarkerWidth - length($marker)
                                  + $padWidth);
            }
        else
            {
            print STDERR "INTERNAL ERROR: missing marker in list\n";
            $::errorStatus = 1;
            }

        $line = shift @inLines until $line =~ /^<$::tagMarkertext>/;

        $currentIndent += $maxMarkerWidth + $padWidth;

        while (1)
            {
            last if ! scalar(@inLines);

            $line = shift @inLines;
            last if $line =~ /^<\/$::tagMarkertext>/;
            next if $line =~ /^\s*$/;

            unshift @inLines, $line;
            push @outLines, chunkGet();
            }

        $currentIndent -= $maxMarkerWidth + $padWidth;
        }

    return @outLines;
    }


1;  # ugly necessity for putting this file in 'require' directive
