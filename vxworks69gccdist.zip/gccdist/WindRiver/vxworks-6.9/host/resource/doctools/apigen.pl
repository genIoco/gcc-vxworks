# apigen.pl - produce API reference from source code
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01r,30jun05,khs  Add $isTcl (empty by default)
# 01q,16jun05,khs  Add \COMMAND directive
# 01p,10jan05,lll  Standalone apigen, SPR#105634 and SPR#104090
# 01o,07oct04,wsl  handle pre-processed input file, SPR 102362
# 01n,06oct04,wsl  revise item list documentation
# 01m,06oct04,wsl  document variant format for list markup, SPR 102301
# 01l,30sep04,wsl  add line numbers to error messages, SPR 93816
# 01k,30sep04,wsl  remove \lib, \rtn, and \file from documentation
# 01j,24sep04,wsl  update documentation
# 01i,22sep04,wsl  SPR 94608, no errors for internal routines
# 01h,17sep04,wsl  add -set flag, SPR 101589; also add \rtn and \file
# 01g,25may04,tpw  Add -missingok, suppress missing section warnings.
# 01f,10dec03,jdi  doc changes
# 01e,25mar03,wsl  doc update
# 01d,22mar03,wsl  change $patHeading to exclude double colons (class names)
# 01c,21mar03,wsl  minor doc changes
# 01b,21mar03,wsl  make errors in options more fatal
# 01a,06mar03,wsl  written
#
# SYNOPSIS
# \ss
# perl apigen.pl [<options>] <filespec> [<filespec> ...]
# \se
#
# DESCRIPTION
# This utility reads program source files that follow the Wind River coding
# conventions, and produces output in one or more of its available output
# formats.
#
# The <filespecs> can contain the shell metacharacters (* and ?).
#
# OPTIONS
# The following options can be specified on the command line:
# \is
# \i `-lang' <language>
# Programming language of the input file.  Normally the programming
# language is deduced from the file extension.  Valid (case-insensitive
# values are: asm, bsp, c, cpp, ctcl, idl, java, pcl, perl, shell, and tcl.
# \i `-form[at]' <format>
# Output format.  At present, only plain text, HTML, and HTMLdoc are
# supported.  The first -format option overrides the default, others
# are added to an ordered list that must correspond to the -out options.
# The output is produced in each format and saved in the corresponding
# directory.  Valid (case-insensitive) values are: html, htmldoc, text,
# and xml.
# \i `-mg'
# Process the old mangen markup without complaining, even if it doesn't
# seem to be necessary.
# \i `-out' <dir>
# The directory in which the output file will be built.  The first -out
# option overrides the default, others are added to an ordered list that
# must correspond to the -format options.
# The output is produced in each format and saved in the corresponding
# directory.
# \i `-depend[encies]'
# Flag indicating that the output should be a `make' rule for the
# normal output file.  This is valid only when there is only one input
# file, but if there are several -out/-format pairs, the rule covers all
# output files.
# \i `-nameOutFile'
# An obsolete synonym for `-dependencies'.
# \i `-book'
# The quoted name to be used in the top-level TOC for the book in
# which the output information will appear.  This is meaningful only
# for HTML output.
# \i `-chapter'
# The quoted name to be used in the book TOC for the subsection
# (chapter) in which the output information will appear. This is
# meaningful only for HTML output.
# \i `-category'
# A string to be used in several ways, mainly to be added to the
# name of each library and routine to differentiate them from different
# libraries and routines with the same name, as in libraries for various
# BSPs or host platforms.
# \i `-sort'
# Sort the routines by alphabetical order.  Normally engineers choose
# an order based on a more helpful principle, and alphabetical ordering
# is not desirable.
# \i `-fname'
# Include the file name in the library description.
# \i `-int[ernal]'
# Process all comments, including sections marked INTERNAL and routines
# marked NOMANUAL.
# \i `-set' <name>
# Only process conditional text if one of condition <name> is set.  
# `Wind River Employees': In order to avoid collisions and conflicts, always
# coordinate with Tech Pubs if you feel you need a new condition name.
# \i `-strict'
# Assume no obsolete markup.  The default behavior is to convert any
# obsolete markup found, but give an error.  This option allows you to
# use words like NOMANUAL and INTERNAL as section headings.  DO NOT use
# this option on files that will go into the build -- the build does not
# use this flag.
# \i `-nostrict'
# Translate obsolete refgen markup without complaining.  This option
# is intended for the automated build to allow backward compatibility
# without error conditions.
# \i `-missingok'
# Allow missing sections in markup and do not print lots of warnings.
# \i `-debug'
# Save intermediate versions of the text and print some additional
# information.
# \i `hyperlink' 
# Add hyperlinks to build
# \ie
#
# DIRECTIVES
# The following directives can be embedded in the comment headers for libraries
# or routines as appropriate.  They must always be spelled in capital letters,
# and must always be alone on a line.  With the -nostrict option, the older
# `refgen' directives do not require the leading backslash.
# \is
# \i `\\NOROUTINES'
# Appropriate only in the library header comments, this directive makes any
# and all routines NOMANUAL.  If a SYNOPSIS heading is also present in the
# library header comments, the library will be documented as a stand-alone
# utility (there will be no ROUTINES section, and the INCLUDE FILES section
# will not be required).
# \i `\\NOMANUAL'
# Appropriate in routine or library header comments, this directive specifies
# that the comments are <internal> and should not be documented unless the
# -int option is specified.  C routines with `static' or `LOCAL'
# in their definitions are automatically considered internal unless 'SYNOPSIS' 
# is used to override it.
# \i `\\INTERNAL' <heading>
# When used as a section heading, specifies that the section should only be
# printed when the -int option is specified.  If a <heading> is specified,
# it is used as the heading for the section;  otherwise, the heading
# becomes `INTERNAL'.
# \i `\\IFSET' <name1> [<name2>...]
# Only process the routine in which this directive appears if at least one of
# the condition names is set using the `-set' command-line flag.  This
# directive should not normally be used in a library description.  Whenever
# possible, use the makefile to control whether or not a library is documented.
# `Wind River Employees': In order to avoid collisions and conflicts, always
# coordinate with Tech Pubs if you feel you need a new condition name.
# \i `\\IFSET_START' <name1> [<name2>...] and `\\IFSET_END' <comment>
# These directives can be used anywhere to cause the text between them to be
# processed only if at least one of the condition names is specified in a
# command-line `-set' flag.  Conditions may be nested (a necessity with
# the `\\APPEND' and related directives), but nesting should be avoided as it
# can rapidly lead to confusion.  One valid use of nesting is to achieve text
# should be printed only if two different conditions are set.  The comment
# after the `\\IFSET_END' directive can be used for identification.  Repeating
# the conditions given in the corresponding `\\IFSET_START' directive is one
# good use.  There must be a space before the beginning of this comment.
# \i `\\APPEND' <filename>
# The given <filename> is appended to the text to be processed.  Appended
# files can contain \\APPEND directives.
# \i `\\EXPAND' <filename> <typename>
# The definition of the given <typename> name is retrieved from the given
# file.  Only C-style `struct' and `enum' typedefs and C++ classes are
# handled. If the file name begins with a '/', it is interpreted relative
# to WIND_BASE. Otherwise, it's interpretation depends on whether there is
# an \\EXPANDPATH directive.  If there is no \\EXPANDPATH directive, the
# file path is interpreted as being relative to the directory of the file
# containing the \\EXPAND directive;  otherwise, each of the directories
# in the expand path are tried as bases for the given <filename>.
# \i `\\EXPANDPATH' <dirname>[:<dirname>:<dirname>...]
# Specifies a search path for interpreting file names given in \\EXPAND
# directives.  Each <dirname> is tried in turn, looking for a file with
# the given name containing a definition for the given <typename>.
# \i `\\IMAGE' <filename>
# This directive inserts either the image in the given file (for HTML and other
# formats that can be viewed with a browser), or a text reference to the
# given image file.
# \i `\\IMPLEMENTS' <filename>
# This directive inserts the contents of the given file at the point of the
# \\IMPLEMENTS directive.  This is used by C++ files to include headers that
# contain the actual documentation.
# \i `\\TITLE' <newTitle> - <newDescription>
# Override the one-line description of the file with the given title line.
# This directive is used almost exclusively with BSPs.  It allows names that
# are not valid file names, but are more descriptive of the BSP.
# \i `\\LANGUAGE' <langname>
# Override all other indications of what the computer language of the
# file might be.  This is especially useful for CTcl files and C++ files
# with .c extensions.  Valid (case-insensitive) values are: ASM, BSP, C,
# CPP, (<not> C++), CTcl, IDL, Java, PCL, Perl, shell, Tcl.  The backslash
# before LANGUAGE is mandatory even with the -nostrict option.
# \i `\\COMMAND'
# Stop automatic concatenation of () for name.
# Stop automatic regeneration of RETURNS: N/A and ERRNO: N/A
# therefore allow to have no RETURN and ERRNO at all.
# \ie
#
# MARKUP
# The following markup is supported:
#
# \is
# \i All capital letters
# Make this line a section heading. This also occurs if text consisting of
# all capital letters is followed by a colon. Text after the colon becomes
# the first text under the new heading.
# \i \` and/or \'
# Words can be marked as bold by enclosing them in quotes or a back-tick
# and a quote. Words marked as bold are not candidates for automatic
# hyperlinks created by htmlLink.
# \i \< and >
# Words can be marked as italic by enclosing them in angle brackets.
# Book titles in reference lists should use the \\tb markup so that they
# can be rendered differently if an output format allows it.
# \i Blank line
# A blank line is used to separate paragraphs. A blank line should always
# preceed a heading that is not explicitly marked. Otherwise, the heading
# text may be interpreted as part of the preceeding paragraph.
# \i Initial spaces
# Any line that begins with a space causes spaces and line breaks to be
# preserved for that line only. The line remains part of the paragraph,
# and so no vertical space is added. The font is not forced into a fixed-width
# font, so this is not a good way to create a table. It is good for indenting
# a list of short items.
# \i \\\<, \\\>, \\\`, \\\'
# The characters used to make words bold and italic must (except for the >
# sign) be excaped with backslashes.
# \i \\\\
# The escape character, (\) must itself be escaped when one wants to use
# it in ambiguous circumstances-but not otherwise.  (For historical
# reasons, \\/ is also interpreted as a backslash.  Beware.)
# \i &
# This markup is needed exclusively for instances of text that would
# otherwise be misinterpreted as a section heading. For consistency with the
# old refgen rules, other instances are interpreted as plain ampersands. There
# is no need to escape ampersands anywhere in text.
# \i \\bs...\\be
# This markup indicates code that should be rendered in a reduced font, if
# possible. To the best of my knowledge, it is an anachronism. It might be
# useful for code displays that are too wide for the output page, but since
# few of our output formats support reduced font size, this is questionable.
# Within code displays, /\@ and \@/ are replaced with /* and */, but no other
# character or markup substitutions are made. The start and end markers must
# appear on a line by themselves.
# \i \\cs...\\ce
# This markup indicates a standard code display. Within code displays,
# /\@ and \@/ are replaced with /* and */, but no other character or markup
# substitutions are made. The start and end markers must appear on a line by
# themselves.
# \i \\h
# This markup indicates a section heading. It is not necessary for headings
# consisting entirely of capital letters, numbers, and underscores, as these
# are automatically flagged as headings. However, sometimes it is necessary
# to include lower-case letters in a heading, and this markup makes that
# possible.
# \i \\is \\i...\\i... \\ie
# This markup indicates an item list. This is a list of terms or phrases,
# each of which is followed, on the next line, by
# explanatory text. The item term or phrase is on the same line as the \\i
# markup, with the explanatory text normally starting on the next line (but
# see the variant format explained in the following paragraphs). There can be
# any number of items in a list. The \\is and \\ie markers must be on lines
# of their own.
#
# Use item lists for definitions and explanations of terms.  Do not use them
# for numbered or bulleted lists; use a marker list for those.
#
# For short texts, the text following an item can be abbreviated as:
#     \i <item>: <following text>
# The colon must be followed by a space. In contrast to marker lists, the
# colon is required. The colon is
# removed when processed. If you must have an item ending in a
# colon, put it on its own line with the following text on the next line. If
# your item must contain a colon followed by whitespace, or anything else that
# confuses apigen, including quotes, put the item on its own line and
# enclose it in quotes.
#
# The text following an item can contain several paragraphs, and even other
# elements, like tables and code displays.
# \i \\ms \\m...\\m... \\me
# This markup signifies a marker list. The text following the \\m is used as
# if it were a bullet. The text following the marker will appear indented
# to the width of the widest marker, and  starting on the same line as the
# marker. The \ms and \me markers must be on lines by themselves.
# The text following the marker can be typed on the line following the marker,
# but can also be typed on the same line as described in the following
# paragraphs, which can give the source code a cleaner look when the following
# text is short.
#
# Marker lists should be used for numbered and bulleted lists. For lists that
# define terms or explain variables, use an item list.
#
# For short texts, the text following a marker can be put on the same line as
# the marker:
#     \m <marker>: <following text>
# or
#     \m <marker> <following text>
# The colon or end of marker must be followed by whitespace. The colon is
# optional if the marker contains no spaces (it shouldn't), but occasionally
# a colon may add to the readability in the
# code. It is removed when processed. If you must have a marker ending in a
# colon, put it on its own line with the following text on the next line. If
# your marker must contain a colon or anything else that confuses apigen,
# including quotes, you can put the marker on its own line and enclose it in
# quotes, but in this case you probably should be restrained for being a
# danger to yourself and others.
#
# The text following a marker can contain several paragraphs, and even other
# elements, like tables and code displays.
# \i \\sh
# This markup signifies a subheading. The indent for this heading is less than
# that of the body text, and the subheading font size and emphasis are between
# that of a full heading and body text.
# \i \\ss...\\se
# This markup indicates a display of preformatted text that is not code. The
# text is rendered in a fixed-width font, and is subject to all the processing
# that normal text receives except that spaces and line breaks are preserved.
# The markers must be on lines by themselves.
# \i \\tb
# This markup introduces a reference title. The marker must occur at the
# beginning of the line, and all following text on that line is rendered in
# italics.
# \i \\ts...\\te
# This markup introduces a table. Tables have several special rules and markup
# features. Each line following the \ts marker represents a row in the table.
# Columns are delimited by vertical bar (stile) characters. If a stile
# character is required in the table, it can be included with a backslash
# escape (\|). Any row composed entirely of +, - and |characters is
# interpreted as a horizontal rule spanning all columns of the table. Every
# row must have the same number of columns-if any row is shorter than the
# longest, empty cells are added. Rows above the first horizontal rule are
# assumed to be headings, and are rendered in bold if possible (but some
# output formats allow only one or no heading row). If there are no horizontal
# rules, then there are no headings. In the input, columns need not line up,
# but it does make the table much easier to write.
# \ie
#
# \INTERNAL CHANGES
# The only additions since `refgen' are:
# \is
# \i \\h
# Following text, to end of line, is a new section heading regardless of its
# content.
# \i \\lib
# Following non-whitespace characters represent a library name.  Libraries
# with standard names will still be tagged automatically.  UNDOCUMENTED.
# \i \\rtn
# Following non-whitespace characters represent a routine name.  Routines
# are automatically tagged only when followed by parentheses.  UNDOCUMENTED.
# \i \\file
# Following non-whitespace characters represent a file name.  Standard file
# names are tagged, but some don't fit the usual pattern and must be marked
# by hand.  UNDOCUMENTED.
# \i \\ms
# This replaces \\ml for consistency, although \\ml still works.
# \i \\i and \\m enhancement
# Items and markers can now share a line with their following text.  The idea
# is to simplify the markup and enhance the readability of the comments in
# the code.
# \i \\IMAGE
# Following file name is inserted into HTML output as an image file.  For
# other output formats, the file is referenced in text.
# \i \\INTERNAL
# The directive is old, but now a title can optionally follow the directive.
# \i \\LANGUAGE
# This allows a file to specify its input format internally.  This should be
# most useful for CTcl files.  (C files meant to be documented as if they
# were Tcl libraries.)
# \i \\CONDITION <names>, \\CONDITION_START <names>, \\CONDITION_END
# Added to allow one source file to serve for both KERNEL and USER libraries,
# this mechanism can do much more, and may be highly useful.  It might also be
# abused.
# \i -lang option
# This replaces the first half of the -config option, specifying the format
# of the input file.
# \i -form(at) option
# This replaces the last half of the -config option, specifying the format
# or formats of the output files.
# \i -out option
# This has been augmented to allow several output files to be produced in
# one execution.
# \i -depend(encies)
# This option is a more accurate synonym for -outFileName, as it produces
# the dependency part of a 'make' rule.
# \i -strict and -nostrict
# These options allow some flexibility in the degree of backward compatibility.
# \i -missingok
# This is a stopgap to reduce build logs size until the markup can be fixed.
# \i -debug
# An aid to debugging, perhaps even to users.
# \i -set <name>
# Specifies condition names of \\IFSET sections to be processed.
# \ie
#
# \INTERNAL LINE NUMBERS
# One other major addition is line numbers, along with file names, in (almost)
# all the error messages.  This requires adding the line number to each line
# before processing begins.  The line number is separated from the line text by
# a non-printing character represented in all routines as $v.  The short name
# goes against common wisdom, but there are so many references to it that a
# longer name would obscure its purpose.
#
# \INTERNAL PURPOSE
# This utility is designed to replace `refgen'.  It is intended to build on
# what has been learned from several years of using `refgen', and to be more
# systematically designed and implemented.
#
# \INTERNAL DESIGN APPROACH
# This utility consists of an initialization section and five filters that are
# applied to the text of each input file.  The routines for these
# passes are contained in different source files.
# The five passes are:
# \ts
# Filter | File         | Procedure      | Purpose
# -------+--------------+----------------+--------
#        | `apigen.pl'  | entry code     | Initialize/main loop
#        | `apigen0.pl' | N/A            | Assign constants
# 1      | `apigen1.pl' | `apiAssemble'  | Assemble complete input text
# 2      | `apigen2.pl' | `apiExtract'   | Remove input language dependencies
# 3      | `apigen3.pl' | `apiTranslate' | Convert mangen markup (Optional)
# 4      | `apigen4.pl' | `apiParse'     | Convert to internal (XML) markup
# 5      | `apigen5.pl' | `apiGenerate'  | Apply output format
# \te
#
# \INTERNAL WARNINGS
# In several places, non-printing characters are used in regular expressions.
# Be very careful not to trample on these.  The most important is $v, which
# is used to separate the line numbers from the text.  Before using any other
# non-printing characters, grep on the number you are planning on using.
# Non-printing characters begin at chr 128.
#
# \NOROUTINES



# pull in the Perl files for the passes

my @path = split /\/|\\/, $0;
pop @path;
$utilPath = join '/', @path;
$utilPath = "." if "$utilPath" eq "";

require "$utilPath/apigen1.pl";
require "$utilPath/apigen2.pl";
require "$utilPath/apigen3.pl";
require "$utilPath/apigen4.pl";
require "$utilPath/apigen5.pl";

package main;

require "$utilPath/apigen0.pl";

# initialize global variables

# patterns defined for consistency

$v = chr 132;  # Used everywhere to separate line numbers from text.
              # This short name is used because it is ubiquitous.
$patHeading = '([A-Z][-A-Z0-9\s,\(\)\/]{3,})(:\s*([^:].*)?)?';

# defaults

$optionLangDefault       = "c";
$optionFormatDefault     = "html";
$optionMangenDefault     = 0;
$optionNoMangenDefault   = 0;
$optionOutDirDefault     = ".";
$optionDependDefault     = 0;
$optionBookDefault       = "VxWorks API Reference";
$optionChapterDefault    = "OS Libraries";
$optionSortDefault       = 0;
$optionFNameDefault      = 0;
$optionStrictDefault     = 0;
$optionMissingOkDefault  = 0;
$optionInternalDefault   = 0;
$optionDebugDefault      = 0;
#####modified
$optionHyperLinkDefault  = 0;
#####
$optionConfigDefault     = "";
@optionConditionsDefault = ();

$legalExtensions = 'c|cpp|i|idl|java|nr|pcl|pl|ref|s|sh|tcl';
$legalLangs      = 'asm|bsp|c|cpp|ctcl|idl|java|pcl|perl|shell|tcl';
$legalFormats    = 'html|htmldoc|mif|text|txt|xhtml|xml';
$legalDirectives = 'INTERNAL|NOMANUAL|NOROUTINES|APPEND|EXPAND|EXPANDPATH';
$legalDirectives .= '|TITLE|IMPLEMENTS|LANGUAGE|IFSET|IFSET_START';
$legalDirectives .= '|IFSET_END|COMMAND';

# Note that IMAGES is not listed among the legal directives.  This is because
# it is handled more like normal markup.  (All other directives that are not
# processed in the second pass are section terminators.)

%extLanguage = (
                "c"    => "c",
                "cc"   => "cpp",
                "cpp"  => "cpp",
                "i"    => "c",   # Wind River internal (pre-processed files)
                "idl"  => "idl",
                "java" => "java",
                "nr"   => "bsp",
                "pcl"  => "pcl",
                "pl"   => "perl",
                "ref"  => "bsp",
                "s"    => "asm",
                "sh"   => "shell",
                "tcl"  => "tcl"
);

%langName = (
             "asm"   => "Asm",
             "bsp"   => "Bsp",
             "c"     => "C",
             "cpp"   => "Cpp",
             "ctcl"  => "CTcl",
             "idl"   => "Idl",
             "java"  => "Java",
             "pcl"   => "Pcl",
             "perl"  => "Perl",
             "shell" => "Shell",
             "tcl"   => "Tcl"
);

%formatName = (
               "html"    => "HTML",
               "htmldoc" => "HTMLdoc",
               "mif"     => "MIF",
               "text"    => "Text",
               "xml"     => "XML"
);

%formatExtension = (
                    "html"    => "html",
                    "htmldoc" => "html",
                    "mif"     => "mif",
                    "text"    => "txt",
		    "txt"     => "txt",
                    "xhtml"   => "xhtml",
                    "xml"     => "xml"
);

# constants from the environment

if ( exists $ENV{WIND_BASE} )
    {  # no error yet -- only need for APPEND, EXPAND
    $windBase = $ENV{WIND_BASE};
    }
else
    {
    $windBase = "";
    }

# ANSI standard errno codes

@stdErrnoList = (
                 "EPERM",
                 "ENOENT",
                 "ESRCH",
                 "EINTR",
                 "EIO",
                 "ENXIO",
                 "E2BIG",
                 "ENOEXEC",
                 "EBADF",
                 "ECHILD",
                 "EAGAIN",
                 "ENOMEM",
                 "EACCES",
                 "EFAULT",
                 "ENOTEMPTY",
                 "EBUSY",
                 "EEXIST",
                 "EXDEV",
                 "ENODEV",
                 "ENOTDIR",
                 "EISDIR",
                 "EINVAL",
                 "ENFILE",
                 "EMFILE",
                 "ENOTTY",
                 "ENAMETOOLONG",
                 "EFBIG",
                 "ENOSPC",
                 "ESPIPE",
                 "EROFS",
                 "EMLINK",
                 "EPIPE",
                 "EDEADLK",
                 "ENOLCK",
                 "ENOTSUP",
                 "EMSGSIZE",
                 "EDOM",
                 "ERANGE",
                 "EDESTADDRREQ",
                 "EPROTOTYPE",
                 "ENOPROTOOPT",
                 "EPROTONOSUPPORT",
                 "ESOCKTNOSUPPORT",
                 "EOPNOTSUPP",
                 "EPFNOSUPPORT",
                 "EAFNOSUPPORT",
                 "EADDRINUSE",
                 "EADDRNOTAVAIL",
                 "ENOTSOCK",
                 "ENETUNREACH",
                 "ENETRESET",
                 "ECONNABORTED",
                 "ECONNRESET",
                 "ENOBUFS",
                 "EISCONN",
                 "ENOTCONN",
                 "ESHUTDOWN",
                 "ETOOMANYREFS",
                 "ETIMEDOUT",
                 "ECONNREFUSED",
                 "ENETDOWN",
                 "ETXTBSY",
                 "ELOOP",
                 "EHOSTUNREACH",
                 "ENOTBLK",
                 "EHOSTDOWN",
                 "EINPROGRESS",
                 "EALREADY",
                 "EWOULDBLOCK",
                 "ENOSYS",
                 "ECANCELED",
                 "ENOSR",
                 "ENOSTR",
                 "EPROTO",
                 "EBADMSG",
                 "ENODATA",
                 "ETIME",
                 "ENOMSG"
               );


# save current location

$cwDir = cwd();

# state variables

$errorStatus = 0;
$isWarned    = 0;
$isTcl = 0;

# command-line options

$optionLang     = "";                     # (-lang) language of input file
@optionFormat   = ();                     # (-form) list of output formats
$optionMangen   = $optionMangenDefault;   # (-mg) process nroff markup
$optionNoMangen = $optionNoMangenDefault; # (-nomg) do not process nroff markup
@optionOutDir   = ();                     # (-out) list of output directories
$optionDepend   = $optionDependDefault;   # (-dependencies) print make rule
$optionBook     = $optionBookDefault;     # (-book) name of book in top TOC
$optionChapter  = $optionChapterDefault;  # (-chapter) name of chapter in book
$optionCategory = "";                     # (-category) add'l classification
$optionSort     = $optionSortDefault;     # (-sort) sort routines
$optionFName    = $optionFNameDefault;    # (-fname) publish file name
$optionInternal = $optionInternalDefault; # (-int) print internal info
$optionStrict   = $optionStrictDefault;   # (-strict) allow no obsolete markup
$optionMissingOk = $optionMissingOkDefault; # (-missingok) missing sections ok
$optionDebug    = $optionDebugDefault;    # (-debug) print extra debug info
$optionConfig   = $optionConfigDefault;   # (-config) obsolete, now lang/form

################## modified section
$optionHyperLink = $optionHyperLinkDefault; # (-hyperlink) option to make hyperlinks in docs
##################

@optionConditions = @optionConditionsDefault; # (-set) conditional text

# globals defined and/or used in other routines
#
# $::utilPath - directory containing apigen.pl and its associates
# $::inFile - loop variable, but used in other locations
# $::outFileBase - base name (no extension) of output file
# $::apiFileLanguage - input language of the file being processed
# $extract::apiClassName - C++ class name, empty for other languages
# $::libraryTitle - name used in description of library
# $::modDate - last date in modification history
# $::outForm - output format for the specific formatting routine
# $::outDir  - output directory for the formatting routine
# $::blankWhenNoRoutines - controls behavior when no documented routines
# $::langIncludesRequired - if true, error printed when no INCLUDES section
# $::langReturnsRequired - if true, error printed when no RETURNS section
# $::langErrnoRequired - if true, error printed when no ERRNO/ERROR section
# $::optionCommand - if true, customize output for shell command

# read and interpret command-line arguments

my @optionFileList = ();  # list of input files

while ( $_ = shift )
    {
    if    ( /^-lang$/ )               { $optionLang     = lc shift }
    elsif ( /^-form(at)?$/ )          { push @optionFormat, lc shift }
    elsif ( /^-mg$/ )                 { $optionMangen   = 1 }

    #### modified section
    elsif ( /^-hyperlink$/ )          { $optionHyperLink   = 1 }
    #### modified ends

    elsif ( /^-out$/ )                { push @optionOutDir, shift }
    elsif ( /^-depend([ea]ncies)?$/ ) { $optionDepend   = 1 }
    elsif ( /^-book$/ )
        {
        $optionBook = shift;
        $optionBook =~ s/_/ /g;
        }
    elsif ( /^-chapter$/ )
        {
        $optionChapter = shift;
        $optionChapter =~ s/_/ /g;
        }
    elsif ( /^-category$/ )           { $optionCategory = shift }
    elsif ( /^-sort$/ )               { $optionSort     = 1 }
    elsif ( /^-fname$/ )              { $optionFName    = 1 }
    elsif ( /^-int(ernal)?$/ )        { $optionInternal = 1 }
    elsif ( /^-set$/ )
        {
        push @optionConditions, shift;
        }
    elsif ( /^-strict$/ )             { $optionStrict   = 1 }
    elsif ( /^-nostrict$/ )           { $optionStrict   = 0 }
    elsif ( /^-missingok$/ )          { $optionMissingOk = 1 }
    elsif ( /^-debug$/ )              { $optionDebug    = 1 }
    elsif ( /^-config$/ )             { $optionConfig   = lc shift }
    elsif ( /^-exbase$/ )             { die "Obsolete option: $_\n" }
    elsif ( /^-expath$/ )             { die "Obsolete option: $_\n" }
    elsif ( /^-/ )                    { die "Illegal option: $_\n" }
    else                              { push @optionFileList, $_ }
    }

# convert the obsolete -config option

if ( "$optionConfig" ne "" )
    {
    if ( $optionConfig =~ /^(\w+)2(\w+)$/ )
        {
        $optionLang = lc $1 if (lc $1) ne "auto";
        push @optionFormat, lc $2 if (lc $2) ne "default";
        }
    }

# verify options

if ( "$optionLang" ne "" and not $optionLang =~
     /^($legalLangs)$/ )
    {
    print STDERR "Unknown input language option: $optionLang\n";
    $optionLang = "";
    print STDERR "    trying file extension\n";
    $errorStatus = 1;
    }

if ( scalar(@optionFormat) == 0 )
    {
    push @optionFormat, $optionFormatDefault;
    }

foreach $format ( @optionFormat )
    {
    if ( not $format =~ /^($legalFormats)$/ )
        {
        # this error must be fatal because this list must be in sync
        # with the list of output directories
        print STDERR "Unknown output format option: $format\n";
	exit 1;
        }
    }

if ( scalar(@optionOutDir) == 0 )
    {
    push @optionOutDir, $optionOutDirDefault;
    }

if ( scalar(@optionFormat) != scalar(@optionOutDir) )
    {
    print STDERR "ERROR: Unequal lists of output formats and output directories\n";
    exit 1;
    }

# expand list of input files

my @fileList = ();
foreach $fileSpec (@optionFileList)
    {
    if ( not $fileSpec =~ /(\*|\?)/ )
        {  # spec is name not a glob pattern
        if ( -T $fileSpec and -r $fileSpec )
            {
            push @fileList, $fileSpec;
            }
        else
            {
            print STDERR "ERROR: Input file not valid: $fileSpec\n";
            $errorStatus = 1;
            }
        }
    else
        {  # spec is probably a glob pattern
        my $listLength = @globList;
        if ( 0 == $listLength )
            {
            print STDERR "ERROR: No match for: $fileSpec\n";
            next;
            }
        foreach $fileName (@globList)
            {
            push @fileList, $fileName if -T $fileName and -r $fileName;
            }
        }
    }

# eliminate duplicates in input file list

my @sortList = sort @fileList;
@fileList = ();
my $prevFile = "";
foreach $file (@sortList)
    {
    if ( "$file" ne "$prevFile" )
        {
        push @fileList, $file;
        }
    $prevFile = $file;
    }

# -dependencies option valid only with a single input file

my $listLength = @fileList;
if ( $optionDepend and $listLength > 1 )
    {
    die "ERROR: -dependencies valid only for a single input file\n";
    }

# process input files one at a time

foreach $inFile (@fileList)
    {
    $isWarned = 0;

    my @text = assemble::apiAssemble($inFile) or next; # pass 1
    next if $optionDepend;

    @text = extract::apiExtract(@text) or next;        # pass 2

    @text = translate::apiTranslate(@text) or next;    # pass 3

    @text = format::apiParse(@text) or next;           # pass 4

    generate::apiGenerate(@text);                      # pass 5
    }

$errorStatus = 0 if $optionDebug;

exit $errorStatus;


###############################################################################
#
# apiPrintWarning - subroutine to print a generic warning
#
# This routine just prints the warning that a non-published routine has 
# errors in it, and sets the flag indicating that the warning, which should
# only be printed once per input file, has been printed.
#

sub apiPrintWarning
    {
    $::isWarned = 1;
    print STDOUT "WARNING: errors in non-published routines\n";
    }



###############################################################################
# The following subroutines provide support for common utility functions
# without requiring Perl library modules. These routines are written to be
# consistent with the documented functions of the similar Perl modules, 
# but only provide support for Win32 and standard Unix (Linux, Solaris).
###############################################################################


###############################################################################
# cwd() - returns the absolute path of the current working directory using the
#     most natural and safe form for the current architecture. For most systems
#     it is identical to `pwd` (but without the trailing line terminator).
#     cwd() always returns the path using forward slash separator format. 
#
# Usage:
#     $dir = cwd();
#

sub cwd {
    my $cd;

    if ($^O eq 'MSWin32') {
        # use the Windows perl built-in
        $cd = Win32::GetCwd();
        $cd =~ s#\\#/#g ;
    } else { 
        # use the natural and safe form for Solaris, Linux
        $cd = `pwd`;
        chomp($cd) if defined $cd;
    }

    return $cd;
}


###############################################################################
# fileparse() - divides a file specification into three parts:
#     a leading "path", a file "name", and a "suffix".
#     The "path" contains everything up to and including the last directory
#     separator in the input file specification.  The remainder of the input
#     file specification is then divided into "name" and "suffix" based on
#     the optional patterns you specify in "@suffixlist".  Each element of
#     this list is interpreted as a regular expression, and is matched
#     against the end of "name".  If this succeeds, the matching portion of
#     "name" is removed and prepended to "suffix".  By proper use of
#     "@suffixlist", you can remove file types or versions for examination.
#
#     You are guaranteed that if you concatenate "path", "name", and
#     "suffix" together in that order, the result will denote the same
#     file as the input file specification.
#
# Usage:
#     ($name,$path,$suffix) = fileparse($fullname,@suffixlist);
#    or
#     ($name,$path) = fileparse($fullname);
#
#    For example, using Unix file syntax:
#
#        ($base,$path,$type) = fileparse('/virgil/aeneid/draft.book7',
#                                        '\.book\d+');
#    would yield
#
#        $base eq 'draft'
#        $path eq '/virgil/aeneid/',
#        $type eq '.book7'
#

sub fileparse {
  my($fullname,@suffices) = @_;
  my($dirpath,$tail,$suffix,$basename);
  my($taint)   = substr($fullname,0,0);  # Is $fullname tainted?
  my($fstype)  = $^O;
  my($igncase) = ($^O eq 'MSWin32');

  if ($fstype eq 'MSWin32') {
      ($dirpath,$basename) = ($fullname =~ m#^((?:.*[:\\\/])?)(.*)#s);
      $dirpath = '.\\' unless $dirpath;
  } else {  # default to Unix
      ($dirpath,$basename) = ($fullname =~ m#^(.*/)?(.*)#s);
      $dirpath = './' unless $dirpath;
  }

  if (@suffices) {
      $tail = '';
      foreach $suffix (@suffices) {
          my $pat = ($igncase ? '(?i)' : '') . "($suffix)\$";
          if ($basename =~ s/$pat//s) {
              $taint .= substr($suffix,0,0);
              $tail = $1 . $tail;
          }
      }
  }

  $tail .= $taint if defined $tail; # avoid warning if $tail == undef
  wantarray ? ($basename . $taint, $dirpath . $taint, $tail)
            : $basename . $taint;
}


###############################################################################
# basename() - returns the first element of the list produced by calling 
#     fileparse() with the same arguments, except that it always quotes 
#     metacharacters in the given suffixes. It is provided for programmer 
#     compatibility with the Unix shell command basename(1).
# 
# Usage:
#     $basename = basename($fullname,@suffixlist);
#    or
#     $basename = basename($fullname);
#

sub basename {
  my($name) = shift;

  (fileparse($name, map("\Q$_\E",@_)))[0];
}


###############################################################################
# dirname() - returns the directory portion of the input file specification.
#     When using Unix or MSDOS syntax, the return value conforms to the 
#     behavior of the Unix shell command dirname(1).
#
# Usage:
#     $dirname = dirname($fullname);
#

sub dirname {
  my($basename,$dirname) = fileparse($_[0]);
  my($fstype) = $^O;

  if ($fstype eq 'MSWin32') { 
      $dirname =~ s#([^:])[\\\/]*\z#$1#;
      unless ( length($basename) ) {
          ($basename,$dirname) = fileparse($dirname);
          $dirname =~ s#([^:])[\\\/]*\z#$1#;
      }
  } else {  # default to Unix
      $dirname =~ s#(.)/*\z#$1#s;
      unless ( length($basename) ) {
          ($basename,$dirname) = fileparse($dirname);
          $dirname =~ s#(.)/*\z#$1#s;
      }
  }

  $dirname;
}


###############################################################################
# copy() - Copy files or filehandles.
#     The copy function takes two parameters: a file to copy from and a file 
#     to copy to. Either argument may be a string, a FileHandle reference or 
#     a FileHandle glob. Obviously, if the first argument is a filehandle 
#     of some sort, it will be read from, and if it is a file name it will be
#     opened for reading. Likewise, the second argument will be written to
#     (and created if need be). 
#
#     Note that passing in files as handles instead of names may lead to loss
#     of information on some operating systems; it is recommended that you
#     use file names whenever possible. Files are opened in binary mode where
#     applicable. To get a consistent behaviour when copying from a filehandle
#     to a file, use binmode on the filehandle.
#
#     An optional third parameter can be used to specify the buffer size used
#     for copying. This is the number of bytes from the first file, that will
#     be held in memory at any given time, before being written to the second
#     file. The default buffer size depends upon the file, but will generally
#     be the whole file (up to 2Mb), or 1k for filehandles that do not
#     reference files (eg. sockets).
#
#     The copy function returns 1 on success, 0 on failure. $! will be set
#     if an error was encountered.
#
# Usage:
#     copy("file1","file2");
#     copy("file1",\*STDOUT);
#     die("Copy failed!")  unless( copy("file1","file2") );
#

sub copy {
  die("Usage: copy(FROM, TO [, BUFFERSIZE]) ") unless(@_ == 2 || @_ == 3);

  my $from = shift;
  my $to   = shift;
  my $Too_Big = 1024 * 1024 * 2;
  my $from_a_handle = (ref($from)
                    ? (ref($from) eq 'GLOB' || UNIVERSAL::isa($from,'GLOB'))
                    : (ref(\$from) eq 'GLOB'));
  my $to_a_handle   = (ref($to)
                    ? (ref($to) eq 'GLOB'   || UNIVERSAL::isa($to, 'GLOB'))
                    : (ref(\$to) eq 'GLOB'));
  my $Syscopy_is_copy = 1;
  local *syscopy = \&copy;

  if ($^O eq 'MSWin32') {
      $Syscopy_is_copy = 0;
      *syscopy = sub { return Win32::CopyFile(@_, 1); };
  }

  if (!$from_a_handle && !$to_a_handle && -d $to && ! -d $from) {
      if ($to =~ m|\\|) {
          $to .= '\\' . ::basename($from);
      } else {
          $to .= '/'  . ::basename($from);
      }
  }

  if (!$Syscopy_is_copy 
      && !$to_a_handle 
      && !($from_a_handle && $^O eq 'MSWin32')
     )
  {
      return syscopy($from, $to);
  }

  my $closefrom = 0;
  my $closeto   = 0;
  my ($size, $status, $r, $buf);
  local(*_protect) = sub { "./$_[0]" };
  local(*FROM, *TO);
  local($\) = '';

  if ($from_a_handle) {
      *FROM = *$from{FILEHANDLE};
  } else {
      $from = _protect($from) if $from =~ /^\s/s;
      open(FROM, "< $from\0") or goto fail_open1;
      binmode FROM or die "($!,$^E)";
      $closefrom = 1;
  }

  if ($to_a_handle) {
      *TO = *$to{FILEHANDLE};
  } else {
      $to = _protect($to) if $to =~ /^\s/s;
      open(TO,"> $to\0") or goto fail_open2;
      binmode TO or die "($!,$^E)";
      $closeto = 1;
  }

  if (@_) {
      $size = shift(@_) + 0;
      die("Bad buffer size for copy: $size\n") unless ($size > 0);
  } else {
      $size = -s FROM;
      $size = 1024 if ($size < 512);
      $size = $Too_Big if ($size > $Too_Big);
  }

  $! = 0;
  for (;;) {
      my ($r, $w, $t);
      defined($r = sysread(FROM, $buf, $size))
          or goto fail_inner;
      last unless $r;
      for ($w = 0; $w < $r; $w += $t) {
          $t = syswrite(TO, $buf, $r - $w, $w)
              or goto fail_inner;
      }
  }

  close(TO)   || goto fail_open2  if $closeto;
  close(FROM) || goto fail_open1  if $closefrom;

  # Use this idiom to avoid uninitialized value warning.
  return 1;

  # All of these contortions try to preserve error messages...
fail_inner:
  if ($closeto) {
      $status = $!;
      $! = 0;
      close TO;
      $! = $status unless $!;
  }
fail_open2:
  if ($closefrom) {
      $status = $!;
      $! = 0;
      close FROM;
      $! = $status unless $!;
  }
fail_open1:
  return 0;

}
