# apiInScript.pl - Specifics for apigen script input languages
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01e,05oct04,wsl  fix pattern for artificial comment end
# 01d,30sep04,wsl  add line numbers to error messages, SPR 93816
# 01c,14sep04,wsl  fix SPR 97660, extra spaces after routine separator comment
#                  cause loss of routine
# 01b,21mar03,wsl  add langSynopsisRequired variable
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This script sets up the variables and routines required for handling input
# files in the script languages Perl, Shell, and Tcl.
#
# The following variables must be defined by any "apiIn" file:
# \is
# \i $langLibStart
# Pattern that starts a library header
# (line-oriented - see apiInC.pl for an example).
# Used to find the beginning of real text in libraries.
#
# \i $langCommentEnd
# String that ends a comment
# (string-oriented - like '\*\/' or "").
# Used to eliminate the comment end from title line.
# Note that C-style comment ends are sometimes used in old markup
# even for script languages.
#
# \i $langHeaderEnd
# Pattern that ends a comment header
# (line-oriented - like '\*\/$' or '\s*([^#].*)?$').
# Used to find the end of all comment headers.
#
# \i $langCommentPrefix
# String that begins lines in continuing comment
# (string-oriented - like '\*' or '#').
# Used to remove markup at the start of each routine line.
#
# \i $langRoutineStart
# Pattern that starts a routine's comments
# (text-oriented - like '\/\*{11,}\n' or '#{11,}\n').
# Used to split the file into routines.
#
# \i $::langIncludesRequired
# Flag indicating that a missing INCLUDES section is an error.
#
# \i $::langSynopsisRequired
# Flag indication that a missing SYNOPSIS section is an error.
#
# \i $::langReturnsRequired
# Flag indicating that a missing RETURNS section is an error.
#
# \i $::langErrnoRequired
# Flag indicating that a missing ERRNO/ERRORS section is an error.
#
# \i $::blankWhenNoRoutines
# Logical flag, when non-zero, no ROUTINES section is printed when there
# are no documented routines.  When zero, the ROUTINES section says
# "No user-callable routines".
# \ie
#
# The following routines must be defined by any "apiIn" file:
# \is
# \i apiLangInit()
# Set the required global variables.
# \i apiPreprocess (@textLines)
# Do any processing necessary before removing any comment characters
# \i apiSynopsisGet($text)
# Return the synopsis extracted from the code text.
# \ie
#
# NOROUTINES
#

# specify namespace

package inScript;

###############################################################################
#
# apiLangInit - initialize for processing of C-language files
#
# This routine just sets the values of some variables.  These variables are
# documented in the header for the routine apiExtract().
#

sub apiLangInit
    {
    $v = $::v;

    $extract::langLibStart      =
         '#\s*([A-Z][-,_A-Z0-9\s]*($|:)|\\\\h\s.*|\\\\TITLE.*|\.TH.*|\.SH.*)';
    $extract::langCommentEnd    = '\*\/';
    $extract::langHeaderEnd     = "$v" . '([^#]|$)';
    $extract::langCommentPrefix = '#';
    $extract::langRoutineStart  = '#{11,}\s*\n';

    $::langIncludesRequired = 0;
    $::langSynopsisRequired = 0;
    $::langReturnsRequired  = 0;
    $::langErrnoRequired    = 0;

    $::blankWhenNoRoutines = 1;
    }


###############################################################################
#
# apiPreprocess - do any preprocessing required by the input format
#
# This routine is null for script input, returning its input unchanged.
#

sub apiPreprocess
    {
    return @_;
    }


###############################################################################
#
# apiSynopsisGet - find and format a C synopsis
#
# This routine is a dummy.  The synopsis is never taken from the source code
# for scripts.  It must be included in the comments.
#

sub apiSynopsisGet
    {
    return;
    }

1;
