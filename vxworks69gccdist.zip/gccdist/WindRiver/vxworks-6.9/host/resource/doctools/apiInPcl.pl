# apiInPcl.pl - PCL language specifics for apigen
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01f,05oct04,???  fix format of error messages
# 01e,30sep04,wsl  add line numbers to error messages, SPR 93816
# 01d,14sep04,wsl  fix SPR 97660, extra spaces after routine separator comment
#                  cause loss of routine
# 01c,22mar03,wsl  allow numbers in routine names
# 01b,21mar03,wsl  add langSynopsisRequired variable
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This script sets up the variables and routines required for handling input
# files in the PCL format.
#
# The following variables must be defined by any "apiIn" file:
# \is
# \i $langLibStart
# Pattern that starts a library header
# (line-oriented - see apiInC.pl for an example).
# Used to find the beginning of real text in libraries.
#
# \i $langCommentEnd
# String that ends a comment
# (string-oriented - like '\*\/' or "").
# Used to eliminate the comment end from title line.
#
# \i $langHeaderEnd
# Pattern that ends a comment header
# (line-oriented - like '\*\/$' or '\s*([^#].*)?$').
# Used to find the end of all comment headers.
#
# \i $langCommentPrefix
# String that begins lines in continuing comment
# (string-oriented - like '\*' or '#').
# Used to remove markup at the start of each routine line.
#
# \i $langRoutineStart
# Pattern that starts a routine's comments
# (text-oriented - like '\/\*{11,}\n' or '#{11,}\n').
# Used to split the file into routines.
#
# \i $::langIncludesRequired
# Flag indicating that a missing INCLUDES section is an error.
#
# \i $::langSynopsisRequired
# Flag indication that a missing SYNOPSIS section is an error.
#
# \i $::langReturnsRequired
# Flag indicating that a missing RETURNS section is an error.
#
# \i $::langErrnoRequired
# Flag indicating that a missing ERRNO/ERRORS section is an error.
#
# \i $::blankWhenNoRoutines
# Logical flag, when non-zero, no ROUTINES section is printed when there
# are no documented routines.  When zero, the ROUTINES section says
# "No user-callable routines".
# \ie
#
# The following routines must be defined by any "apiIn" file:
# \is
# \i apiLangInit()
# Set the required global variables.
# \i apiPreprocess (@textLines)
# Do any processing necessary before removing any comment characters
# \i apiSynopsisGet($text)
# Return the synopsis extracted from the code text.
# \ie
#
# NOROUTINES
#

# specify namespace

package inPcl;

###############################################################################
#
# apiLangInit - initialize for processing of C-language files
#
# This routine just sets the values of some variables.  These variables are
# documented in the header for the routine apiExtract().
#

sub apiLangInit
    {
    $v = $::v;

    $extract::langLibStart      =
         '\s*([A-Z][-,_A-Z0-9\s]*($|:)|\\\\h\s.*|\\\\TITLE.*|\.TH.*|\.SH.*)';
    $extract::langCommentEnd    = '\*\/';
    $extract::langHeaderEnd     = "\\*\\/\\s*\$";
    $extract::langCommentPrefix = '\*';
    $extract::langRoutineStart  = '\/\*{11,}\s*\n';

    $::langIncludesRequired = 0;
    $::langSynopsisRequired = 1;
    $::langReturnsRequired  = 0;
    $::langErrnoRequired    = 0;

    $::blankWhenNoRoutines = 0;
    }


###############################################################################
#
# apiPreprocess - do any preprocessing required by the input format
#
# This routine is null for PCL input, returning its input unchanged.
#

sub apiPreprocess
    {
    return @_;
    }


###############################################################################
#
# apiSynopsisGet - find and format a PCL synopsis
#
# This routine simply calls the vanilla version in apigen2.pl.
#

sub apiSynopsisGet
    {
    my $firstLine = shift;
    $firstLine =~ /^(.*)$v/o;
    my $firstLoc = $1;

    my @outLines = ("$firstLoc$v", "$firstLoc$v\\h INPUT", "$firstLoc$v\\ss");
    my $rtnOutput = "";

    while ( @_ and $firstLine =~ /$v\s*$/ )
	{
	$firstLine = shift;
	}
    unshift @_, $firstLine;	

    while ( @_ )
        {
        $_ = shift;
        if ( /$v\s*(.*?)\s[A-Z_0-9]+\s*$/ )
            {
            $rtnOutput = $1;
            last;
            }
        }
    if ( $rtnOutput eq "" )
        {
        print STDERR "$firstLoc: ERROR: can't find PCL routine prototype\n";
        $::errorStatus = 1;
        }

    foreach (@_)
        {
        next if /(\(|\))/;
        if ( /^(.*)$v\s*(\w+.*)/ )
            {
            my $line = "$1$v$2";
            $line =~ s/\s+$//;
            if ( $line =~ /$v$::patHeading$/ )
                {
                $line =~ s/$v/$v\&/o;
                }
            push @outLines, $line;
            }
        }

    push @outLines, "$firstLoc$v\\se";
    push @outLines, "$firstLoc$v";
    push @outLines, "$firstLoc$v" . "OUTPUT";
    push @outLines, "$firstLoc$v\\ss";
    if ( $rtnOutput =~ /^$::patHeading$/ )
        {
        $rtnOutput =~ s/^/\&/o;
        }
    push @outLines, "$firstLoc$v$rtnOutput";
    push @outLines, "$firstLoc$v\\se";
    return @outLines;
    }

1;
