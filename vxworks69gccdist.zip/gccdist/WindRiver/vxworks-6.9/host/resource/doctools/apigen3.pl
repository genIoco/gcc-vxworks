# apigen3.pl - translate older markups to the new
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01k,05oct04,wsl  fix reformatting of PARAMETERS section
# 01j,05oct04,wsl  fix error report for mangen markup
# 01i,05oct04,wsl  fix format of error messages
# 01h,01oct04,wsl  add line numbers to error messages, SPR 93816
# 01g,24sep04,wsl  fix recognition of .TH arguments
# 01f,22sep04,wsl  SPR 94608, suppress errors for undocumented routines
# 01e,22sep04,wsl  fix test for legacy mangen markup
# 01d,16sep04,wsl  fix SPR 97003, parsing of PARAMETERS
# 01c,15sep04,wsl  fix SPRs 101870 and 101871, correct legacy markup
# 01b,21mar03,wsl  fix bug in handling PARAMETERS section
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This group of subroutines converts mangen (nroff-style) markup to refgen
# markup and also updates some refgen markup.  If flags or other indicators
# make this conversion unnecessary, it is skipped.
#
# NOROUTINES
#

# set the name space

package translate;


###############################################################################
#
# apiTranslate - convert older markup to the newest
#
# This routine is the master routine for updating markup.  Since there is no
# real difference between the library comments and the routine comments in
# this context, they are treated alike.
#

sub apiTranslate
    {
    $v = $::v;

    $haveName = 0;

    if ( $::optionDebug )
        {
        print STDERR "Starting Stage 3 -- translation\n";
        }

    # decide whether mangen translation should be applied to entire file

    my $mangenPresent = $::optionMangen;
    if ( not $::optionMangen )
        {
        foreach (@_)
            {
            if ( /\n([^$v]*)$v(\.|[^\n]*\\(%|\()|[^\n]*\'\\\")/ )
                {
                my $loc = $1;
                $mangenPresent = 1;
                print STDERR "$loc: ERROR: mangen markup found - translating\n";
                $::errorStatus = 1;
                last;
                }
            }
        }

    if ( not $mangenPresent and $::optionStrict )
        {
        if ( $::optionDebug )
            {
            print STDERR "  Skipping Stage 3 -- not required\n";
            }

        return @_;
        }

    # process each entry

    my @entryList = ();
    foreach $entry (@_)
        {
        my $newEntry = apiEntryTranslate($entry);      # mangen markup
        if ( not $::optionStrict )
            {
            $newEntry = apiEntryModernize($newEntry);  # obsolete refgen markup
            }
        push @entryList, $newEntry;
        }

    if ( $::optionDebug )
        {
        my $debugFile = $::outFileBase . ".3";
        my $debugText = (join "\n", @entryList) . "\n";
        $debugText =~ s/$v/:/go;

        open DEBUG, ">$debugFile";
        print DEBUG $debugText;
        close DEBUG;

        print STDERR "  Finished Stage 3\n";
        }
    return @entryList;
    }


###############################################################################
#
# apiEntryTranslate - convert a single lib/routine entry to new markup
#
# This routine is the workhorse routine for updating markup.  First mangen
# (nroff) markup is translated to refgen markup, then any depricated refgen
# markup is updated.  Both of these can be overridden, and the mangen markup
# is only processed if mangen markup is found in the text or the -mg flag is
# specified.
#
# Note that the list translation must occur before the markup translation
# because it depends on some markers that are removed by the markup
# translation.
#

sub apiEntryTranslate
    {
    $isNomanual = 0;
    $isNomanual = 1 if /$v\\NOMANUAL/;

    my @textLines = split /\n/, shift;

    @textLines = apiTableTranslate(@textLines);

    @textLines = apiListTranslate(@textLines);

    @textLines = apiMarkupTranslate(@textLines);

    @textLines = apiSpecialSectionsTranslate(@textLines);

    return join "\n", @textLines;
    }


###############################################################################
#
# apiTableTranslate - convert all tables in a single library/routine entry
#
# This routine translates tables from mangen style to refgen style.
#

sub apiTableTranslate
    {

    @inLines = @_;

    my $inCode  = 0;
    my $inTable = 0;
    @outLines = ();

    while ( @inLines )
        {
        $_ = shift @inLines;

        # code displays are exempt from all reformatting

        if ( /$v(\\cs|\\bs|\.CS|\.bS)/ )
            {
            $inCode = 1;
            }
        elsif ( /$v(\\ce|\\be|\.CE|\.bE)/ )
            {
            $inCode = 0;
            }

        if ( $inCode )
            {
            push @outLines, $_;
            next;
            }

        # check for erroneous end of table

        if ( /^(.*)$v(\.TE|\.fi)/ )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
	        print STDERR "$1: ERROR: extra end-of-table marker\n";
	        $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
	    next;
            }

        # unless we are starting a table, move on to the next line

        if ( not /$v(\.TS|\.nf)/ )
            {
            push @outLines, $_;
            next;
            }

        # beyond this point we are in a table

        $inTable = 1;
        /^(.*)$v/;
        my $tabLoc = $1;

	# check for formatting info and remove it

	$_ = shift @inLines;
	if ( (! /\t/) && /;\s*$/ )
	    {
	    $_ = shift @inLines until /\.\s*$/;
	    }
	else
	    {
	    unshift @inLines, $_;
	    }

        my $tableCols = -1; # actually number of column separators
        push @outLines, "$tabLoc$v\\ts";

        while ( @inLines )
            {
            $_ = shift @inLines;

	    # translate a change in table format to a table end/table start

	    if ( /^(.*)$v\.T&/ )
		{
		unshift @inLines, "$1$v.TS";
		$_ = "$1$v.TE";
		}

	    # check for end of table

            if ( /^(.*)$v\.(TE|fi)/ )
                {
                push @outLines, "$1$v\\te";
                $inTable = 0;
                last;
                }

            if ( /^(.*)$v[\_=]+[\_= |\t]*$/ )
                {
                # a table rule

                push @outLines, "$1$v-----";
                next;
                }

            # protect embedded vertical bars

            s/($v\\)\|/\1\\\|/g;

            # substitute vertical bars for tabs

            my $numFound = s/\t/ \| /g;

            $tableCols = $numFound if $numFound > $tableCols;

	    if ( /T\{\s*$/ )
		{

		# multiline cell -- turn into extra rows --
		# assumes that multiline cell is last in row

		s/T\{\s*$//;
                /^(.*)$v/;
                my $loc = $1;
		my $line = shift @inLines;
		while ( $line !~ /$v\s*T\}/ )
		    {
                    $line =~ s/^.*$v//g;
		    $_ .= $line;
		    push @outLines, $_;
                    $_ = "$loc$v";
		    $_ .= " | " x $tableCols;
		    $line = shift @inLines;
		    }
		}
	    else
		{
		push @outLines, $_;
		}
            }

        if ( $inTable )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                /^(.*)$v/;
                my $loc = $1;
                print STDERR "$loc: ERROR: Table not properly ended\n";
                $::errorStatus = 1;
                push @outLines, "$loc$v\\te";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            $inTable = 0;
            }
        }

    return @outLines;
    }


###############################################################################
#
# apiListTranslate - convert all lists in a single library/routine entry
#
# This routine translates lists from mangen style to refgen style.  Note that
# we must guess whether something is a marker list or an item list.
#

sub apiListTranslate
    {

    @inLines = @_;

    my $inCode  = 0;
    my $inList = 0;  # 0 = not in list, 1 = in marker list, 2 = in item list
    @outLines = ();

    while ( @inLines )
        {
        $_ = shift @inLines;

        # code displays are exempt from all reformatting

        if ( /$v(\\cs|\\bs|\.CS|\.bS)/ )
            {
            $inCode = 1;
            }
        elsif ( /$v(\\ce|\\be|\.CE|\.bE)/ )
            {
            $inCode = 0;
            }

        if ( $inCode )
            {
            push @outLines, $_;
            next;
            }

        # unless we are starting a list, move on to next line

        if ( not /$v\.[iI]P/ )
            {
            push @outLines, $_;
            next;
            }

        # beyond this point we are in a list

        unshift @inLines, $_;  # put line back in order to simplify later code

        while ( @inLines )
            {

            $_ = shift @inLines;

            # the end of a list can be indicated by several things:
            # - an explicit end (.lE -- I think -- no documentation)
            # - an explicit non-list paragraph (.LP -- no refgen equivalent)
            # - a section heading (.SH or \h if markup is mixed)
            # - a section subheading (.SS or \sh if markup is mixed)
            # - an implied heading in all caps
            # - a directive

            if ( /$v(\.lE|\.LP|\.SH|\.SS|$::patHeading$|\\?[A-Z]+$|\\h|\\sh)/ )
                {
                unshift @inLines, $_;
                last;
                }

            # if we are not at the start of a list, move on

            if ( not /$v\.[iI]P\s*(\"[^\"]+\"|[^\s\"]+)?/ )
                {
                # add follow-on text

                push @outLines, $_;
                next;
                }

            # start of new list entry

            my $mark   = $1;
            $mark =~ s/^\"//;
            $mark =~ s/\"$//;

            /^(.*)$v/;
            my $loc = $1;

            if ( not $mark )
                {
                $mark = '-';
                }

            if ( not $inList )
                {
                # marker list

                if ( $mark =~ /^[- 0-9\.()]+$/ )
                    {
                    $inList = 1;  # marker list
                    push @outLines, "$loc$v\\ms";
                    }
                else
                    {
                    $inList = 2;  # item list
                    push @outLines, "$loc$v\\is";
                    }
                }

            # add the new entry to the list

            my $newLine;
            if ( 1 == $inList )
                {
                $newLine = "$loc$v\\m ";
                }
            else
                {
                $newLine = "$loc$v\\i ";
                }

            if ( 2 == $font )
                {
                $newLine .= "<$mark>";
                }
            elsif ( 3 == $font )
                {
                $newLine .= "`$mark'";
                }
            else
                {
                $newLine .= $mark;
                }
            push @outLines, $newLine;               
            }

        /^(.*)$v/;
        my $loc = $1;

        if ( 1 == $inList )
            {
            push @outLines, "$loc$v\\me";
            }
        elsif ( 2 == $inList )
            {
            push @outLines, "$loc$v\\ie";
            }
        else
            {
            print STDERR "$loc: INTERNAL ERROR: end of list with no start\n";
            }

        $inList = 0;
        }

    return @outLines;
    }


###############################################################################
#
# apiMarkupTranslate - convert a single lib/routine entry to new markup
#
# This routine translates all of the logistically simple markup.  This
# excludes lists and tables, which require some parsing.
#

sub apiMarkupTranslate
    {

    my @inLines = @_;

    my $inCode = 0;
    my @outLines = ();
    while (@inLines)
        {
	$line = shift @inLines;

        # code displays are exempt from most reformatting

        if ( $line =~ /$v(\\ce|\\be|\.CE|\.bE)/ )
            {
            $inCode = 0;
            }

        if ( $inCode )
            {

	    # lines beginning with a period are formatting commands that
	    # should be removed

	    next if $line =~ /$v\.\w/;

            push @outLines, $line;
            next;
            }

        # lines to kill outright

        if ( $line =~ /\'\\\" t / )
            {  # mystery markup
            next;
            }
        if ( $line =~ /${v}SECTION:\s+\w+\s*$/ )
            {
            # directive is obsolete, and should be ignored
            # it once set a chapter number in the page header
            next;
            }

        # markup to replace within a line

        $line =~ s:\\e:\\\\:g;       # fix roff backslash
        $line =~ s:\\%::g;           # do not hyphenate -- not needed
        $line =~ s:\\\(mi: - :g;     # minus sign
        $line =~ s:\\\(mu:x:g;       # multiplication sign
        $line =~ s:\\\(rg:\\reg:g;   # registered trademark sign
        $line =~ s:\\\(co:\\copy:g;  # copyright sign
        $line =~ s:\\f2([^\\]*)\\f[1P]:<\1>:g;    # italic font change
        $line =~ s/\\f3([^\\]*)\\f[1P]/\`\1\'/g;  # bold font change

	# \f2...\f1 can span lines.  If so, join lines.

	if ( $line =~ /(\\f[23])/ )
	    {
            my $marker = $1;
	    my $nextLine = shift @inLines;
	    if ( $nextLine =~ /$v(.*\\f[1P]\s*)(.*)/o )
		{
                $nextLine =~ s/^.*$v//o;
		$line .= " " . $nextLine;
		unshift @inLines, $line;
		next;
		}
	    else
		{
                unshift @inLines, $nextLine;
		$line =~ s/(\\f[23])/\[unmatched \1\]/;
                if ( ! $isNomanual || $::optionInternal )
                    {
                    $line =~ /^(.*)$v/o;
		    print STDERR "$1: ERROR: unmatched $marker\n";
                    }
                elsif ( ! $::isWarned )
                    {
                    ::apiPrintWarning();
                    }
		}
	    }

	# a few old bits of markup seem unwise but necessary for backward
	# compatibility

        my $badIdea =
            " and BSP-specific reference pages for this routine.";
        $line =~ s/\.sA/$badIdea/;   # one horrible legacy

        # update directives

        $line =~ s/$v\s*(APPEND\s|EXPAND\s|EXPANDPATH\s|IMPLEMENTS\s)/$v\\\1/;
        $line =~ s/$v\s*(INTERNAL|NOMANUAL|NOROUTINES)/$v\\\1/;

        # handle markup affecting entire line if necessary

        if ( not $line =~ /^(.*)$v\.(\S+)\s*(.*)$/ )
            {
            push @outLines, $line;
            next;
            }

        my $loc     = $1;
        my $mark    = $2;
        my $content = $3;

        # The following is a Perl-style switch statement.
        # It handles any translation that does not require reformatting
        # (the exceptions being tables and lists).
        # The order of the patterns should be some approximation to
        # the frequency of occurrence.

        for ($mark)
            {

            # paragraphs

            /^[LP]P$/ and do
                {
                push @outLines, "$loc$v";  # new paragraph
                last;
                };
            /^tS$/    and do
                {
                push @outLines, "$loc$v\\ss";  # display paragraph
                last;
                };
            /^tE$/    and do
                {
                push @outLines, "$loc$v\\se";  # end display
                last;
                };
            /^CS$/    and do
                {
                $inCode = 1;
                push @outLines, "$loc$v\\cs";  # code paragraph
                last;
                };
            /^CE$/    and do
                {
                push @outLines, "$loc$v\\ce tag1";  # end code
                last;
                };
            /^bS$/    and do
                {
                $inCode = 1;
                push @outLines, "$loc$v\\bs";  # small code paragraph
                last;
                };
            /^bE$/    and do
                {
                push @outLines, "$loc$v\\be";  # end small code
                last;
                };
            /^[iI]P$/ and do
                {
                push @outLines, "$loc$v.$_";  # should have been handled by now
                last;
                };

            # headings

            /^SS$/    and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                push @outLines, "$loc$v\\sh $content";  # subheading
                last;
                };
            /^SH$/    and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                if ( $content eq "NAME" and 1 == $haveName )
                    {
                    # NAME section is redundant, so skip it

                    $line = shift @inLines;
                    $line = shift @inLines while $line !~ /$v\.SH/;
                    unshift @inLines, $line;
                    print STDOUT "$loc: NOTE: NAME section is redundant " .
                        "with TITLE line -- removing\n";
                    }
                else
                    {
                    push @outLines, "$loc$v\\h $content";  # heading
                    }
                last;
                };
            /^aX$/    and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                push @outLines, "$loc$v`$content'";  # name
                last;
                };
            /^TH$/    and do
                {
                my $name;
                my $desc;
                if ( $content =~ s/^\s*\"([^\"]+)\"\s+T\s+// )
                    {
                    $name = $1;
                    }
                elsif ( $content =~ s/^\s*(\S+)\s+T\s+// )
                    {
                    $name = $1;
                    }
                else
                    {
                    print STDERR "$loc: ERROR: cannot decipher .TH command\n";
                    $::errorStatus = 1;
                    last;
                    }
                if ( $content =~ /^\"([^\"]+)\"/ )
                    {
                    $desc = $1;
                    }
                elsif ( $content =~ /^(\S+)/ )
                    {
                    $desc = $1;
                    }
                else
                    {
                    print STDERR "$loc: ERROR: cannot decipher .TH command\n";
                    $::errorStatus = 1;
                    last;
                    }
                push @outLines, "$loc$v\\TITLE $name - $desc";  # title
                $haveName = 1;
                last;
                };
            /^[sS]T$/ and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                push @outLines, "$loc$v\\sts";  # C++ class lib subtitle
                push @outLines, $content; # this should change!
                push @outLines, "$loc$v\\ste";
                last;
                };

            # tables -- these should have been removed earlier

            /^TS$/    and do
                {
                # will deal with this elsewhere

                push @outLines, "$loc$v.TS";
                last;
                };
            /^TE$/    and do
                {
                # will deal with this elsewhere

                push @outLines, "$loc$v.TE";
                last;
                };
            /^T&$/    and do
                {
                push @outLines, "$loc$v.TE", "$loc$v", "$loc$v.TS"; # defer
                last;
                };
            /^nf$/    and do
                {
                push @outLines, "$loc$v.TS"; # non-spacing paragraph(?)
                last;
                };
            /^fi$/    and do
                {
                push @outLines, "$loc$v.TE"; # end of n-s paragraph
                last;
                };

            # text markup

            /^I$/     and do
                {
                $content =~ s/\"[^\"]*$//g;  # kill anything after last quote
                $content =~ s/\"//g;
                push @outLines, "$loc$v\\tb $content";  # italics
                last;
                };
            /^IR$/    and do
                {
                $content =~ /^\"?([^\"\s]*)\"?\s+\"?([^\"]*)\"?/;
                push @outLines, "$loc$v<$1>$2";  # italics then roman
                last;
                };
            /^B$/     and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                push @outLines, "$loc$v`$content'";  # bold
                last;
                };
            /^BR$/    and do
                {
                $content =~ /^\"?([^\"\s]*)\"?\s+\"?([^\"]*)\"?/;
                push @outLines, "$loc$v`$1'$2";  # bold then roman
                last;
                };
            /^br$/    and do
                {
                push @outLines, "$loc$v";  # line break
                last;
                };
            /^[iI]T$/ and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                push @outLines, "$loc$v$content";  # indent?
                last;
                };
            /^iB$/    and do
                {
                $content =~ s/\"[^\"]*$//g;
                $content =~ s/\"//g;
                push @outLines, "$loc$v\\tb $content";  # biblio entry
                last;
                };
            /^[rR]L$/ and do
                {
                push @outLines, "$loc$v\\rl";  # horizontal rule
                last;
                };
            /^pG$/    and do
                {
                $content =~ s/^\s*\"//;
                $content =~ s/\"\s*$//;
                push @outLines,
                "$loc$v\\tb VxWorks Programmer's Guide: $content";
                last;
                };
            /^tG$/    and do
                {
                $content =~ s/^\s*\"//;
                $content =~ s/\"\s*$//;
                push @outLines,
                "$loc$v\\tb Tornado User's Guide: $content";
                last;
                };
            /^\\\"$/  and do
                {
                push @outLines, "$loc$v\\\" $content"; # comment
                last;
                };
            /^(ft|sp|vs|ne|PD|RS|RE|lE)$/ and do
                {

                # various map to nothing, or have been handled elsewhere

                last;
                };
            /^(so|P|HP)$/  and do
                {
                # various map to nothing

                last;
                };
            /^nT$/    and do
                {
                # an even more horrible legacy

		push @outLines, "$loc${v}NOTE: This is a generic page for a " .
		                "BSP-specific routine; this";
		push @outLines, "description contains general " .
		                "information only.  To determine if this";
		push @outLines, "routine is supported by your BSP, or for " .
		                "information specific to your";
		push @outLines, "BSP's version of this routine, see the " .
		                "reference pages for your BSP.";
                last;
                };

            # default case

            if ( ! $isNomanual || $::optionInternal )
                {
                print STDERR "$loc: ERROR: unrecognized mangen markup\n";
                $::errorStatus = 1;
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            push @outLines, $line;
            }
        }

    return @outLines;
    }

###############################################################################
#
# apiSpecialSectionsTranslate - convert certain sections to new markup
#
# This routine translates some specialized legacy conventions to the new
# markup.
#

sub apiSpecialSectionsTranslate
    {
    my @inLines = @_;
    my @outLines = ();

    while (@inLines)
        {
        my $line = shift @inLines;
        if ( $line =~ /${v}SYNOPSIS\s*$/ )
            {
            # ensure that synopsis is part of a code display

            push @outLines, $line;
            $line = shift @inLines;
            $line = shift @inLines while $line =~ /$v\s*$/; # skip blank lines

            if ( $line =~ /$v\\(cs|ss)/ )
                {
                # all is well

                push @outLines, $line;
                next;
                }
            else
                {
                # must add \cs and \ce

                $line =~ /^(.*)$v/o;
                push @outLines, "$1$v\\cs";
                push @outLines, $line;
                $line = shift @inLines;
                while ( scalar(@inLines) and
                        not ($line =~ /$v$::patHeading$/) )
                    {
                    push @outLines, $line;
                    $line = shift @inLines;
                    }
                if ( @inLines )
                    {
                    unshift @inLines, $line;
                    }
                else
                    {
                    push @outLines, $line;
                    }

                $line = pop @outLines;
                $line = pop @outLines while $line =~ /$v\s*$/; # skip blank lines

                push @outLines, $line;
                $line =~ /^(.*)$v/o;
                push @outLines, "$1$v\\ce tag2";
                }
            }
        elsif ( $line =~ s/${v}PARAMETERS:?\s*$/${v}PARAMETERS/o )
            {
            # reformat old style parameter list (if present)

            push @outLines, $line;
            $line = shift @inLines;
            $line = shift @inLines while $line =~ /$v\s*$/; # skip blank lines

            if ( $line =~ /$v\s*(.*\S)\s*:\s+(.*)$/ )
                {

                # must reformat

		unshift @inLines, $line;

		$line =~ /^(.*)$v/o;
                push @outLines, "$1$v\\is";

                while ( scalar(@inLines) and
                        not ($line =~ /$v(\\.*|$::patHeading)$/) )
                    {
		    $line = shift @inLines;
                    next if $line =~ /$v(\\.*|$::patHeading)$/;

                    if ( $line =~ /^(.*)$v\s*(.*\S)\s*:\s+(.*)$/ )
                        {
                        my $loc    = $1;
                        my $marker = $2;
                        my $text   = $3;
                        $text =~ s/$v\s*/$v/;
                        push @outLines, "$loc$v\\i $marker";
                        push @outLines, "$loc$v$text";
                        }
                    else
                        {

                        # must remove leading spaces to prevent pre-formatting

                        $line =~ s/$v\s*/$v/;
                        push @outLines, $line;
                        }
                    }

                if ( scalar(@inLines) > 0 )
                    {
                    unshift @inLines, $line;
                    }
                    
                $line = pop @outLines;
                $line = pop @outLines while $line =~ /$v\s*$/; # skip blank lines

                push @outLines, $line;
                $line =~ /^(.*)$v/o;
                push @outLines, "$1$v\\ie";
                }
            else
                {
                # section is not in old format

                push @outLines, $line;
                next;
                }
            }
        else
            {
            # just another ho-hum line

            push @outLines, $line;
            }
        }

    return @outLines;
    }

###############################################################################
#
# apiEntryModernize - update refgen markup for a single lib/routine entry
#
# This routine updates old refgen markup to new (strict) refgen markup.  The
# updates are not extensive.
#

sub apiEntryModernize
    {

    my @inLines = split /\n/, shift;

    my $inCode = 0;
    my $inPara = 0;
    my @outLines = ();
    my $warned = 0;
    foreach (@inLines)
        {

        # code displays are exempt from all reformatting

        if ( /$v(\\cs|\\bs|\.CS|\.bS)/ )
            {
            $inCode = 1;
            }
        elsif ( /$v(\\ce|\\be|\.CE|\.bE)/ )
            {
            $inCode = 0;
            }

        if ( $inCode )
            {
            push @outLines, $_;
            next;
            }

        # add backslashes to directives

        /^(.*)$v(.*)$/o;
        my $loc = $1;
        my $original = $2;
        if ( (s/$v\s*(APPEND\s|EXPAND\s|EXPANDPATH\s|IMPLEMENTS\s)/$v\\\1/ or
              s/$v\s*(INTERNAL|NOMANUAL|NOROUTINES)/$v\\\1/) and not $warned )
            {
            if ( ! $isNomanual || $::optionInternal )
                {
                print STDOUT "$loc: WARNING: \"$original\" directive should "
                        . "begin with backslash\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
            }

	# remove some deviant lint directives with error message

	if ( /$v\s*(VARARGS|ARGSUSED|LINTLIBRARY)/ )
	    {
            if ( ! $isNomanual || $::optionInternal )
                {
	        print STDOUT "$loc: WARNING: Illegal heading (probable lint" .
                           " directive): $original\n";
                }
            elsif ( ! $::isWarned )
                {
                ::apiPrintWarning();
                }
	    next;
	    }

	# automatic titles should not occur inside tables or special paragraphs

	if ( /$v\\(bs|is|ms|ml|ss|ts)/ )
	    {
	    $inPara = 1;
	    }

	if ( /$v\\(be|ie|me|se|te)/ )
	    {
	    $inPara = 0;
	    }

	if ( ! $inPara )
	    {
	    # make all-cap lines headings

	    s/$v$::patHeading$/$v\\h \1/o;
	    if ( $3 )
		{
		$_ .= "\n$loc$v$3";
		}

	    s/$v(\\INTERNAL)\s*:\s*(.*)$/$v\1\n$loc$v\2/;
	    }

	# Ampersands need not be escaped except at beginning of line.
	# An ampersand at the beginning of a line prevents that line
	# from becoming a section title.  The ampersand itself is deleted.

        $marker = chr 129;
        s/\\\\/$marker/g;    # protect double backslashes
	s/$v\\&([A-Z\.\\])/$v\1/;  # used to prevent special handling
        s/\\&/&/g;
        s/$marker/\\\\/og;

        push @outLines, $_;
        }

    return join "\n", @outLines;
    }

1;  # ugly necessity for putting this file in 'require' directive
