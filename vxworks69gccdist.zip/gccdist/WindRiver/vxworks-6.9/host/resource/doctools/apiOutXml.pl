# apiOutXml.pl - produce standalone XML output format from internal XML
#
# Copyright 2003, 2004 Wind River Systems, Inc.
#
# modification history
# --------------------
# 01d,01sep06,rtm  Added unlink to minimise space requirements
# 01c,10jan05,lll  Standalone apigen, SPR#105634 and SPR#104090
# 01b,02oct04,wsl  add line numbers to error messages, SPR 93816
# 01a,06mar03,wsl  written
#
# DESCRIPTION
# This subroutine takes the internal XML and converts it to independent
# true XML.
#
# NOROUTINES
#

# set the name space

package xmlOut;


###############################################################################
#
# apiGenerate - convert internal XML to text output
#
# This is the master routine for putting the text into external XML.  Since
# the internal markup is XML, this consists of little more than adding a
# header.
#

sub apiGenerate
    {
    $v = $::v;

    grep s/^.*$v//o, @_; # eliminate line numbers as no error msgs here
    my $fullText = join "\n", @_;

    my $marker = chr 129;

    $fullText =~ s/&bslash;/\\/g;
    $fullText =~ s/&btick;/\`/g;
    $fullText =~ s/&vbar;/\|/g;

    $outFileName = "$::outFileBase.xml";

    # copy any image files

    my $imageCount = 1;
    while ( $fullText =~ /<$::tagImage\s+src=\"([^\"]+)\"\s*\/>/ )
        {
        my $imgName = $1;
        $imgName =~ /(\.\w+)$/;
        my $imgExt = $1;
        my $imgOutName = "$::outFileBase$imageCount$imgExt";
        my $imgBase = ::basename($imgName);
        my $imgDir  = ::dirname($imgName);
        my $inDirName = ::dirname($::inFile);

        # check that source and destination files are not the same

        chdir $inDirName;
        chdir $imgDir;
        my $srcDir = ::cwd();
        chdir $::cwDir;
        chdir $::outDir;
        my $destDir = ::cwd();
        chdir $::cwDir;

        if ( ($imgOutName ne $imgBase) or ($srcDir ne $destDir) )
            {
            $imgName = $srcDir . "/" . $imgBase;
            my $imgOutFileName = $destDir . "/" . $imgOutName;
            ::copy($imgName, $imgOutFileName);
            unlink $imgName;
            }
        $fullText =~ s/<$::tagImage\s+src=\"[^\"]+\"\s*\/>/<$marker src=\"$imgOutName\" \/>/;

        $imgCount++;
        }
    $fullText =~ s/$marker/$::tagImage/g;

    # print output to proper file

    open OUTFILE, ">$::outDir/$outFileName";

    print OUTFILE "<?xml version=\"1.0\" encoding=\"US-ASCII\" standalone=\"yes\"?>\n";
    print OUTFILE "<!DOCTYPE $::tagApidoc SYSTEM \"apigen.dtd\">\n";
    print OUTFILE "<$::tagApidoc";
    if ( $::optionBook )
        {
        print OUTFILE " book=\"$::optionBook\"";
        }
    if ( $::optionChapter )
        {
        print OUTFILE " chapter=\"$::optionChapter\"";
        }
    print OUTFILE ">\n";
    print OUTFILE $fullText;
    print OUTFILE "\n";
    print OUTFILE "</$::tagApidoc>\n";

    close OUTFILE;

    # copy DTD file

    open INFILE, "<$::utilPath/apigen.dtd";
    open OUTFILE, ">$::outDir/apigen.dtd";

    my $buffer;
    while ( read INFILE, $buffer, 16384 )
        {
        print OUTFILE $buffer;
        }

    close INFILE;
    close OUTFILE;


    return;
    }

1;  # ugly necessity for putting this file in 'require' directive
