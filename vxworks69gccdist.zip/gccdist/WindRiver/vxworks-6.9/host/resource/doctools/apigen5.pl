# apigen5.pl - produce selected output format from internal XML
#
# Copyright (c) 2003-2005 Wind River Systems, Inc.
#
# The right to copy, distribute, modify or otherwise make use
# of this software may be licensed only pursuant to the terms
# of an applicable Wind River license agreement.
#
#
# modification history
# --------------------
# 01d,10oct05,lei  keep a copy of the internal section so that we 
#                  can generate the .rtn files later.
# 01c,08sep05,lei  print out error message and exit if dir is not 
#                  writable (SPR#111860)
# 01b,01oct04,wsl  add line numbers to error messages, SPR 93816
# 01a,05mar03,wsl  written
#
# DESCRIPTION
# This subroutine takes the internal XML and converts it to whatever
# output formats have been selected.  To do this, it just calls the package
# that is appropriate to the output format.
#
# NOROUTINES
#

# set the name space

package generate;

# read in all the routines for output formats

require "$::utilPath/apiOutHtml.pl";
require "$::utilPath/apiOutMif.pl";
require "$::utilPath/apiOutTxt.pl";
require "$::utilPath/apiOutXml.pl";

###############################################################################
#
# apiGenerate - convert internal XML to output formats
#
# This routine is the master routine for putting the text into the chosen
# output formats.
#



sub apiGenerate
    {
    $v = $::v;

    # For each selected output format, generate a file.
    # The variable $outDir is global so that the called
    # routine can know where to put its output.  The variable
    # $outForm is global so that one set of routines can process
    # similar output formats (like html and xhtml).

    if ( $::optionDebug )
        {
        print STDERR "Starting Stage 5 -- output generation\n";
        }

    my @formatList = @::optionFormat;
    my @outDirList = @::optionOutDir;

    my @inLines = map { split /\n/ } @_; # combine lib/routines into single list
    my @textLines = ();

    # keep a copy before the internal section get removed

    my @forRtnLines = @inLines;

    if ( not $::optionInternal )
        {
        # remove internal sections

        while (@inLines)
            {
            my $line = shift @inLines;
            if ( $line =~ /<(\w+)\s+scope="internal">/ )
                {
                my $tag = $1;
                while ( not $line =~ /<\/$tag>/ )
                    {
                    $line = shift @inLines;
                    }
                }
            else
                {
                push @textLines, $line;
                }
            }
        }
    else
        {
        @textLines = @inLines;
        }

    while ( @formatList )
        {
        $::outForm = shift @formatList;
        $::outDir  = shift @outDirList;


	# create the output directory and its parents if necessary

	my @dirPath = split /\//, $::outDir;

	my $partialPath = shift @dirPath;

	while ( 1 )
	    {
	    if ( "" eq $partialPath )
		{
		$partialPath = "/" . (shift @dirPath);
		}

	    if ( ! -e $partialPath )
		{

		if ( ! mkdir $partialPath, 0775 )
		    {
		    print STDERR "*** ERROR: could not create $partialPath\n";
		    exit ($::errorStatus = 1);		    
		    }
		}

	    # SPR:111860 print out error message and exit if output 
            # directory is not writable.

            if (scalar(@dirPath) == 0)
                {
                if (! -w $partialPath)
                    {
                    print STDERR "*** ERROR: directory $partialPath not writable\n";
		    exit ($::errorStatus = 1); 
		    }                                   
                last; 
		}

	    $partialPath .= "/" . shift @dirPath;
	    }
	next if ! -e $::outDir;

	# call appropriate formatting routine

        if ( $::outForm =~ /^(html|htmldoc|xhtml)$/ )
            {
            htmlOut::apiGenerate(\@textLines,\@forRtnLines);
            }
        elsif ( $::outForm eq "mif" )
            {
            mifOut::apiGenerate(@textLines);
            }
        elsif ( $::outForm eq "text" or $::outForm eq "txt" )
            {
            txtOut::apiGenerate(@textLines);
            }
        elsif ( $::outForm eq "xml" )
            {
            xmlOut::apiGenerate(@textLines);
            }
        else
            {
            print STDERR "INTERNAL ERROR: output format not implemented\n";
            $::errorStatus = 1;
            }
        }

    if ( $::optionDebug )
        {
        print STDERR "  Finished Stage 5\n";
        }

    return;
    }

1;  # ugly necessity for putting this file in 'require' directive
